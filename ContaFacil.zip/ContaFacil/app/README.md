# Clone Local - ContaFácil

Esta é uma versão local da aplicação web "ContaFácil", desenvolvida para fins de estudo e execução offline.

## Pré-requisitos

*   **Python 3:** Certifique-se de ter o Python 3 instalado em sua máquina. Você pode baixá-lo em [python.org](https://www.python.org/).
*   **Pip:** O gerenciador de pacotes do Python, geralmente incluído na instalação do Python.

## Configuração e Instalação

1.  **Descompacte o arquivo:** Extraia o conteúdo do arquivo `ContaFacil_local.zip` para uma pasta de sua preferência.
2.  **Navegue até o diretório:** Abra o terminal ou prompt de comando e navegue até a pasta `ContaFacil_local` que você acabou de extrair.
    ```bash
    cd caminho/para/ContaFacil_local
    ```
3.  **(Opcional, mas recomendado) Crie um Ambiente Virtual:** Isso isola as dependências do projeto.
    ```bash
    python -m venv venv 
    ```
4.  **(Opcional) Ative o Ambiente Virtual:**
    *   **Linux/macOS:** `source venv/bin/activate`
    *   **Windows:** `venv\Scripts\activate`
5.  **Instale as dependências:** Execute o comando abaixo para instalar o Flask e suas dependências.
    ```bash
    pip install -r requirements.txt
    ```

## Executando a Aplicação

1.  **Inicie o servidor:** No mesmo terminal (com o ambiente virtual ativado, se você o criou), execute:
    ```bash
    python app.py
    ```
2.  **Acesse no navegador:** Abra seu navegador de internet e acesse o endereço:
    [http://127.0.0.1:5000](http://127.0.0.1:5000)

## Funcionalidades

A aplicação permite:
*   Cadastrar novos usuários.
*   Fazer login com usuários existentes.
*   Adicionar e listar contas bancárias.
*   Excluir contas (isso também excluirá as movimentações associadas).
*   Criar movimentações financeiras (receitas e despesas).
*   Visualizar um resumo mensal das movimentações.
*   Excluir movimentações individuais.
*   Fazer logout.
*   **Resetar Dados:** Acessar a rota `/reset` (ex: http://127.0.0.1:5000/reset) enquanto logado limpará todas as contas e movimentações do usuário atual (útil para testes).

## Banco de Dados

*   Os dados (usuários, contas, movimentações) são armazenados em um arquivo chamado `database.db` dentro da pasta `ContaFacil_local`.
*   Este arquivo será criado automaticamente na primeira vez que você executar a aplicação, caso ele não exista.

## Observações

*   Esta é uma versão simplificada baseada na análise da aplicação original. Algumas funcionalidades complexas ou detalhes visuais podem diferir.
*   A funcionalidade de *editar conta* possui a lógica no backend, mas não foi implementada uma tela específica no frontend (a rota `/contas/editar/<id>` existe, mas redireciona para a listagem).
*   A aplicação foi desenvolvida para rodar localmente e não possui as mesmas medidas de segurança de uma aplicação web de produção.

