import os
import sqlite3

db_path = os.path.join(os.path.dirname(__file__), 'database.db')

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

cursor.execute("PRAGMA table_info(usuarios);")
columns = cursor.fetchall()

print("Estrutura da tabela 'usuarios':")
for col in columns:
    print(f"Coluna: {col[1]} | Tipo: {col[2]} | Not Null: {col[3]} | Default: {col[4]} | PK: {col[5]}")

conn.close()
