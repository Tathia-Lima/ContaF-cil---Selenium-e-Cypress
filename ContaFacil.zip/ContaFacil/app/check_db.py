import os
import sqlite3

db_path = os.path.join(os.path.dirname(__file__), 'database.db')

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Lista as tabelas do banco
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tabelas = cursor.fetchall()
print("Tabelas no banco:")
for tabela in tabelas:
    print(f"- {tabela[0]}")

print("\nDados da tabela 'user':")
cursor.execute("SELECT * FROM user")
usuarios = cursor.fetchall()
for usuario in usuarios:
    print(usuario)

conn.close()
