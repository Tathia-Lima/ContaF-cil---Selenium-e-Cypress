# -*- coding: utf-8 -*-
import os
import re
import sqlite3
import calendar
import locale
import math
import datetime
from decimal import Decimal, InvalidOperation
from datetime import date, timedelta, datetime
from flask_wtf.csrf import CSRFProtect
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, DateField, DecimalField, RadioField
from wtforms.validators import DataRequired, ValidationError, NumberRange, Length

# --- Configuração ---
app = Flask(__name__)
app.secret_key = 'uma_chave_secreta_forte_e_fixa_ou_vinda_de_variavel_ambiente'
csrf = CSRFProtect(app)  # ativa a proteção CSRF para toda a aplicação

# Caminho do banco de dados (relativo ao app.py)
DATABASE = os.path.join(os.path.dirname(__file__), 'database.db')

# Dados do admin
email = 'admin@teste.com'
senha = 'senha_supersegura'
senha_hash = generate_password_hash(senha)
is_admin = 1  # ou True, conforme sua tabela

# Conecta no banco SQLite
conn = sqlite3.connect(DATABASE)
cursor = conn.cursor()

# --- Decorator de autenticação (exemplo) ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            # Aqui deve redirecionar para login ou tratar o não login
            return "Você precisa estar logado", 401
        return f(*args, **kwargs)
    return decorated_function

# --- Injeta a variável meses em português em todos os templates ---
@app.context_processor
def inject_meses():
    meses = {
        1: 'Janeiro', 2: 'Fevereiro', 3: 'Março', 4: 'Abril',
        5: 'Maio', 6: 'Junho', 7: 'Julho', 8: 'Agosto',
        9: 'Setembro', 10: 'Outubro', 11: 'Novembro', 12: 'Dezembro'
    }
    return dict(meses=meses)

# --- Banco de Dados ---
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row # Retorna linhas como dicionários
    return db

# --- Fecha conexão automaticamente ao final de cada request ---
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

def execute_db(query, args=()):
    conn = get_db()
    cursor = conn.cursor()
    print(f"DEBUG: Executando DB query: {query} com args: {args}") # Adicione esta linha
    cursor.execute(query, args)
    conn.commit()
    print("DEBUG: DB commit realizado com sucesso!") # Adicione esta linha
    last_id = cursor.lastrowid
    return last_id


def init_db_command():
    """Cria as tabelas do banco de dados."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    # Criar tabela usuarios
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        senha TEXT NOT NULL
    );
    """)
    # Criar tabela contas
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS contas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        usuario_id INTEGER NOT NULL,
        FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
    );
    """)
    # Criar tabela movimentacoes
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS movimentacoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        conta_id INTEGER NOT NULL,
        tipo TEXT NOT NULL CHECK(tipo IN ('receita', 'despesa')),
        data_movimentacao TEXT NOT NULL, -- Formato YYYY-MM-DD
        data_pagamento TEXT NOT NULL,    -- Formato YYYY-MM-DD
        descricao TEXT NOT NULL,
        interessado TEXT,
        valor REAL NOT NULL,
        situacao TEXT NOT NULL CHECK(situacao IN ('pago', 'pendente')),
        FOREIGN KEY(usuario_id) REFERENCES usuarios(id),
        FOREIGN KEY(conta_id) REFERENCES contas(id) ON DELETE CASCADE -- Adicionado ON DELETE CASCADE
    );
    """)
    conn.commit()
    conn.close()
    print('Banco de dados inicializado.')

# Inicializa o DB se ele não existir
if not os.path.exists(DATABASE):
    init_db_command()

# --- Decorator de Autenticação ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Você precisa estar logado para acessar esta página.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def query_db(query, args=(), one=False):
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # Permite acessar colunas pelo nome
    cur = conn.cursor()
    cur.execute(query, args)
    rv = cur.fetchall()
    conn.close()
    return (rv[0] if rv else None) if one else rv

def get_user_by_id(user_id):
    user = query_db('SELECT * FROM usuarios WHERE id = ?', [user_id], one=True)
    return user

class MovimentacaoForm(FlaskForm):
    tipo = SelectField(
        'Tipo da Movimentação',
        choices=[('receita', 'Receita'), ('despesa', 'Despesa')],
        validators=[DataRequired(message='Selecione o tipo de movimentação.')]
    )
    data_movimentacao = DateField(
        'Data da Movimentação',
        format='%Y-%m-%d',
        validators=[DataRequired(message='Informe a data da movimentação.'),]
    )
    data_pagamento = DateField(
        'Data do Pagamento',
        format='%Y-%m-%d',
        validators=[DataRequired(message='Informe a data de pagamento.'),]
    )
    descricao = StringField(
        'Descrição',
        validators=[
            DataRequired(message='Descrição é obrigatória.'),
            Length(max=30, message='Descrição deve ter no máximo 30 caracteres.')
        ]
    )
    interessado = StringField('Interessado')
    valor = DecimalField('Valor', places=2)
    conta_id = SelectField(
        'Conta',
        coerce=int,
        validators=[DataRequired(message="Você precisa selecionar uma conta.")]
    )
    situacao = RadioField(
        'Situação',
        choices=[('pago', 'Pago'), ('pendente', 'Pendente')],
        validators=[DataRequired(message='Selecione a situação da movimentação.')]
    )

    def validate_conta_id(self, field):
        if field.data == 0:
            raise ValidationError('Você precisa selecionar uma conta válida.')

    def validate_valor(self, field):
        field.errors[:] = [] # Limpa erros anteriores

        raw_value = field.raw_data[0].strip() if field.raw_data else ''

        if not raw_value:
            raise ValidationError('Informe um valor.')
        
        try:
            decimal_value = Decimal(raw_value.replace(',', '.'))
        except InvalidOperation:
            raise ValidationError('Valor inválido.')
        except TypeError:
            raise ValidationError('Valor inválido.')

        if decimal_value < Decimal('0.01'):
            raise ValidationError('O valor deve ser maior ou igual a 0.01.')

        field.data = decimal_value

    def validate_data_movimentacao(self, field):
        if not field.data:
            raise ValidationError('Informe a data da movimentação.')

        hoje = date.today()
        dez_anos_atras = hoje - timedelta(days=365*10)

        if field.data < dez_anos_atras or field.data > hoje:
            raise ValidationError(
                f'A data da movimentação deve estar entre {dez_anos_atras.strftime("%d/%m/%Y")} e {hoje.strftime("%d/%m/%Y")}.'
            )

    def validate_data_pagamento(self, field):
        if not field.data:
            raise ValidationError('Informe a data de pagamento.')

        hoje = date.today()
        dez_anos_atras = hoje - timedelta(days=365*10)

        if field.data < dez_anos_atras or field.data > hoje:
            raise ValidationError(
                f'A data de pagamento deve estar entre {dez_anos_atras.strftime("%d/%m/%Y")} e {hoje.strftime("%d/%m/%Y")}.'
            )

    def validate(self, **kwargs):
        # Primeiro faz validações padrões dos campos
        is_valid = super().validate(**kwargs)

        # Só prossegue se os campos básicos são válidos
        if not is_valid:
            return False

        hoje = date.today()
        data_mov = self.data_movimentacao.data
        data_pag = self.data_pagamento.data
        situacao = self.situacao.data

        # Regra: para 'pago', data_movimentacao não pode ser após data_pagamento
        if situacao == 'pago' and data_mov and data_pag:
            if data_mov > data_pag:
                self.data_movimentacao.errors.append(
                    'Para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento.'
                )
                is_valid = False

        # Regra: para 'pago', data_pagamento não pode ser no futuro
        if situacao == 'pago' and data_pag:
            if data_pag > hoje:
                self.data_pagamento.errors.append(
                    'Para movimentações pagas, a data de pagamento não pode ser no futuro.'
                )
                is_valid = False

        # Regra: para 'pendente', data_pagamento não pode ser no passado
        if situacao == 'pendente' and data_pag:
            if data_pag < hoje:
                self.data_pagamento.errors.append(
                    'Para movimentações pendentes, a data de pagamento não pode ser no passado.'
                )
                is_valid = False

        return is_valid

# --- Rotas ---
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('home'))
    return redirect(url_for('login'))

@app.route('/admin')
def admin():
    if 'user_id' not in session:
        flash('Você precisa estar logado para acessar esta página.', 'warning')
        return redirect(url_for('login'))

    user = get_user_by_id(session['user_id'])
    if not user or user['is_admin'] != 1:
        flash('Acesso não autorizado.', 'danger')
        return redirect(url_for('login'))

    return render_template('admin.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'tentativas' not in session:
        session['tentativas'] = 0

    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']

        user = query_db('SELECT * FROM usuarios WHERE email = ?', [email], one=True)

        if user and check_password_hash(user['senha'], senha):
            session['user_id'] = user['id']
            session['user_name'] = user['nome']
            session.pop('tentativas', None)  # Zera tentativas
            return redirect(url_for('home'))
        else:
            session['tentativas'] += 1

            if session['tentativas'] >= 6:  # bloqueia só na 6ª tentativa
                flash('Muitas tentativas. Tente novamente mais tarde.', 'danger')
            else:
                flash('Email ou senha inválidos.', 'danger')

        return render_template('login.html')

    return render_template('login.html')

def validar_email(email):
    regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(regex, email)

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form['nome'].strip()
        email = request.form['email'].strip()
        senha = request.form['senha'].strip()

        if not nome or not email or not senha:
            flash('Todos os campos são obrigatórios!', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if not re.match(r'^[A-Za-zÀ-ÿ\s]+$', nome):
            flash('Nome deve conter apenas letras.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if len(nome) > 50:
            flash('Máximo de 50 caracteres no nome.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if not validar_email(email):
            flash('Email inválido.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if ' ' in senha:
            flash('Senha não pode conter espaços.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if len(senha) < 8 or len(senha) > 10:
            flash('Senha deve ter entre 8 e 10 caracteres.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if not re.search(r'[A-Za-z]', senha):
            flash('Senha deve conter pelo menos uma letra.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if not re.search(r'\d', senha):
            flash('Senha deve conter pelo menos um número.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        if not re.search(r'[!@#$%^&*(),.?":{}|<>_]', senha):
            flash('Senha deve conter pelo menos um caractere especial.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

        hashed_senha = generate_password_hash(senha)

        try:
            execute_db(
                "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)",
                (nome, email, hashed_senha)
            )
            flash('Usuário cadastrado com sucesso! Faça o login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Endereço de email já utilizado.', 'danger')
            return render_template('cadastro.html', nome=nome, email=email)

    return render_template('cadastro.html')

@app.route('/logout')
@login_required
def logout():
    session.pop('user_id', None)
    session.pop('user_name', None)
    flash('Você saiu da sua conta.', 'info')
    return redirect(url_for('login'))

# --- Rotas Protegidas ---
@app.route('/home')
@login_required
def home():
    user_id = session['user_id']
    contas = query_db("SELECT * FROM contas WHERE usuario_id = ?", [user_id])

    saldo_total = 0
    total_receitas = 0
    total_despesas = 0
    contas_com_saldo = []

    for conta in contas:
        # Consulta receitas pagas
        mov_receitas = query_db(
            "SELECT IFNULL(SUM(valor), 0) as total FROM movimentacoes WHERE conta_id = ? AND tipo = 'receita'",
            [conta['id']], one=True
        )
        # Consulta TODAS as despesas (pagas e pendentes)
        mov_despesas = query_db(
            "SELECT IFNULL(SUM(valor), 0) as total FROM movimentacoes WHERE conta_id = ? AND tipo = 'despesa'",
            [conta['id']], one=True
        )

        receitas = mov_receitas['total']
        despesas = mov_despesas['total']
        saldo = receitas - despesas

        saldo_total += saldo
        total_receitas += receitas
        total_despesas += despesas

        contas_com_saldo.append({
            'id': conta['id'],
            'nome': conta['nome'],
            'receitas': receitas,
            'despesas': despesas,
            'saldo': saldo
        })

    # Ordena por nome, ignorando maiúsculas/minúsculas
    contas_com_saldo = sorted(contas_com_saldo, key=lambda c: c['nome'].lower())

    return render_template(
        'home.html',
        username=session.get('user_name'),
        contas=contas_com_saldo,
        saldo_total=saldo_total,
        total_receitas=total_receitas,
        total_despesas=total_despesas
    )

# --- Contas ---
@app.route('/contas/adicionar', methods=['GET', 'POST'])
@login_required
def contas_adicionar():
    if request.method == 'POST':
        nome = request.form['nome'].strip()

        if not nome:
            flash('O nome da conta é obrigatório.', 'warning')
        elif len(nome) > 20:
            flash('O nome da conta deve ter no máximo 20 caracteres.', 'warning')
        else:
            # 🔍 Verifica se o nome da conta já existe para o usuário atual
            conta_existente = query_db(
                "SELECT 1 FROM contas WHERE nome = ? AND usuario_id = ?",
                [nome, session['user_id']],
                one=True
            )

            if conta_existente:
                flash('Já existe uma conta com esse nome.', 'warning')
            else:
                try:
                    execute_db(
                        "INSERT INTO contas (nome, usuario_id) VALUES (?, ?)",
                        [nome, session['user_id']]
                    )
                    flash('Conta adicionada com sucesso!', 'success')
                    return redirect(url_for('contas_listar'))
                except Exception as e:
                    flash(f'Erro ao adicionar conta: {e}', 'danger')

    return render_template('contas_adicionar.html')

@app.route('/contas')
@login_required

def contas_listar():
    contas = query_db("SELECT * FROM contas WHERE usuario_id = ? ORDER BY nome", [session['user_id']])
    return render_template('contas_listar.html', contas=contas)

@app.route('/contas/editar/<int:conta_id>', methods=['GET', 'POST']) # Rota para editar
@login_required
def contas_editar(conta_id):
    # Esta funcionalidade não foi completamente implementada no frontend original
    # Apenas a rota e a lógica básica de update estão aqui
    conta = query_db("SELECT * FROM contas WHERE id = ? AND usuario_id = ?", [conta_id, session['user_id']], one=True)
    if not conta:
        flash('Conta não encontrada ou não pertence a você.', 'danger')
        return redirect(url_for('contas_listar'))

    if request.method == 'POST':
        nome = request.form['nome']
        if not nome:
            flash('O nome da conta é obrigatório.', 'warning')
            # Deveria renderizar um template de edição aqui
            return redirect(url_for('contas_editar', conta_id=conta_id))
        else:
            try:
                execute_db("UPDATE contas SET nome = ? WHERE id = ? AND usuario_id = ?", [nome, conta_id, session['user_id']])
                flash('Conta atualizada com sucesso!', 'success')
                return redirect(url_for('contas_listar'))
            except Exception as e:
                flash(f'Erro ao atualizar conta: {e}', 'danger')
    
    # Renderiza o template de edição
    return render_template('contas_editar.html', conta=conta)

@app.route('/contas/excluir/<int:conta_id>', methods=['POST'])
@login_required
def contas_excluir(conta_id):
    # Verifica se a conta pertence ao usuário antes de excluir
    conta = query_db("SELECT id FROM contas WHERE id = ? AND usuario_id = ?", [conta_id, session['user_id']], one=True)
    if not conta:
        flash('Conta não encontrada ou não pertence a você.', 'danger')
        return redirect(url_for('contas_listar'))
        
    try:
        # ON DELETE CASCADE cuidará das movimentações
        execute_db("DELETE FROM contas WHERE id = ? AND usuario_id = ?", [conta_id, session['user_id']])
        flash('Conta e suas movimentações excluídas com sucesso!', 'success')
    except Exception as e:
        flash(f'Erro ao excluir conta: {e}', 'danger')
    return redirect(url_for('contas_listar'))

@app.route('/contas/detalhes/<int:conta_id>')
@login_required
def conta_detalhes(conta_id):
    # Verifica se a conta pertence ao usuário
    conta = query_db("SELECT * FROM contas WHERE id = ? AND usuario_id = ?", [conta_id, session['user_id']], one=True)
    if not conta:
        flash('Conta não encontrada ou não pertence a você.', 'danger')
        return redirect(url_for('contas_listar'))
    
    # Busca o nome do usuário
    usuario = query_db("SELECT nome FROM usuarios WHERE id = ?", [session['user_id']], one=True)
    usuario_nome = usuario['nome'] if usuario else 'Usuário'
    
    # Calcula saldo da conta
    mov_receitas = query_db("SELECT IFNULL(SUM(valor), 0) as total FROM movimentacoes WHERE conta_id = ? AND tipo = 'receita'", [conta_id], one=True)
    mov_despesas = query_db("SELECT IFNULL(SUM(valor), 0) as total FROM movimentacoes WHERE conta_id = ? AND tipo = 'despesa'", [conta_id], one=True)
    
    total_receitas = mov_receitas['total'] or 0
    total_despesas = mov_despesas['total'] or 0
    saldo = total_receitas - total_despesas
    
    # Busca total de movimentações (para a contagem total de itens)
    # Esta variável agora é usada corretamente para o cálculo das páginas
    total_movimentacoes_geral = query_db("SELECT COUNT(*) as total FROM movimentacoes WHERE conta_id = ?", [conta_id], one=True)['total']

    # --- Lógica de Paginação ---
    per_page = 10 # Número máximo de itens por página
    current_page = request.args.get('page', 1, type=int) # Pega o número da página da URL, padrão é 1
    
    # Calcula o offset para a consulta SQL
    offset = (current_page - 1) * per_page
    
    # Calcula o total de páginas
    # CORREÇÃO: Usando total_movimentacoes_geral
    total_pages = math.ceil(total_movimentacoes_geral / per_page)

    # Busca as movimentações para a página atual (com LIMIT e OFFSET)
    # CORREÇÃO: Usando LIMIT e OFFSET para paginar a consulta
    movimentacoes_paginated = query_db("""
        SELECT * FROM movimentacoes 
        WHERE conta_id = ? 
        ORDER BY data_movimentacao DESC, id DESC 
        LIMIT ? OFFSET ?
    """, [conta_id, per_page, offset])
    
    return render_template('conta_detalhes.html', 
                         conta=conta,
                         usuario_nome=usuario_nome,
                         saldo=saldo,
                         total_receitas=total_receitas,
                         total_despesas=total_despesas,
                         total_movimentacoes=total_movimentacoes_geral, # Passa o total geral de movimentações
                         movimentacoes_recentes=movimentacoes_paginated, # Passa apenas as movimentações da página atual
                         current_page=current_page, # CORREÇÃO: Passa a página atual
                         total_pages=total_pages) # CORREÇÃO: Passa o total de páginas


# --- Rota Temporária para Limpeza de XSS (APENAS PARA TESTES) ---
@app.route('/clean-xss-payloads', methods=['GET']) # <--- ROTA CORRETA PARA A LIMPEZA
@login_required
def clean_xss_payloads():
    try:
        # Limpa movimentações com o payload XSS na descrição
        execute_db("DELETE FROM movimentacoes WHERE descricao LIKE '%<script>alert(\"XSS Vulnerability!\");</script>%'")
        flash('Payloads XSS de teste removidos do banco de dados!', 'success')
    except Exception as e:
        flash(f'Erro ao limpar payloads XSS: {e}', 'danger')
    return redirect(url_for('resumo'))


# --- Movimentações ---
@app.route('/movimentacao', methods=['GET', 'POST'])
@login_required
def movimentacao():
    user_id = session['user_id']
    contas = query_db("SELECT id, nome FROM contas WHERE usuario_id = ? ORDER BY nome", [user_id])
    choices_contas = [(0, 'Selecione uma conta')] + [(conta['id'], conta['nome']) for conta in contas]
    choices_tipo = [('', 'Selecione o tipo de movimentação'), ('receita', 'Receita'), ('despesa', 'Despesa')]

    form = MovimentacaoForm()
    form.conta_id.choices = choices_contas
    form.tipo.choices = choices_tipo

    if request.method == 'GET':
        form.situacao.data = None

    if len(contas) == 0:
        flash('Você precisa cadastrar uma conta antes de criar movimentações.', 'warning')
        return render_template('movimentacao.html', form=form, server_today=date.today().strftime('%Y-%m-%d'))

    # --- NOVOS PRINTS DE DEBUG AQUI ---
    print(f"DEBUG: request.method: {request.method}")
    if request.method == 'POST':
        print(f"DEBUG: Dados do formulário recebidos: {request.form}")
        print(f"DEBUG: Valor da descrição em request.form: '{request.form.get('descricao')}'")
        print(f"DEBUG: Comprimento da descrição em request.form: {len(request.form.get('descricao', ''))}")
    # --- FIM DOS NOVOS PRINTS DE DEBUG ---

    if form.validate_on_submit():
        print("DEBUG: form.validate_on_submit() retornou TRUE") # DEBUG
        # Se o formulário passou nas validações do Flask-WTF (incluindo as personalizadas)
        # Agora, faça a validação que depende do banco de dados (se a conta existe para o usuário)

        # Validação da conta (verificação no banco de dados)
        conta_valida = query_db(
            "SELECT id FROM contas WHERE id = ? AND usuario_id = ?",
            [form.conta_id.data, user_id],
            one=True
        )
        if not conta_valida:
            flash('Conta inválida selecionada.', 'danger')
            return render_template('movimentacao.html', form=form, server_today=date.today().strftime('%Y-%m-%d'))

        # --- TRECHO DE INSERÇÃO NO BANCO DE DADOS (AGORA COMPLETO) ---
        try:
            data_movimentacao = form.data_movimentacao.data
            data_pagamento = form.data_pagamento.data
            valor_decimal = form.valor.data
            situacao = form.situacao.data

            execute_db("""
                INSERT INTO movimentacoes
                (usuario_id, conta_id, tipo, data_movimentacao, data_pagamento, descricao, interessado, valor, situacao)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, [
                user_id,
                form.conta_id.data,
                form.tipo.data,
                data_movimentacao.strftime('%Y-%m-%d'),
                data_pagamento.strftime('%Y-%m-%d'),
                form.descricao.data,
                form.interessado.data,
                float(valor_decimal),
                situacao
            ])
            flash(
                'Receita incluída com sucesso!' if form.tipo.data == 'receita' else 'Despesa incluída com sucesso!',
                'success'
            )
            return redirect(url_for('resumo'))
        except Exception as e:
            print(f"DEBUG: Erro ao salvar movimentação: {e}") # DEBUG
            flash(f'Erro ao salvar movimentação: {e}', 'danger')
            return render_template('movimentacao.html', form=form, server_today=date.today().strftime('%Y-%m-%d'))
    else:
        print("DEBUG: form.validate_on_submit() retornou FALSE") # DEBUG
        # --- NOVOS PRINTS DE DEBUG AQUI ---
        print(f"DEBUG: Erros do formulário: {form.errors}")
        # --- FIM DOS NOVOS PRINTS DE DEBUG ---
        for field, errors in form.errors.items():
            for error in errors:
                flash(error, 'danger')

    return render_template('movimentacao.html', form=form, server_today=date.today().strftime('%Y-%m-%d'))

# ROTA para EDITAR Movimentação
@app.route('/movimentacao/editar/<int:movimentacao_id>', methods=['GET', 'POST'])
@login_required
def movimentacao_editar(movimentacao_id):
    form = MovimentacaoForm()
    user_id = session['user_id']

    # Popula as escolhas de tipo e conta para o formulário de edição
    contas = query_db("SELECT id, nome FROM contas WHERE usuario_id = ? ORDER BY nome", [user_id])
    form.conta_id.choices = [(0, 'Selecione uma conta')] + [(conta['id'], conta['nome']) for conta in contas]
    form.tipo.choices = [('', 'Selecione o tipo de movimentação'), ('receita', 'Receita'), ('despesa', 'Despesa')]

    movimentacao_data = query_db("SELECT * FROM movimentacoes WHERE id = ? AND usuario_id = ?",
                                 [movimentacao_id, user_id], one=True)


    if not movimentacao_data:
        flash('Movimentação não encontrada ou não pertence a você.', 'danger')
        return redirect(url_for('home'))  # Redireciona para a home se não encontrar

    if form.validate_on_submit():
        # Validação da conta (verificação no banco de dados)
        conta_valida = query_db(
            "SELECT id FROM contas WHERE id = ? AND usuario_id = ?",
            [form.conta_id.data, user_id],
            one=True
        )
        if not conta_valida:
            flash('Conta inválida selecionada.', 'danger')
            return render_template('movimentacao_editar.html', form=form, movimentacao_id=movimentacao_id, conta_id_from_mov=movimentacao_data['conta_id'])

        try:
            data_movimentacao = form.data_movimentacao.data
            data_pagamento = form.data_pagamento.data
            valor_decimal = form.valor.data
            situacao = form.situacao.data

            print(f"DEBUG UPDATE: ID={movimentacao_id}, Tipo={form.tipo.data}, Valor={float(valor_decimal)}, "
                  f"DataMov={data_movimentacao.strftime('%Y-%m-%d')}, DataPag={data_pagamento.strftime('%Y-%m-%d')}, "
                  f"Descricao={form.descricao.data}, Interessado={form.interessado.data}, "
                  f"ContaID={form.conta_id.data}, Situacao={situacao}")

            execute_db("""
                UPDATE movimentacoes SET
                tipo = ?, valor = ?, data_movimentacao = ?, data_pagamento = ?,
                descricao = ?, interessado = ?, conta_id = ?, situacao = ?
                WHERE id = ? AND usuario_id = ?
            """, [
                form.tipo.data,
                float(valor_decimal),
                data_movimentacao.strftime('%Y-%m-%d'),
                data_pagamento.strftime('%Y-%m-%d'),
                form.descricao.data,
                form.interessado.data,
                form.conta_id.data,
                situacao,
                movimentacao_id,
                user_id
            ])
            flash('Movimentação atualizada com sucesso!', 'success')
            return redirect(url_for('conta_detalhes', conta_id=form.conta_id.data))
        except Exception as e:
            flash(f'Erro ao atualizar movimentação: {e}', 'danger')
            return render_template('movimentacao_editar.html', form=form, movimentacao_id=movimentacao_id, conta_id_from_mov=movimentacao_data['conta_id'])

    elif request.method == 'GET':
        # Preenche o formulário com os dados da movimentação para edição (apenas no GET)
        form.tipo.data = movimentacao_data['tipo']
        form.valor.data = Decimal(str(movimentacao_data['valor']))
        form.data_movimentacao.data = datetime.strptime(movimentacao_data['data_movimentacao'], '%Y-%m-%d').date() if movimentacao_data['data_movimentacao'] else None
        form.data_pagamento.data = datetime.strptime(movimentacao_data['data_pagamento'], '%Y-%m-%d').date() if movimentacao_data['data_pagamento'] else None

        form.descricao.data = movimentacao_data['descricao']
        form.interessado.data = movimentacao_data['interessado']
        form.conta_id.data = movimentacao_data['conta_id']
        form.situacao.data = movimentacao_data['situacao']
    else:
        # Mostra somente as mensagens de erro sem o nome do campo
        for field, errors in form.errors.items():
            for error in errors:
                flash(error, 'danger')
        # Erros gerais (não vinculados a um campo)
        if hasattr(form, 'non_field_errors'):
            for error in form.non_field_errors:
                flash(error, 'danger')
        elif hasattr(form, 'errors') and isinstance(form.errors, dict) and None in form.errors:
            for error in form.errors[None]:
                flash(error, 'danger')

    return render_template('movimentacao_editar.html',
                           form=form,
                           movimentacao_id=movimentacao_id,
                           conta_id_from_mov=movimentacao_data['conta_id'])

@app.route('/movimentacao/excluir/<int:mov_id>', methods=['POST'])
@login_required
def movimentacao_excluir(mov_id):
    # Verifica se a movimentação pertence ao usuário
    mov = query_db("SELECT id FROM movimentacoes WHERE id = ? AND usuario_id = ?", [mov_id, session['user_id']], one=True)
    if not mov:
        flash('Movimentação não encontrada ou não pertence a você.', 'danger')
    else:
        try:
            execute_db("DELETE FROM movimentacoes WHERE id = ? AND usuario_id = ?", [mov_id, session['user_id']])
            flash('Movimentação excluída com sucesso!', 'success')
        except Exception as e:
            flash(f'Erro ao excluir movimentação: {e}', 'danger')
            
    # Tenta voltar para a URL de onde veio (Resumo Mensal)
    redirect_url = request.form.get('redirect_url') or url_for('resumo')
    return redirect(redirect_url)

@app.route('/api/contas/<int:conta_id>/totais')
@login_required
def api_totais(conta_id):
    print(f"DEBUG API: api_totais chamada para conta_id={conta_id}")
    user_id = session['user_id']
    print(f"DEBUG API: user_id={user_id}")

    # Verifica se a conta existe e pertence ao usuário
    conta = query_db(
        "SELECT id FROM contas WHERE id = ? AND usuario_id = ?",
        [conta_id, user_id],
        one=True
    )
    if not conta:
        print(f"DEBUG API: Conta {conta_id} não encontrada ou não pertence ao usuário {user_id}")
        return jsonify({"erro": "Conta não encontrada ou não pertence ao usuário."}), 404

    print(f"DEBUG API: Conta {conta_id} encontrada para user {user_id}. Buscando movimentações...")
    movimentacoes = query_db(
        "SELECT tipo, valor FROM movimentacoes WHERE conta_id = ? AND usuario_id = ?",
        [conta_id, user_id]
    )
    print(f"DEBUG API: Movimentações encontradas: {movimentacoes}")

    try:
        total_receitas = sum(m['valor'] for m in movimentacoes if m['tipo'] == 'receita')
        total_despesas = sum(m['valor'] for m in movimentacoes if m['tipo'] == 'despesa')
        total_movimentacoes = len(movimentacoes)
    except Exception as e:
        print(f"DEBUG API: ERRO ao calcular totais: {e}")
        # Re-lança a exceção para que o Flask ainda retorne 500, mas com o print no log
        raise 

    print(f"DEBUG API: Totais calculados: Receitas={total_receitas}, Despesas={total_despesas}")
    return jsonify({
        "total_receitas": float(total_receitas),
        "total_despesas": float(total_despesas),
        "total_movimentacoes": total_movimentacoes
    })
    
# --- Resumo Mensal ---
@app.route('/resumo')
@login_required
def resumo():
    user_id = session['user_id']
    now = datetime.now()

    # Pega mês e ano dos parâmetros GET, ou usa valores atuais como padrão
    mes_atual = request.args.get('mes', default=now.month, type=int)
    ano_atual = request.args.get('ano', default=now.year, type=int)
    tipo = request.args.get('tipo', default='todos', type=str)

    month_str = f'{mes_atual:02d}'
    year_str = str(ano_atual)
    date_pattern = f'{year_str}-{month_str}-%'

    try:
        # Consulta SQL base
        sql_base = """
            SELECT m.*, c.nome as conta_nome, 
                   strftime('%Y-%m-%d', m.data_pagamento) as data_pagamento_fmt,
                   strftime('%Y-%m-%d', m.data_movimentacao) as data_movimentacao_fmt
            FROM movimentacoes m 
            JOIN contas c ON m.conta_id = c.id 
            WHERE m.usuario_id = ? AND m.data_movimentacao LIKE ?
        """
        
        # Adiciona filtro por tipo se necessário
        params = [user_id, date_pattern]
        if tipo == 'receita':
            sql_base += " AND m.tipo = 'receita'"
        elif tipo == 'despesa':
            sql_base += " AND m.tipo = 'despesa'"
            
        # Adiciona ordenação
        sql_base += " ORDER BY m.data_movimentacao DESC, m.id DESC"
        
        # Executa a consulta
        movimentacoes = query_db(sql_base, params)

        return render_template('resumo.html',
                            movimentacoes=movimentacoes,
                            mes_atual=mes_atual,
                            ano_atual=ano_atual,
                            tipo=tipo)
    except Exception as e:
        flash(f'Erro ao carregar resumo mensal: {e}', 'danger')
        return redirect(url_for('home'))

# --- Reset (Opcional, para testes) ---
@app.route('/reset', methods=['POST', 'GET']) # GET só para facilitar o clique no link
@login_required
def reset_data():
    user_id = session['user_id']
    try:
        # Exclui movimentações e contas do usuário logado
        execute_db("DELETE FROM movimentacoes WHERE usuario_id = ?", [user_id])
        execute_db("DELETE FROM contas WHERE usuario_id = ?", [user_id])
        flash('Seus dados (contas e movimentações) foram resetados com sucesso!', 'warning')
    except Exception as e:
        flash(f'Erro ao resetar dados: {e}', 'danger')
    return redirect(url_for('home'))

# --- Execução ---
if __name__ == '__main__':
    # Host 0.0.0.0 permite acesso externo na rede local/exposição
    # debug=False para evitar problemas com recarregamento e teardown_appcontext
    app.run(debug=False, host='0.0.0.0', port=5000)