document.addEventListener('DOMContentLoaded', function () {
    const senhaInput = document.getElementById('senha');
    const toggleButton = document.getElementById('togglePassword');

    if (senhaInput && toggleButton) {
        toggleButton.addEventListener('click', function () {
            const isPassword = senhaInput.type === 'password';
            senhaInput.type = isPassword ? 'text' : 'password';
            toggleButton.textContent = isPassword ? '🔒' : '👁️';
            toggleButton.setAttribute('aria-label', isPassword ? 'Ocultar senha' : 'Mostrar senha');
        });
    }
});
