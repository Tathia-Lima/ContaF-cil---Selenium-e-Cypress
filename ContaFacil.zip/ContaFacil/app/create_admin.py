// Em create_admin.py

// ... (código anterior) ...
    # Verifica se o admin já existe
    cursor.execute("SELECT * FROM usuarios WHERE email = ?", (email,))
    if cursor.fetchone() is None:
        try:
            # CORREÇÃO: Adiciona a coluna is_admin no INSERT
            cursor.execute("""
                INSERT INTO usuarios (nome, email, senha, is_admin)
                VALUES (?, ?, ?, ?)
            """, (nome, email, senha_hash, 1)) # Adiciona o valor 1 para is_admin
            conn.commit()
            print('Usuário admin criado com sucesso!')
        except sqlite3.Error as e:
            print(f'Erro ao criar usuário admin: {e}')
    else:
        print('Usuário admin já existe no banco.')
