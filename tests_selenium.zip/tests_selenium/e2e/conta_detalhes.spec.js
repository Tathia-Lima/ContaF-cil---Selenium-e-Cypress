// e2e/conta_detalhes.spec.js
import { Builder, By, until } from 'selenium-webdriver';
import { expect } from 'chai';
import chrome from 'selenium-webdriver/chrome.js';
import LoginPage from '../support/page_objects/LoginPage.js';
import ContaDetalhesPage from '../support/page_objects/ContaDetalhesPage.js';

let driver;
let loginPage;
let contaDetalhesPage;

const baseUrl = 'http://localhost:5000';
const contaUsuario = {
  email: 'conta_detalhes@conta.com',
  senha: 'login_10'
};

// Cores para validação (usando regex para aceitar rgb ou rgba )
const greenColorRegex = /(?:rgb|rgba)\(0,\s*255,\s*0(?:,\s*1)?\)/;
const redColorRegex = /(?:rgb|rgba)\(255,\s*36,\s*0(?:,\s*1)?\)/;
const yellowColorRegex = /(?:rgb|rgba)\(255,\s*152,\s*0(?:,\s*1)?\)/;

describe('Página Conta Detalhes - Testes Funcionais e Segurança', () => {

   before(async () => {
    // ... (código do before permanece o mesmo)
    const options = new chrome.Options();
    options.addArguments('--start-maximized');
    driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build();
    loginPage = new LoginPage(driver, baseUrl);
    contaDetalhesPage = new ContaDetalhesPage(driver, baseUrl);
    // O login inicial é feito aqui, mas pode ser invalidado pelo teste 273
  });

  // --- CORREÇÃO: beforeEach agora garante o estado de login ---
  beforeEach(async () => {
    // Verifica se o usuário está logado olhando a URL atual.
    const currentUrl = await driver.getCurrentUrl();
    if (!currentUrl.includes('/home')) {
      // Se não estiver na home (provavelmente foi deslogado), faz o login novamente.
      console.log('[beforeEach] Usuário não está na home. Fazendo login novamente...');
      await loginPage.login(contaUsuario.email, contaUsuario.senha);
    }
    // Garante que, após a verificação/login, estamos na página /home
    await driver.get(`${baseUrl}/home`);
    await driver.wait(until.urlContains('/home'), 5000);
    await driver.wait(until.elementLocated(By.css('table.table')), 5000);
  });

  after(async () => {
    if (driver) {
      await driver.quit();
    }
  });

  // --- FUNÇÃO AUXILIAR SIMPLIFICADA E ROBUSTA ---
  async function abrirDetalhesConta(nomeConta) {
    // Encontra o link "Detalhes" na linha da conta
    const detalhesLink = await driver.wait(
      until.elementLocated(
        By.xpath(`//tr[.//a[normalize-space(text())='${nomeConta}']]//a[contains(text(), 'Detalhes')]`)
      ), 10000, `Link 'Detalhes' para a conta '${nomeConta}' não encontrado na home.`
    );

    // Remove o atributo target="_blank" para forçar a abertura na mesma aba
    await driver.executeScript("arguments[0].removeAttribute('target')", detalhesLink);

    // Clica no link
    await detalhesLink.click();

    // Confirma que a navegação para a página de detalhes ocorreu na mesma aba
    await driver.wait(until.urlContains('/contas/detalhes/'), 10000, 'A navegação para a página de detalhes falhou.');
    await driver.wait(until.elementLocated(By.css('h2')), 5000);
  }


  it('252 - Saldo atual é exibido com formato correto e cor verde se positivo', async () => {
    await abrirDetalhesConta('Conta 1');
    const saldoElement = await contaDetalhesPage.getSaldoAtual();
    const texto = await saldoElement.getText();
    const cor = await saldoElement.getCssValue('color');
    expect(texto.trim()).to.match(/^R\$ -?\d{1,3}(\.\d{3})*,\d{2}$/);
    expect(cor).to.match(greenColorRegex);
  });

  it('253 - Saldo atual exibe cor vermelha se saldo negativo', async () => {
    await abrirDetalhesConta('Conta 4');
    const saldoElement = await contaDetalhesPage.getSaldoAtual();
    const cor = await saldoElement.getCssValue('color');
    expect(cor).to.match(redColorRegex);
  });

  it('254 - Campos básicos da conta estão visíveis e corretos', async () => {
    await abrirDetalhesConta('Conta 1');
    const nome = await contaDetalhesPage.getNomeConta();
    const tipo = await contaDetalhesPage.getTipoConta();
    const usuario = await contaDetalhesPage.getUsuarioConta();
    const data = await contaDetalhesPage.getDataCriacao();
    expect(nome).to.not.be.empty;
    expect(tipo).to.contain('Conta Corrente');
    expect(usuario).to.not.be.empty;
    expect(data).to.not.be.empty;
  });

  it('255 - Validar valor Receitas com retorno da API', async () => {
    await abrirDetalhesConta('Conta 1');
    const contaId = (await driver.getCurrentUrl()).split('/').pop();
    const data = await driver.executeScript(async (url) => {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    }, `${baseUrl}/api/contas/${contaId}/totais`);
    const valorExibido = parseFloat((await (await driver.findElement(By.xpath("//div[contains(text(), 'Total de Receitas')]/following-sibling::div"))).getText()).replace(/[^\d,]/g, '').replace(',', '.'));
    expect(valorExibido).to.be.closeTo(data.total_receitas, 0.01);
  });

  it('256 - Validar valor Despesas com retorno da API', async () => {
    await abrirDetalhesConta('Conta 1');
    const contaId = (await driver.getCurrentUrl()).split('/').pop();
    const data = await driver.executeScript(async (url) => {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    }, `${baseUrl}/api/contas/${contaId}/totais`);
    const valorExibido = parseFloat((await (await driver.findElement(By.xpath("//div[contains(text(), 'Total de Despesas')]/following-sibling::div"))).getText()).replace(/[^\d,]/g, '').replace(',', '.'));
    expect(valorExibido).to.be.closeTo(data.total_despesas, 0.01);
  });

  it('257 - Validar Total de Movimentações com retorno da API', async () => {
    await abrirDetalhesConta('Conta 2');
    const contaId = (await driver.getCurrentUrl()).split('/').pop();
    const data = await driver.executeScript(async (url) => {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    }, `${baseUrl}/api/contas/${contaId}/totais`);
    const valorExibido = parseInt((await (await driver.findElement(By.xpath("//div[contains(text(), 'Total de Movimentações')]/following-sibling::div"))).getText()).replace(/[^\d]/g, ''), 10);
    expect(valorExibido).to.eq(data.total_movimentacoes);
  });

  it('258 - Validar Saldo Atual com base nos valores da API', async () => {
    await abrirDetalhesConta('Conta 2');
    const contaId = (await driver.getCurrentUrl()).split('/').pop();
    const data = await driver.executeScript(async (url) => {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    }, `${baseUrl}/api/contas/${contaId}/totais`);
    const saldoCalculado = data.total_receitas - data.total_despesas;
    const textoSaldo = await (await contaDetalhesPage.getSaldoAtual()).getText();
    const valorExibido = parseFloat(textoSaldo.replace('R$', '').replace(/\./g, '').replace(',', '.').trim());
    expect(valorExibido).to.be.closeTo(saldoCalculado, 0.01);
  });

  it('259 - Total de Receitas tem a cor verde', async () => {
    await abrirDetalhesConta('Conta 1');
    const cor = await (await driver.findElement(By.xpath("//div[contains(text(), 'Total de Receitas')]/following-sibling::div"))).getCssValue('color');
    expect(cor).to.match(greenColorRegex);
  });

  it('260 - Total de Despesas em vermelho', async () => {
    await abrirDetalhesConta('Conta 1');
    const cor = await (await driver.findElement(By.xpath("//div[contains(text(), 'Total de Despesas')]/following-sibling::div"))).getCssValue('color');
    expect(cor).to.match(redColorRegex);
  });

  it('261 - Saldo Total em vermelho', async () => {
    await abrirDetalhesConta('Conta 4');
    const cor = await (await contaDetalhesPage.getSaldoAtual()).getCssValue('color');
    expect(cor).to.match(redColorRegex);
  });

  it('262 - Valida a quantidade de movimentações por página (máx. 10)', async () => {
    await abrirDetalhesConta('Conta 1');
    const paginationLinks = await contaDetalhesPage.getPaginationLinks();
    const totalPaginas = paginationLinks.length > 0 ? paginationLinks.length : 1;
    if (totalPaginas > 1) {
      const rows = await contaDetalhesPage.getMovementRows();
      expect(rows.length).to.equal(10);
    }
  });

  it('263 - Valida a ordem decrescente das movimentações por data', async () => {
    await abrirDetalhesConta('Conta 1');
    const dateElements = await driver.findElements(By.css('table tbody tr td:first-child'));
    const dates = await Promise.all(dateElements.map(async el => new Date((await el.getText()).trim().split('/').reverse().join('-')).getTime()));
    for (let i = 0; i < dates.length - 1; i++) {
      expect(dates[i]).to.be.at.least(dates[i + 1]);
    }
  });

  it('264 - Valida os botões de paginação (Anterior / Próximo)', async () => {
    await abrirDetalhesConta('Conta 1');
    const previousButton = await contaDetalhesPage.getPreviousButton();
    expect(await contaDetalhesPage.isPaginationButtonDisabled(previousButton)).to.be.true;
    const nextButton = await contaDetalhesPage.getNextButton();
    if (nextButton) {
      await nextButton.click();
      await driver.wait(until.urlContains('page=2'), 5000);
      const previousButtonPage2 = await contaDetalhesPage.getPreviousButton();
      expect(await contaDetalhesPage.isPaginationButtonDisabled(previousButtonPage2)).to.be.false;
    }
  });

  it('265 - Situação tem cor verde para pago e amarelo para pendente', async () => {
    await abrirDetalhesConta('Conta 3');
    const rows = await driver.findElements(By.css('table tbody tr'));
    for (const row of rows) {
      const situacaoCell = await row.findElement(By.css('td:nth-child(5) span'));
      const situacaoText = (await situacaoCell.getText()).trim().toLowerCase();
      const color = await situacaoCell.getCssValue('color');
      if (situacaoText === 'pago') {
        expect(color).to.match(greenColorRegex);
      } else if (situacaoText === 'pendente') {
        expect(color).to.match(yellowColorRegex);
      }
    }
  });

  it('266 - Botão Editar está presente em cada movimentação com link correto', async () => {
    await abrirDetalhesConta('Conta 2');
    const rows = await driver.findElements(By.css('table tbody tr'));
    for (const row of rows) {
      const editButton = await row.findElement(By.css("td:last-child a.btn-warning"));
      expect(await editButton.getAttribute('href')).to.match(/\/movimentacao\/editar\/\d+/);
    }
  });

  it('267 - Exibe mensagem quando não há movimentações', async () => {
    await abrirDetalhesConta('Conta 5');
    const messageElement = await driver.findElement(By.xpath("//*[contains(text(), 'Nenhuma movimentação encontrada para esta conta.')]"));
    expect(await messageElement.isDisplayed()).to.be.true;
  });

  it('268 - Validar botão "Voltar para Contas"', async () => {
    await abrirDetalhesConta('Conta 1');
    const voltarBtn = await contaDetalhesPage.getVoltarParaContasButton();
    await voltarBtn.click();
    await driver.wait(until.urlContains('/contas'));
    const titulo = await driver.wait(
      until.elementLocated(By.xpath("//*[contains(text(), 'Contas Cadastradas')]")),
      8000,
      'Título "Contas Cadastradas" não encontrado'
    );

    expect(await titulo.isDisplayed()).to.be.true;
  });

  it('269 - Validar botão "Editar Conta"', async () => {
    await abrirDetalhesConta('Conta 1');
    await (await driver.findElement(By.xpath("//a[contains(text(), 'Editar Conta')]"))).click();
    await driver.wait(until.urlContains('/contas/editar/'), 5000);
    expect(await (await driver.findElement(By.xpath("//h2[contains(text(), 'Editar Conta')]"))).isDisplayed()).to.be.true;
  });

  it('270 - Validar botão "Editar Movimentação"', async () => {
    await abrirDetalhesConta('Conta 1');
    await (await driver.findElement(By.xpath("//table//a[contains(text(), 'Editar')]"))).click();
    await driver.wait(until.urlContains('/movimentacao/editar/'), 5000);
    expect(await (await driver.findElement(By.xpath("//h2[contains(text(), 'Editar Movimentação')]"))).isDisplayed()).to.be.true;
  });

  it('271 - Validar botão "Nova Movimentação"', async () => {
    await abrirDetalhesConta('Conta 1');
    await (await driver.findElement(By.css('a.btn-success[href="/movimentacao"]'))).click();
    await driver.wait(until.urlContains('/movimentacao'), 5000);
    expect(await (await driver.findElement(By.xpath("//h2[contains(text(), 'Criar Movimentação')]"))).isDisplayed()).to.be.true;
  });

  it('272 - Redireciona com mensagem se conta não pertence ao usuário', async () => {
    await driver.get(`${baseUrl}/contas/detalhes/9999`);
    await driver.wait(until.urlContains('/contas'), 5000);
    const errorMessage = await driver.findElement(By.xpath("//*[contains(text(), 'Conta não encontrada ou não pertence a você.')]"));
    expect(await errorMessage.isDisplayed()).to.be.true;
  });

  it('273 - Acesso bloqueado para usuários não autenticados', async () => {
    await driver.manage().deleteAllCookies();
    await driver.get(`${baseUrl}/contas/detalhes/1`);
    await driver.wait(until.urlContains('/login'), 5000);
    const messageElement = await driver.findElement(By.xpath("//*[contains(text(), 'Você precisa estar logado para acessar esta página.')]"));
    expect(await messageElement.isDisplayed()).to.be.true;
  });

  it('274 - Usuário não pode acessar conta de outro usuário', async () => {
    await driver.get(`${baseUrl}/contas/detalhes/5`);
    await driver.wait(until.urlContains('/contas'), 7000);
    const errorMessage = await driver.findElement(By.xpath("//*[contains(text(), 'Conta não encontrada ou não pertence a você.')]"));
    expect(await errorMessage.isDisplayed()).to.be.true;
  });

  it('275 - Formulários possuem token CSRF', async () => {
    await driver.get(`${baseUrl}/contas`);
    const csrfToken = await driver.wait(until.elementLocated(By.css('form input[name="csrf_token"]')), 5000);
    expect(await csrfToken.getAttribute('value')).to.not.be.empty;
  });

  it('276 - Campos estão escapados e sem vulnerabilidade XSS', async () => {
    await abrirDetalhesConta('Conta 4');
    const contaInfoGrid = await driver.findElement(By.css('.conta-info-grid'));
    const htmlContent = await contaInfoGrid.getAttribute('innerHTML');
    expect(htmlContent).to.not.include('<script>');
  });
});
