// e2e/conta_adicionar.spec.js
import { Builder, By, until } from 'selenium-webdriver';
import { expect } from 'chai';
import chrome from 'selenium-webdriver/chrome.js';
import LoginPage from '../support/page_objects/LoginPage.js';
import ContaAdicionarPage from '../support/page_objects/ContaAdicionarPage.js';

let driver;
let loginPage;
let contaAdicionarPage;

const baseUrl = 'http://localhost:5000';
const contaUsuario = {
  email: 'LoginPage@LoginPage.com',
  senha: 'login_10'
};

function gerarSufixo(length ) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

describe('ContaFácil - Página Adicionar Conta', () => {
  // --- CORREÇÃO: before() agora faz o setup completo, incluindo o login ---
  before(async () => {
    const options = new chrome.Options();
    options.addArguments('--start-maximized');
    driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build();

    loginPage = new LoginPage(driver, baseUrl);
    contaAdicionarPage = new ContaAdicionarPage(driver, baseUrl);

    // Faz o login UMA VEZ para toda a suíte de testes
    console.log('[before] Fazendo login para a suíte de testes...');
    await loginPage.login(contaUsuario.email, contaUsuario.senha);
    console.log('[before] Login concluído.');
  });

  // --- CORREÇÃO: beforeEach() agora só navega para a página ---
  beforeEach(async () => {
    // Navega para a página de adicionar conta antes de CADA teste
    console.log('[beforeEach] Navegando para /contas/adicionar...');
    await contaAdicionarPage.visit();
    console.log('[beforeEach] Página /contas/adicionar carregada.');
  });

  after(async () => {
    await driver.quit();
  });

  it('124 - Deve conter título da aba correto', async () => {
    const title = await driver.getTitle();
    expect(title).to.equal('ContaFácil - Adicionar Conta');
  });

  it('125 - Deve conter o título visível "Adicionar Conta"', async () => {
    const h2Text = await contaAdicionarPage.getPageTitleText();
    expect(h2Text).to.equal('Adicionar Conta');
  });

  it('126 - Deve conter um formulário com method POST', async () => {
    const formMethod = await contaAdicionarPage.getFormMethod();
    expect(formMethod.toLowerCase()).to.equal('post');
  });

  it('127 - Deve conter o campo oculto de CSRF Token', async () => {
    const csrfToken = await contaAdicionarPage.getCsrfTokenInput();
    expect(await csrfToken.getAttribute('name')).to.equal('csrf_token');
    expect(await csrfToken.getAttribute('type')).to.equal('hidden');
  });

  it('128 - Deve conter campo de nome com label correto', async () => {
    const labelText = await contaAdicionarPage.getNomeLabelText();
    const inputName = await contaAdicionarPage.getNomeInputName();
    expect(labelText).to.equal('Nome');
    expect(inputName).to.equal('nome');
  });

  it('129 - Deve permitir digitar no campo "nome"', async () => {
    const testName = 'Conta Corrente Teste';
    await contaAdicionarPage.typeNome(testName);
    const inputValue = await contaAdicionarPage.getNomeInputValue();
    expect(inputValue).to.equal(testName);
  });

  it('130 - Botão "Salvar" deve ser do tipo submit e visível', async () => {
    const salvarButton = await contaAdicionarPage.getSalvarButton();
    expect(await salvarButton.getText()).to.contain('Salvar');
    expect(await salvarButton.getAttribute('type')).to.equal('submit');
    expect(await salvarButton.isDisplayed()).to.be.true;
  });

  it('131 - Deve redirecionar para a Home ao clicar em "Cancelar"', async () => {
    const cancelarLink = await contaAdicionarPage.getCancelarLink();
    expect(await cancelarLink.getAttribute('href')).to.include('/home');
    await contaAdicionarPage.clickCancelar();
  });

it('132 - Deve exibir erro 400 se CSRF token estiver ausente (pela resposta)', async () => {
  await driver.get('http://localhost:5000/contas/adicionar');
  await driver.findElement(By.css('#nome')).sendKeys('Conta CSRF');

  await driver.executeScript(`
    document.querySelector('input[name="csrf_token"]').value = '';
    document.querySelector('form').submit();
  `);

  await driver.sleep(1000); // aguarda a resposta

  const url = await driver.getCurrentUrl();
  const bodyText = await driver.findElement(By.tagName('body')).getText();

  expect(url).to.include('/contas/adicionar');
  expect(bodyText).to.include('CSRF token is missing');
});

  it('133 - Deve ter estrutura semântica HTML correta (form, label, input)', async () => {
    const formElement = await driver.findElement(contaAdicionarPage.form);
    const labels = await formElement.findElements(By.css('label'));
    const inputs = await formElement.findElements(By.css('input'));
    expect(labels.length).to.be.at.least(1);
    expect(inputs.length).to.be.at.least(2);
  });

it('134 - Deve adicionar conta com exatamente 19 caracteres', async () => {
  const nomeBase = 'Conta com 16 cha'; // 16 + 3 = 19
  const nome19 = nomeBase + gerarSufixo(3);
  expect(nome19.length).to.equal(19);

  await contaAdicionarPage.typeNome(nome19);
  await contaAdicionarPage.clickSalvar();
  const flashMessageText = await contaAdicionarPage.getFlashMessageText();
  expect(flashMessageText).to.include('Conta adicionada com sucesso!');
  await driver.wait(until.urlContains('/contas'), 5000);
});

it('135 - Deve adicionar conta com exatamente 20 caracteres', async () => {
  const base = 'Conta com ';
  const sufixo = gerarSufixo(20 - base.length); // completa para 20
  const nome20 = base + sufixo;
  expect(nome20.length).to.equal(20);

  await contaAdicionarPage.typeNome(nome20);
  await contaAdicionarPage.clickSalvar();
  const flashMessageText = await contaAdicionarPage.getFlashMessageText();
  expect(flashMessageText).to.include('Conta adicionada com sucesso!');
  await driver.wait(until.urlContains('/contas'), 5000);
});

  it('136 - Deve exibir erro ao tentar adicionar conta com 21 caracteres', async () => {
    const nome21 = 'Conta com 21 chars '.padEnd(21, 'z');
    await contaAdicionarPage.typeNome(nome21);
    await contaAdicionarPage.clickSalvar();
    const flashMessageText = await contaAdicionarPage.getFlashMessageText();
    expect(flashMessageText).to.include('O nome da conta deve ter no máximo 20 caracteres.');
    await driver.wait(until.urlContains('/contas/adicionar'), 5000);
  });

  it('137 - Deve exibir erro ao tentar salvar conta com nome vazio', async () => {
    await contaAdicionarPage.typeNome('');
    await contaAdicionarPage.clickSalvar();
    const flashMessageText = await contaAdicionarPage.getFlashMessageText();
    expect(flashMessageText).to.include('O nome da conta é obrigatório.');
    await driver.wait(until.urlContains('/contas/adicionar'), 5000);
  });

  it('138 - Não deve cadastrar nome de conta repetida', async () => {
    const nomeDuplicado = `Conta Dup. ${gerarSufixo(5)}`;
    await contaAdicionarPage.typeNome(nomeDuplicado);
    await contaAdicionarPage.clickSalvar();
    await driver.wait(until.urlContains('/contas'), 5000);
    await contaAdicionarPage.visit();
    await contaAdicionarPage.typeNome(nomeDuplicado);
    await contaAdicionarPage.clickSalvar();
    const flashMessageText = await contaAdicionarPage.getFlashMessageText();
    expect(flashMessageText).to.include('Já existe uma conta com esse nome.');
    await driver.wait(until.urlContains('/contas/adicionar'), 5000);
  });
});
