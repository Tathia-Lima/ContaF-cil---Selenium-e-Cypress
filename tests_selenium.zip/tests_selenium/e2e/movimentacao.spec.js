// e2e/movimentacao.spec.js
import { Builder, By, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';
import moment from 'moment';

import LoginPage from '../support/page_objects/LoginPage.js';
import MovimentacaoPage from '../support/page_objects/MovimentacaoPage.js';
import ResumoPage from '../support/page_objects/ResumoPage.js';

const baseUrl = 'http://localhost:5000';
const user = { email: 'movimentacao@movimentacao.com', senha: 'login_10' };
const userWithoutAccount = { email: 'semconta@teste.com', senha: 'login_10' };

let driver;
let loginPage;
let movimentacaoPage;
let resumoPage;

describe('Criação de Movimentações - Testes Funcionais', function( ) {
  this.timeout(300000); // 5 minutos para a suíte completa

  before(async () => {
    driver = await new Builder().forBrowser('chrome').build();
    loginPage = new LoginPage(driver, baseUrl);
    movimentacaoPage = new MovimentacaoPage(driver, baseUrl);
    resumoPage = new ResumoPage(driver, baseUrl);
  });

  after(async () => {
    if (driver) await driver.quit();
  });

  beforeEach(async function() {
    this.timeout(30000);
    await driver.manage().deleteAllCookies();
    await loginPage.login(user.email, user.senha);
    await driver.wait(until.urlContains('/home'), 15000);
    // *** GARANTE UM FORMULÁRIO LIMPO PARA CADA TESTE ***
    await movimentacaoPage.visitar();
  });

  const today = moment();
  const dataMovimentacaoBase = today.clone().subtract(5, 'days').format('YYYY-MM-DD');
  const dataPagamentoBase = today.clone().subtract(4, 'days').format('YYYY-MM-DD');

  const dadosBase = {
    tipo: 'receita',
    dataMovimentacao: dataMovimentacaoBase,
    dataPagamento: dataPagamentoBase,
    descricao: 'Descrição Padrão',
    valor: 100,
    conta: 'Conta 1',
    situacao: 'pago'
  };

  it('173 - Deve exibir todos os campos obrigatórios', async () => {
    const form = await driver.findElement(By.css('form'));
    expect(await form.findElement(movimentacaoPage.tipoSelect)).to.exist;
  });

  async function validarCampoObrigatorio(campo, mensagemErro) {
    const dadosTeste = { ...dadosBase };
    dadosTeste[campo] = null;
    await movimentacaoPage.preencherFormulario(dadosTeste);
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText(mensagemErro);
    expect(await alert.isDisplayed()).to.be.true;
  }

  it('174 - Deve validar que o campo "Tipo da Movimentação" é obrigatório', async () => {
    await validarCampoObrigatorio('tipo', 'Selecione o tipo de movimentação.');
  });

  it('175 - Deve validar que o campo "Data da Movimentação" é obrigatório', async () => {
    await validarCampoObrigatorio('dataMovimentacao', 'Informe a data da movimentação.');
  });

  it('176 - Deve validar que o campo "Data do Pagamento" é obrigatório', async () => {
    await validarCampoObrigatorio('dataPagamento', 'Informe a data de pagamento.');
  });

  it('177 - Deve validar que o campo "Descrição" é obrigatório', async () => {
    await validarCampoObrigatorio('descricao', 'Descrição é obrigatória.');
  });

  it('178 - Deve validar que o campo "Valor" é obrigatório', async () => {
    await validarCampoObrigatorio('valor', 'Informe um valor.');
  });

  it('179 - Deve validar que o campo "Conta" é obrigatório', async () => {
    await validarCampoObrigatorio('conta', 'Você precisa selecionar uma conta.');
  });

  it('180 - Deve validar que o campo "Situação" é obrigatório', async () => {
    await validarCampoObrigatorio('situacao', 'Selecione a situação da movimentação.');
  });

  it('181 - Deve validar valor não numérico', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, valor: 'abc' });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('Valor inválido.');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('182 - Deve criar receita com sucesso', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, descricao: 'Venda de produto bem sucedida' });
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);
    const alert = await resumoPage.findElementWithText('Receita incluída com sucesso!');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('183 - Deve manter valores preenchidos após erro de validação', async () => {
    await movimentacaoPage.preencherFormulario({ descricao: 'Teste erro' });
    await movimentacaoPage.submeter();
    const descricaoInput = await driver.findElement(movimentacaoPage.descricaoInput);
    expect(await descricaoInput.getAttribute('value')).to.equal('Teste erro');
  });

  it('184 - Deve aceitar valor mínimo 0.01', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, valor: 0.01 });
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);
    const alert = await resumoPage.findElementWithText('Receita incluída com sucesso!');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('185 - Deve rejeitar valor menor que 0.01', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, valor: 0.009 });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('O valor deve ser maior ou igual a 0.01.');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('186 - Deve impedir valor zero', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, valor: 0 });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('O valor deve ser maior ou igual a 0.01.');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('187 - Deve permitir descrição com caracteres especiais', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, descricao: '!%&@#()[]{} - Teste' });
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);
    const alert = await resumoPage.findElementWithText('Receita incluída com sucesso!');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('188 - Deve permitir campo "Interessado" opcional (vazio)', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, interessado: '' });
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);
    const alert = await resumoPage.findElementWithText('Receita incluída com sucesso!');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('189 - Deve validar que data de pagamento não pode ser anterior à movimentação', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, dataMovimentacao: today.format('YYYY-MM-DD'), dataPagamento: today.clone().subtract(1, 'days').format('YYYY-MM-DD') });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('Para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento.');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('190 - Não deve ter nenhuma opção de "Situação" selecionada por padrão', async () => {
    const pagoChecked = await driver.findElement(movimentacaoPage.situacaoPagoRadio).isSelected();
    const pendenteChecked = await driver.findElement(movimentacaoPage.situacaoPendenteRadio).isSelected();
    expect(pagoChecked).to.be.false;
    expect(pendenteChecked).to.be.false;
  });

  it('191 - Deve manter "pendente" marcado ao submeter e falhar', async () => {
    await movimentacaoPage.preencherFormulario({ situacao: 'pendente' });
    await movimentacaoPage.submeter();
    const pendenteChecked = await driver.findElement(movimentacaoPage.situacaoPendenteRadio).isSelected();
    expect(pendenteChecked).to.be.true;
  });

  it('192 - Deve permitir descrição com até 30 caracteres', async () => {
    const descricao30Chars = 'A'.repeat(30);
    await movimentacaoPage.preencherFormulario({ ...dadosBase, descricao: descricao30Chars });
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);
    await resumoPage.filtrarPor(today.clone().subtract(5, 'days').month() + 1, today.clone().subtract(5, 'days').year());
    const cell = await resumoPage.findElementWithText(descricao30Chars);
    expect(await cell.isDisplayed()).to.be.true;
  });

  it('193 - Não deve permitir descrição com 31 caracteres', async () => {
    const descricao31Chars = 'A'.repeat(31);
    await movimentacaoPage.preencherFormulario({ ...dadosBase, descricao: descricao31Chars });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('Descrição deve ter no máximo 30 caracteres.');
    expect(await alert.isDisplayed()).to.be.true;
    expect(await driver.getCurrentUrl()).to.include('/movimentacao');
  });

  it('194 - Deve permitir descrição com 29 caracteres', async () => {
    const descricao29Chars = 'A'.repeat(29);
    await movimentacaoPage.preencherFormulario({ ...dadosBase, descricao: descricao29Chars });
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);
    await resumoPage.filtrarPor(today.clone().subtract(5, 'days').month() + 1, today.clone().subtract(5, 'days').year());
    const cell = await resumoPage.findElementWithText(descricao29Chars);
    expect(await cell.isDisplayed()).to.be.true;
  });

  it('195 - Deve redirecionar para Home ao clicar em Cancelar', async () => {
    await driver.findElement(movimentacaoPage.cancelButton).click();
    await driver.wait(until.urlContains('/home'), 10000);
    expect(await driver.getCurrentUrl()).to.include('/home');
  });

  it('196 - Deve exibir erro ao criar movimentação sem conta cadastrada', async () => {
    await driver.get(`${baseUrl}/logout`);
    await driver.wait(until.urlContains('/login'));
    await loginPage.login(userWithoutAccount.email, userWithoutAccount.senha);
    await driver.wait(until.urlContains('/home'));
    await movimentacaoPage.visitar();
    const alert = await movimentacaoPage.findElementWithText('Você precisa cadastrar uma conta antes de criar movimentações.');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('197 - Deve validar que para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento', async () => {
    await movimentacaoPage.preencherFormulario({ ...dadosBase, dataMovimentacao: today.format('YYYY-MM-DD'), dataPagamento: today.clone().subtract(1, 'days').format('YYYY-MM-DD') });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('Para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento.');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('198 - Deve validar que para movimentações pagas, a data de pagamento não pode ser no futuro', async () => {
    const dataHoje = today.format('YYYY-MM-DD');
    const dataAmanha = today.clone().add(1, 'days').format('YYYY-MM-DD');
    await movimentacaoPage.preencherFormulario({ ...dadosBase, dataMovimentacao: dataHoje, dataPagamento: dataAmanha });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('A data de pagamento deve estar entre');
    expect(await alert.isDisplayed()).to.be.true;
  });

  it('199 - Deve validar que para movimentações pendentes, a data de pagamento não pode ser no passado', async () => {
    const dataHoje = today.format('YYYY-MM-DD');
    const dataOntem = today.clone().subtract(1, 'days').format('YYYY-MM-DD');
    await movimentacaoPage.preencherFormulario({ ...dadosBase, tipo: 'despesa', situacao: 'pendente', dataPagamento: dataOntem });
    await movimentacaoPage.submeter();
    const alert = await movimentacaoPage.findElementWithText('Para movimentações pendentes, a data de pagamento não pode ser no passado.');
    expect(await alert.isDisplayed()).to.be.true;
  });

it('200 - Deve prevenir XSS no campo Descrição', async () => {
    const xssPayload = '<img src=x onerror=alert(1)>';
    const escapedXssPayload = '&lt;img src=x onerror=alert(1)&gt;';
    const valorUnico = '100,99';
    const dataMovimentacao = '2025-07-02';

    // --- ETAPA 1: Preparação ---
    await driver.get(`${baseUrl}/clean-xss-payloads`);
    await driver.wait(until.urlContains('/resumo'), 10000);
    await movimentacaoPage.visitar();

    // --- ETAPA 2: Ação ---
    await movimentacaoPage.preencherFormulario({
      tipo: 'receita',
      dataMovimentacao: dataMovimentacao,
      dataPagamento: dataMovimentacao,
      descricao: xssPayload,
      valor: 100.99,
      conta: 'Conta 1',
      situacao: 'pago'
    });
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);

    // --- ETAPA 3: Validação (ORDEM CORRIGIDA) ---

    // **VALIDAÇÃO 3 (MOVIDA PARA CIMA):** Valida a mensagem de sucesso ANTES de qualquer outra ação.
    const alert = await resumoPage.findElementWithText('Receita incluída com sucesso!');
    const alertText = await alert.getText();
    expect(alertText).to.not.include(xssPayload);
    expect(await alert.isDisplayed()).to.be.true; // Garante que a mensagem apareceu.

    // **VALIDAÇÃO 1:** O HTML da página inteira não deve conter a tag <img> executável.
    const pageHtml = await driver.getPageSource();
    expect(pageHtml).to.not.include(xssPayload);

    // **VALIDAÇÃO 2:** Encontrar a linha correta na tabela e validar seu conteúdo.
    const [ano, mes] = dataMovimentacao.split('-');
    await resumoPage.filtrarPor(parseInt(mes), ano);

    const linhas = await resumoPage.getLinhasTabela();
    let linhaEncontrada = null;

    for (const linha of linhas) {
      const textoLinha = await linha.getText();
      if (textoLinha.includes(xssPayload) && textoLinha.includes(valorUnico)) {
        linhaEncontrada = linha;
        break;
      }
    }

    expect(linhaEncontrada, `A linha com a descrição "${xssPayload}" e valor "${valorUnico}" não foi encontrada.`).to.not.be.null;

    const primeiraCelula = await linhaEncontrada.findElement(By.css('td:first-child'));
    const htmlPrimeiraCelula = await primeiraCelula.getAttribute('innerHTML');
    expect(htmlPrimeiraCelula.trim()).to.equal(escapedXssPayload);

    const textoPrimeiraCelula = await primeiraCelula.getText();
    expect(textoPrimeiraCelula.trim()).to.equal(xssPayload);
});
  it('201 - Deve redirecionar para login se tentar acessar movimentacao após logout', async () => {
    await driver.get(`${baseUrl}/logout`);
    await driver.wait(until.urlContains('/login'), 10000);
    await movimentacaoPage.visitar();
    await driver.wait(until.urlContains('/login'), 10000);
    const alertText = await loginPage.getAlertMessageText();
    expect(alertText).to.include('Você precisa estar logado para acessar esta página.');
  });
});
