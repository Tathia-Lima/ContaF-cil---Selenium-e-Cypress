import { Builder, By, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';

import LoginPage from '../support/page_objects/LoginPage.js'; // Assumindo que você já tem este
import HomePage from '../support/page_objects/HomePage.js';

const baseUrl = 'http://localhost:5000';
const userWithAccounts = { email: 'conta@conta.com', senha: 'login_10' }; // Usuário com contas
const userWithoutAccounts = { email: 'home@home.com', senha: 'login_10' }; // Usuário sem contas


let driver;
let loginPage;
let homePage;


// Cores (diretamente como strings RGB, conforme sua solução Cypress )
const redColor = 'rgba(255, 36, 0, 1)';
const greenColor = 'rgba(0, 255, 0, 1)';
const defaultTextColor = 'rgb(255, 255, 255, 1)';

// Função auxiliar para parsear valores monetários
function parseMonetaryValue(text) {
  // Remove "R$", espaços, pontos de milhar e substitui vírgula decimal por ponto
  return parseFloat(text.replace(/[R$\s-]/g, '').replace(/\./g, '').replace(',', '.'));
}

describe('ContaFácil - Home', () => {
  before(async () => {
    const options = new chrome.Options();
    options.addArguments('--start-maximized');
    driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build();

    loginPage = new LoginPage(driver, baseUrl);
    homePage = new HomePage(driver, baseUrl);
  });

  after(async () => {
    await driver.quit();
  });

  // Describe para testes com usuário que possui contas
  describe('Testes com usuário que possui contas', () => {
    beforeEach(async () => {
      await loginPage.login(userWithAccounts.email, userWithAccounts.senha);
      await homePage.navigateToHome();
    });

    // Validações principais de textos e hierarquia (65 - 75)
    it('65 - Deve conter título da aba correto', async () => {
      expect(await homePage.getPageTitle()).to.equal('ContaFácil - Home');
    });

    it('66 - Deve conter um h1 com texto exato', async () => {
      expect(await homePage.getH1Text()).to.equal('ContaFácil - Página Inicial');
    });

    it('67 - Deve conter h2 com saudação contendo o nome do usuário', async () => {
      const h2Text = await homePage.getH2Text();
      expect(h2Text).to.match(/^Olá, .+! Seja bem-vindo\(a\) ao ContaFácil\.$/);
    });

    it('68 - Deve conter parágrafo explicativo com texto esperado', async () => {
      expect(await homePage.getPExplanationText()).to.equal('Aqui você pode gerenciar facilmente suas finanças e acompanhar o saldo das suas contas.');
    });

    it('69 - Deve conter h3 com o texto "Saldo das suas contas"', async () => {
      expect(await homePage.getH3SectionTitleText()).to.equal('Saldo das suas contas');
    });

    // Validações da tabela de contas (70 - 80)
    it('70 - A tabela deve ter a classe "table" e atributo aria-label correto', async () => {
      const table = await homePage.getTable();
      expect(await table.getAttribute('class')).to.include('table');
      expect(await table.getAttribute('aria-label')).to.equal('Tabela de saldos das contas do usuário');
    });

    it('71 - A tabela deve conter cabeçalhos "Conta", "Despesas", "Receitas" e "Saldo"', async () => {
      const headers = await homePage.getTableHeaders();
      expect(await headers[0].getText()).to.equal('Conta');
      expect(await headers[1].getText()).to.equal('Receitas');
      expect(await headers[2].getText()).to.equal('Despesas');
      expect(await headers[3].getText()).to.equal('Saldo');
      expect(await headers[4].getText()).to.equal('Ações'); // Adicionado 'Ações' conforme seu HTML
    });

    it('72 - Cada linha de conta deve conter link com tabindex=0 e nome da conta não vazio', async () => {
      const rows = await homePage.getTableRows();
      for (const row of rows) {
        const isSaldoTotal = await row.getAttribute('class').then(cls => cls.includes('saldo-total')).catch(() => false);
        const cells = await row.findElements(By.css('td'));

        if (!isSaldoTotal && cells.length > 1 && !(await cells[0].getAttribute('colspan'))) {
          const link = await cells[0].findElement(By.css('a'));
          expect(await link.getAttribute('tabindex')).to.equal('0');
          expect(await link.getText()).to.not.be.empty;
        }
      }
    });

it('73 - Os saldos devem estar no formato PT-BR, ex: R$ 1.234,56', async () => {
  const saldoRegex = /^R\$ -?\s?\d{1,3}(\.\d{3})*,\d{2}$/;
  const rows = await homePage.getTableRows();

  for (const row of rows) {
    const isSaldoTotal = await row.getAttribute('class')
      .then(cls => cls.includes('saldo-total'))
      .catch(() => false);
    const cells = await row.findElements(By.css('td'));

    if (!isSaldoTotal && cells.length > 1 && !(await cells[0].getAttribute('colspan'))) {
      const receitasText = await cells[1].getText();
      const despesasText = await cells[2].getText();
      const saldoText = await cells[3].getText();

      expect(receitasText.trim()).to.match(saldoRegex);
      expect(despesasText.trim()).to.match(/^R\$ -?\s?\d{1,3}(\.\d{3})*,\d{2}$|^R\$ 0,00$/);
      expect(saldoText.trim()).to.match(saldoRegex);
    }
  }
});

    // Acessibilidade e atributos (75 - 79)
    it('75 - Links dos nomes das contas devem ter tabindex=0', async () => {
      const rows = await homePage.getTableRows();
      for (const row of rows) {
        const isSaldoTotal = await row.getAttribute('class').then(cls => cls.includes('saldo-total')).catch(() => false);
        const cells = await row.findElements(By.css('td'));

        if (!isSaldoTotal && cells.length > 1 && !(await cells[0].getAttribute('colspan'))) {
          const link = await cells[0].findElement(By.css('a'));
          expect(await link.getAttribute('tabindex')).to.equal('0');
        }
      }
    });

    it('76 - Deve existir exatamente um elemento main na página', async () => {
      const mainElements = await driver.findElements(By.css('main'));
      expect(mainElements).to.have.lengthOf(1);
    });

    it('77 - Deve garantir hierarquia correta de títulos (h1, depois h2, depois h3)', async () => {
      const mainElement = await driver.findElement(By.css('main'));
      expect(await mainElement.findElement(By.css('h1'))).to.exist;
      expect(await mainElement.findElement(By.css('h2'))).to.exist;
      expect(await mainElement.findElement(By.css('h3'))).to.exist;
    });

    it('78 - A tabela deve ter os cabeçalhos com scope="col"', async () => {
      const headers = await homePage.getTableHeaders();
      for (const header of headers) {
        expect(await header.getAttribute('scope')).to.equal('col');
      }
    });

    it('79 - A linha de saldo total deve estar estilizada em negrito', async () => {
      const saldoTotalRow = await homePage.getSaldoTotalRow();
      const fontWeight = await saldoTotalRow.getCssValue('font-weight');
      expect(['700', 'bold']).to.include(fontWeight);
    });

    it('81 - Deve exibir múltiplas contas e saldo total correto', async () => {
      const saldoTotalRow = await homePage.getSaldoTotalRow();
      expect(saldoTotalRow).to.exist;

      // Verifica que a primeira célula da linha "Total" contenha o texto "Total"
      const labelText = await homePage.getCellText(saldoTotalRow, 0);
      expect(labelText.trim()).to.equal('Total');

      // Pega o texto do saldo total (coluna 3)
      const totalText = await homePage.getCellText(saldoTotalRow, 3);

      // Verifica o formato PT-BR do valor (ex: R$ 11.852,25 ou R$ - 900,00)
      expect(totalText.trim()).to.match(/^R\$ -?\s?\d{1,3}(\.\d{3})*,\d{2}$/);

      // Converte para número para verificar a classe CSS adequada
      const valorNumerico = parseMonetaryValue(totalText);

      // Verifica a classe CSS da célula do saldo total (coluna 3)
      const saldoTotalCell = (await saldoTotalRow.findElements(By.css('td')))[3];
      const classAttr = await saldoTotalCell.getAttribute('class');

      if (valorNumerico >= 0) {
        expect(classAttr).to.include('positive-value');
      } else {
        expect(classAttr).to.include('negative-value');
      }
    });


    it('82 - Deve validar a soma total das receitas', async () => {
      let somaReceitas = 0;
      const rows = await homePage.getTableRows();

      for (const row of rows) {
        const isSaldoTotal = await row.getAttribute('class').then(cls => cls.includes('saldo-total')).catch(() => false);
        const cells = await row.findElements(By.css('td'));

        if (!isSaldoTotal && cells.length > 1 && !(await cells[0].getAttribute('colspan'))) {
          const receitasText = await cells[1].getText();
          somaReceitas += parseMonetaryValue(receitasText);
        }
      }

      const saldoTotalRow = await homePage.getSaldoTotalRow();
      const totalText = await homePage.getCellText(saldoTotalRow, 1);
      const total = parseMonetaryValue(totalText);

      expect(total).to.be.closeTo(somaReceitas, 0.01);
    });

    it('83 - Deve validar a soma total das despesas', async () => {
      let somaDespesas = 0;
      const rows = await homePage.getTableRows();

      for (const row of rows) {
        const isSaldoTotal = await row.getAttribute('class').then(cls => cls.includes('saldo-total')).catch(() => false);
        const cells = await row.findElements(By.css('td'));

        if (!isSaldoTotal && cells.length > 1 && !(await cells[0].getAttribute('colspan'))) {
          const despesasText = await cells[2].getText();
          somaDespesas += parseMonetaryValue(despesasText);
        }
      }

      const saldoTotalRow = await homePage.getSaldoTotalRow();
      const totalText = await homePage.getCellText(saldoTotalRow, 2);
      const total = parseMonetaryValue(totalText);

      expect(total).to.be.closeTo(somaDespesas, 0.01);
    });

    it('84 - Deve validar que o saldo total é a diferença entre receitas e despesas', async () => {
      let receitas = 0;
      let despesas = 0;
      const rows = await homePage.getTableRows();

      for (const row of rows) {
        const isSaldoTotal = await row.getAttribute('class').then(cls => cls.includes('saldo-total')).catch(() => false);
        const cells = await row.findElements(By.css('td'));

        if (!isSaldoTotal && cells.length > 1 && !(await cells[0].getAttribute('colspan'))) {
          receitas += parseMonetaryValue(await cells[1].getText());
          despesas += parseMonetaryValue(await cells[2].getText());
        }
      }

      const saldoEsperado = receitas - despesas;
      const saldoTotalRow = await homePage.getSaldoTotalRow();
      const textSaldo = await homePage.getCellText(saldoTotalRow, 3);
      const saldoTotal = parseMonetaryValue(textSaldo);

      // O Cypress usava includes('-') para verificar o sinal.
      // No Selenium, parseMonetaryValue já retorna o valor absoluto, então comparamos com o esperado.
      // Se o saldo esperado for negativo, o parseMonetaryValue do total também será negativo.
      expect(saldoTotal).to.be.closeTo(saldoEsperado, 0.01);
    });

    it('220 - Deve redirecionar para a página de detalhes da conta ao clicar no link', async () => {
      // Pega o primeiro link do nome da conta
      const firstAccountLink = await driver.findElement(By.css('table tbody tr td:first-child a'));
      await driver.wait(until.elementIsVisible(firstAccountLink), 5000);

      const href = await firstAccountLink.getAttribute('href');

      // Remove o atributo target="_blank" para que o Selenium navegue na mesma aba
      await driver.executeScript("arguments[0].removeAttribute('target')", firstAccountLink);

      await firstAccountLink.click();

      await driver.wait(until.urlContains('/contas/detalhes/'), 10000);
      expect(await driver.getCurrentUrl()).to.include(href);

      const h2 = await driver.findElement(By.css('h2'));
      expect(await h2.getText()).to.include('Detalhes da Conta');
    });

    it('221 - Despesa de conta específica deve ser exibida em vermelho', async () => {
      const accountRow = await homePage.getAccountRow('Conta 2');
      const despesasCell = await homePage.getCellElement(accountRow, 2); // Coluna de Despesas

      expect(await despesasCell.getText()).to.include('R$ -');
      expect(await despesasCell.getAttribute('class')).to.include('negative-value');
      expect(await despesasCell.getCssValue('color')).to.equal(redColor);
    });

    it('222 - Saldo negativo de conta específica deve ser exibido em vermelho', async () => {
      const accountRow = await homePage.getAccountRow('Conta 2');
      const saldoCell = await homePage.getCellElement(accountRow, 3); // Coluna de Saldo

      expect(await saldoCell.getText()).to.include('R$ -');
      expect(await saldoCell.getAttribute('class')).to.include('negative-value');
      expect(await saldoCell.getCssValue('color')).to.equal(redColor);
    });

    it('223 - Saldo positivo de conta específica deve ser exibido em verde', async () => {
      const accountRow = await homePage.getAccountRow('Conta 1');
      const saldoCell = await homePage.getCellElement(accountRow, 3); // Coluna de Saldo

      expect(await saldoCell.getText()).to.not.include('R$ -');
      expect(await saldoCell.getAttribute('class')).to.include('positive-value');
      expect(await saldoCell.getCssValue('color')).to.equal(greenColor);
    });

    it('224 - Despesas totais devem ser exibidas em vermelho se houver valor', async () => {
      const saldoTotalRow = await homePage.getSaldoTotalRow();
      const despesasTotalCell = await homePage.getCellElement(saldoTotalRow, 2); // Coluna de Despesas Total

      const text = await despesasTotalCell.getText();
      const value = parseMonetaryValue(text);

      if (value > 0) {
        expect(await despesasTotalCell.getAttribute('class')).to.include('negative-value');
        expect(await despesasTotalCell.getCssValue('color')).to.equal(redColor);
      } else {
        expect(await despesasTotalCell.getAttribute('class')).to.not.include('negative-value');
        expect(await despesasTotalCell.getCssValue('color')).to.equal(defaultTextColor);
      }
    });

    it('225 - Saldo total negativo deve ser exibido em vermelho', async () => {
      const saldoTotalRow = await homePage.getSaldoTotalRow();
      const saldoTotalCell = await homePage.getCellElement(saldoTotalRow, 3); // Coluna de Saldo Total

      const text = await saldoTotalCell.getText();
      if (text.includes('-')) {
        expect(await saldoTotalCell.getAttribute('class')).to.include('negative-value');
        expect(await saldoTotalCell.getCssValue('color')).to.equal(redColor);
      } else {
        expect(await saldoTotalCell.getAttribute('class')).to.not.include('negative-value');
        expect(await saldoTotalCell.getCssValue('color')).to.equal(greenColor);
      }
    });

    it('226 - Saldo total positivo deve ser exibido em verde', async () => {
      const saldoTotalRow = await homePage.getSaldoTotalRow();
      const saldoTotalCell = await homePage.getCellElement(saldoTotalRow, 3); // Coluna de Saldo Total

      const text = await saldoTotalCell.getText();
      if (!text.includes('-')) {
        expect(await saldoTotalCell.getAttribute('class')).to.include('positive-value');
        expect(await saldoTotalCell.getCssValue('color')).to.equal(greenColor);
      } else {
        expect(await saldoTotalCell.getAttribute('class')).to.not.include('positive-value');
        expect(await saldoTotalCell.getCssValue('color')).to.equal(redColor);
      }
    });
  });

  // Describe para testes com usuário que NÃO possui contas
  describe('Testes com usuário que NÃO possui contas', () => {
    beforeEach(async () => {
      await loginPage.login(userWithoutAccounts.email, userWithoutAccounts.senha);
      await homePage.navigateToHome();
    });

    it('74 - Deve mostrar mensagem "Nenhuma conta cadastrada ainda." caso não haja contas', async () => {
      const rows = await homePage.getTableRows();

      if (rows.length === 1) { // Apenas a linha da mensagem
        const messageElement = await driver.findElement(By.css('table tbody tr td[colspan="5"]'));
        const messageText = await messageElement.getText();
        expect(messageText).to.equal('Nenhuma conta cadastrada ainda.');
      } else {
        throw new Error('Esperado usuário sem contas, mas contas foram encontradas.');
      }
    });


    it('80 - Deve exibir linha de saldo total somente se houver contas, senão mensagem adequada', async () => {
      // Busca todas as linhas da tabela
      const rows = await homePage.getTableRows();

      // Tenta localizar a linha de saldo total
      const saldoTotalRows = await driver.findElements(By.css('tr.saldo-total'));

      if (saldoTotalRows.length > 0) {
        // Deve haver pelo menos uma linha de conta + uma de total
        expect(rows.length).to.be.greaterThan(1);

        const saldoTotalRow = saldoTotalRows[0];
        const primeiraCelula = await saldoTotalRow.findElement(By.css('td'));

        // Confirma que a linha de total começa com "Total"
        const textoCelula = await primeiraCelula.getText();
        expect(textoCelula).to.equal('Total');

        // Verifica que o valor de saldo está no formato correto
        const saldoTotalCells = await saldoTotalRow.findElements(By.css('td'));
        const textoSaldo = await saldoTotalCells[3].getText();
        expect(textoSaldo.trim()).to.match(/^R\$ -?\s?\d{1,3}(\.\d{3})*,\d{2}$/);

      } 
    });
  });
});
