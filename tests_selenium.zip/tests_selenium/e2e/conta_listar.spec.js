// Arquivo: conta_listar_selenium.spec.js

import { Builder, By, Key, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';

let driver;
let nomeConta = 'Conta adicionada';

async function login(email, senha) {
  await driver.get('http://localhost:5000/login');
  await driver.findElement(By.name('email')).sendKeys(email);
  await driver.findElement(By.name('senha')).sendKeys(senha, Key.RETURN);
  await driver.wait(until.urlContains('/home'), 5000);
}

describe('ContaFácil - Página Listar Conta', function () {
  this.timeout(50000);

  beforeEach(async () => {
    driver = await new Builder().forBrowser('chrome').setChromeOptions(new chrome.Options()).build();
    await login('contalistar@contalistar.com', 'login_10');
    await driver.get('http://localhost:5000/contas');
  });

  afterEach(async () => {
    await driver.quit();
  });


  it('148 - Deve exibir título e botão "Adicionar Conta"', async () => {
    const titulo = await driver.findElement(By.css('h1')).getText();
    expect(titulo).to.include('Contas Cadastradas');

    const botaoAdicionar = await driver.findElement(By.css('a.btn-success')).getText();
    expect(botaoAdicionar).to.include('Adicionar Conta');
  });

  it('149 - Deve exibir tabela com cabeçalhos "Conta" e "Ações"', async () => {
    const ths = await driver.findElements(By.css('thead tr th'));
    expect(await ths[0].getText()).to.include('Conta');
    expect(await ths[1].getText()).to.include('Ações');
  });

  it('150 - Deve validar a mensagem: Nenhuma conta cadastrada.', async () => {
    const rows = await driver.findElements(By.css('tbody tr'));
    if (rows.length === 1) {
      const texto = await rows[0].getText();
      expect(texto).to.include('Nenhuma conta cadastrada');
    } else {
      for (const row of rows) {
        const cell = await row.findElement(By.css('td'));
        const texto = await cell.getText();
        expect(texto).to.not.equal('');
      }
    }
  });

  it('151 - Deve adicionar conta', async () => {
    await driver.findElement(By.css('a.btn-success')).click();
    await driver.wait(until.urlContains('/contas/adicionar'), 5000);

    await driver.findElement(By.name('nome')).clear();
    await driver.findElement(By.name('nome')).sendKeys(nomeConta);
    await driver.findElement(By.css('button[type="submit"]')).click();

    await driver.wait(until.urlContains('/contas'), 5000);
    const mensagem = await driver.findElement(By.css('.alert-success')).getText();
    expect(mensagem).to.include('Conta adicionada com sucesso!');

    const contaCriada = await driver.findElement(By.xpath(`//td[text()='${nomeConta}']`));
    expect(contaCriada).to.exist;
  });

  it('152 - Não deve permitir duplicar nome de conta já existente', async () => {
    // Navega para a página de adicionar conta
    await driver.findElement(By.css('a.btn-success')).click();
    await driver.wait(until.urlContains('/contas/adicionar'), 5000);

    // Tenta adicionar a mesma conta novamente
    await driver.findElement(By.name('nome')).clear();
    await driver.findElement(By.name('nome')).sendKeys(nomeConta);
    await driver.findElement(By.css('button[type="submit"]')).click();

    // *** CORREÇÃO APLICADA AQUI: Mudando de .alert-danger para .alert-warning ***
    // O código Flask e o template base.html confirmam que a mensagem de duplicidade
    // é um "warning", não um "danger".
    await driver.wait(until.elementLocated(By.css('.alert-warning')), 5000);
    const erro = await driver.findElement(By.css('.alert-warning')).getText();
    expect(erro).to.include('Já existe uma conta com esse nome');
    await driver.wait(until.urlContains('/contas/adicionar')); 
  });

  it('153 - Cada conta listada deve conter botões de Detalhes, Editar e Excluir', async () => {
    const linhas = await driver.findElements(By.css('tbody tr'));
    for (let linha of linhas) {
      const texto = await linha.getText();
      if (!texto.includes('Nenhuma conta cadastrada')) {
        const detalhes = await linha.findElement(By.css('a.btn-primary')).getText();
        const editar = await linha.findElement(By.css('a.btn-warning')).getText();
        const excluir = await linha.findElement(By.css('button.btn-danger')).getText();
        expect(detalhes).to.include('Detalhes');
        expect(editar).to.include('Editar');
        expect(excluir).to.include('Excluir');
      }
    }
  });

  it('154 - Botão Detalhes deve abrir com target _blank e rel seguro', async () => {
    const botoes = await driver.findElements(By.css('a.btn-primary'));
    for (let botao of botoes) {
      const target = await botao.getAttribute('target');
      const rel = await botao.getAttribute('rel');
      expect(target).to.equal('_blank');
      expect(rel).to.include('noopener');
    }
  });

  it('155 - Formulário de exclusão deve conter token CSRF', async () => {
    const forms = await driver.findElements(By.css('form'));
    for (let form of forms) {
      const html = await form.getAttribute('innerHTML');
      expect(html).to.include('csrf_token');
    }
  });

  it('156 - Ao clicar em "Excluir" deve exibir confirmação antes de enviar', async () => {
    await driver.executeScript('window.confirm = () => false');
    const botao = await driver.findElement(By.css('button.btn-danger'));
    await botao.click();
    const url = await driver.getCurrentUrl();
    expect(url).to.include('/contas');
  });

  it('157 - Links de ação não devem permitir navegação sem autenticação', async () => {
    await driver.manage().deleteAllCookies();
    await driver.get('http://localhost:5000/contas');
    await driver.wait(until.urlContains('/login'), 5000);
  });

  it('158 - Não deve permitir exclusão via POST sem token CSRF', async () => {
    const response = await fetch('http://localhost:5000/contas/1/excluir', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: ''
    });
    expect(response.status).to.not.equal(200);
  });

  it('159 - Campos da tabela não devem permitir script injection', async () => {
    const tds = await driver.findElements(By.css('tbody td'));
    for (let td of tds) {
      const texto = await td.getText();
      expect(texto).to.not.include('<script>');
    }
  });

  it('160 - Validar botão "Detalhes"', async () => {
    const botao = await driver.findElement(By.css('a.btn-primary'));
    await driver.executeScript('arguments[0].removeAttribute("target")', botao);
    await botao.click();
    await driver.wait(until.urlContains('/contas/detalhes'), 5000);
    const titulo = await driver.findElement(By.css('h2')).getText();
    expect(titulo).to.include('Detalhes da Conta');
  });

  it('161 - Deve editar a conta criada e validar a alteração', async () => {
    const novaContaNome = 'Conta adicionada Editada';

    const rows = await driver.findElements(By.css('tbody tr'));
    for (let row of rows) {
      const firstCellText = await row.findElement(By.css('td')).getText();
      if (firstCellText === nomeConta) { // <-- Aqui estava 'contaNome'
        await row.findElement(By.css('a.btn-warning')).click();
        break;
      }
    }

    await driver.wait(until.urlContains('/contas/editar'), 5000);
    const inputNome = await driver.findElement(By.name('nome'));
    await inputNome.clear();
    await inputNome.sendKeys(novaContaNome);
    await driver.findElement(By.css('button[type="submit"]')).click();

    await driver.wait(until.urlContains('/contas'), 5000);
    const sucesso = await driver.findElement(By.css('.alert-success')).getText();
    expect(sucesso).to.include('Conta atualizada com sucesso!');

    const novaContaExiste = await driver.findElement(By.xpath(`//td[text()='${novaContaNome}']`));
    expect(novaContaExiste).to.exist;

    nomeConta = novaContaNome; 
  });

  it('162 - Deve excluir a conta editada e validar remoção', async () => {
    const rows = await driver.findElements(By.css('tbody tr'));
    for (let row of rows) {
      const firstCellText = await row.findElement(By.css('td')).getText();
      if (firstCellText === nomeConta) {
        await driver.executeScript('window.confirm = () => true');
        await row.findElement(By.css('button.btn-danger')).click();
        break;
      }
    }

    await driver.wait(until.elementLocated(By.css('.alert-success')), 5000);
    const alerta = await driver.findElement(By.css('.alert-success')).getText();
    expect(alerta).to.include('Conta e suas movimentações excluídas com sucesso!');
  });
});

describe('ContaFácil - Editar, Excluir e Ordenar Conta', function () {
this.timeout(50000);

  beforeEach(async () => {
    driver = await new Builder().forBrowser('chrome').setChromeOptions(new chrome.Options()).build();
    await login('ordemAlfabetica@ordem.com', 'login_10');
    await driver.get('http://localhost:5000/contas');
  });

  afterEach(async () => {
    await driver.quit();
  });

  it('163 - Contas devem estar ordenadas alfabeticamente por nome', async () => {
    const nomes = await driver.findElements(By.css('tbody tr td:first-child'));
    const nomesText = await Promise.all(nomes.map(async (el) => (await el.getText()).trim()));
    const ordenados = [...nomesText].sort((a, b) => a.localeCompare(b));
    expect(nomesText).to.deep.equal(ordenados);
  });

  it('164 - Excluir conta "A" e validar que as contas permanecem ordenadas', async () => {
    const rows = await driver.findElements(By.css('tbody tr'));
    for (let row of rows) {
      const nome = await row.findElement(By.css('td')).getText();
      if (nome.trim().toUpperCase() === 'A') {
        await driver.executeScript('window.confirm = () => true');
        await row.findElement(By.css('form button[type="submit"]')).click();
        break;
      }
    }

    const nomes = await driver.findElements(By.css('tbody tr td:first-child'));
    const nomesText = await Promise.all(nomes.map(async (el) => (await el.getText()).trim()));
    const ordenados = [...nomesText].sort((a, b) => a.localeCompare(b));
    expect(nomesText).to.deep.equal(ordenados);
  });

  it('165 - Deve validar a ordem alfabética após a inclusão do nome "A"', async () => {
    await driver.findElement(By.css('a.btn-success')).click();
    await driver.wait(until.urlContains('/contas/adicionar'), 5000);
    await driver.findElement(By.name('nome')).sendKeys('A');
    await driver.findElement(By.css('button[type="submit"]')).click();
    await driver.wait(until.urlContains('/contas'), 5000);

    const sucesso = await driver.findElement(By.css('.alert-success')).getText();
    expect(sucesso).to.include('Conta adicionada com sucesso!');

    const nomes = await driver.findElements(By.css('tbody tr td:first-child'));
    const nomesText = await Promise.all(nomes.map(async (el) => (await el.getText()).trim()));
    const ordenados = [...nomesText].sort((a, b) => a.localeCompare(b));
    expect(nomesText).to.deep.equal(ordenados);
  });
});