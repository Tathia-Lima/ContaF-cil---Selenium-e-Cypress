// e2e/resumo.spec.js
import { Builder, By, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';

import LoginPage from '../support/page_objects/LoginPage.js';
import ResumoPage from '../support/page_objects/ResumoPage.js';
import MovimentacaoPage from '../support/page_objects/MovimentacaoPage.js';

const baseUrl = 'http://localhost:5000';

describe('Página Resumo Mensal - Suíte Completa', function() {
    this.timeout(120000); // Timeout para a suíte inteira

    let driver;
    let loginPage;
    let resumoPage;
    let movimentacaoPage;

    // Hook `before` único para toda a suíte
    before(async () => {
        driver = await new Builder().forBrowser('chrome').build();
        // Instanciação única de todos os Page Objects
        loginPage = new LoginPage(driver, baseUrl);
        resumoPage = new ResumoPage(driver, baseUrl);
        movimentacaoPage = new MovimentacaoPage(driver, baseUrl);
    });

    // Hook `after` único para toda a suíte
    after(async () => {
        if (driver) await driver.quit();
    });

    describe('Testes Funcionais', () => {
        const user = { email: 'resumo.mensal@resumo.mensal', senha: 'login_10' };

        beforeEach(async () => {
            await driver.manage().deleteAllCookies();
            await loginPage.login(user.email, user.senha);
            await driver.wait(until.urlContains('/home'), 15000);
            await resumoPage.visitar();
        });

        it('222 - Deve carregar filtros com mês, ano e tipo corretos', async () => {
            const now = new Date();
            const currentMonth = (now.getMonth() + 1).toString();
            const currentYear = now.getFullYear().toString();
            expect(await resumoPage.getFiltroValue(resumoPage.mesSelect)).to.equal(currentMonth);
            expect(await resumoPage.getFiltroValue(resumoPage.anoSelect)).to.equal(currentYear);
            expect(await resumoPage.getFiltroValue(resumoPage.tipoSelect)).to.equal('todos');
        });

        it('223 - Deve exibir mensagem de dados ausentes em conta sem movimentação', async () => {
            const linhas = await resumoPage.getLinhasTabela();
            if (linhas.length === 1) { // Verifica se há apenas uma linha, que seria a mensagem
                const celula = await linhas[0].findElement(By.css('td'));
                expect(await celula.getText()).to.include('Nenhuma movimentação encontrada');
            } else {
                // Se houver mais de uma linha, significa que há movimentações, então este teste não se aplica diretamente
                // Ou o cenário de teste precisa garantir que a conta não tenha movimentações
                console.warn('O cenário para o teste 223 não encontrou uma conta sem movimentação.');
            }
        });

        it('224 - Deve validar a estrutura de uma linha da tabela de resumo', async () => {
            const cabecalhos = await driver.findElements(By.css('table thead tr th'));
            expect(cabecalhos.length).to.equal(7);
            expect(await cabecalhos[0].getText()).to.equal('Descrição');
            expect(await cabecalhos[1].getText()).to.equal('Data Movimentação');
            expect(await cabecalhos[2].getText()).to.equal('Data Pagamento');
            expect(await cabecalhos[3].getText()).to.equal('Conta');
            expect(await cabecalhos[4].getText()).to.equal('Valor');
            expect(await cabecalhos[5].getText()).to.equal('Situação');
            expect(await cabecalhos[6].getText()).to.equal('Ações');
        });

        it('225 - Deve permitir alterar mês e ano e manter resultado coerente', async () => {
            const anoAlvo = (new Date().getFullYear() - 1).toString();
            await resumoPage.filtrarPor('1', anoAlvo, null);
            const url = await driver.getCurrentUrl();
            expect(url).to.include('mes=1');
            expect(url).to.include(`ano=${anoAlvo}`);
        });

        it('226 - Deve exibir mensagem apropriada para filtros sem resultados', async () => {
            await resumoPage.filtrarPor('1', '2026', 'todos');
            const elemento = await resumoPage.findElementWithText('Nenhuma movimentação encontrada para este período.');
            expect(await elemento.isDisplayed()).to.be.true;
        });
    });

    describe('Validar resumos mensal', () => {
        const user = { email: 'resumo.movimento@resumo.com', senha: 'login_10' };

        beforeEach(async () => {
            await driver.manage().deleteAllCookies();
            await loginPage.login(user.email, user.senha);
            await driver.wait(until.urlContains('/home'), 15000);
            await resumoPage.visitar();
        });

        it('227 - Deve filtrar corretamente por tipo "Receitas"', async () => {
            await resumoPage.filtrarPor('1', '2025', 'receita');
            const linhas = await resumoPage.getLinhasTabela();
            for (const linha of linhas) {
                const celulaValor = await linha.findElement(By.css('td:nth-child(5)'));
                expect(await celulaValor.getAttribute('class')).to.include('positive-value');
            }
        });

        it('228 - Deve filtrar corretamente por tipo "Despesas"', async () => {
            await resumoPage.filtrarPor('1', '2025', 'despesa');
            const linhas = await resumoPage.getLinhasTabela();
            for (const linha of linhas) {
                const celulaValor = await linha.findElement(By.css('td:nth-child(5)'));
                expect(await celulaValor.getAttribute('class')).to.include('negative-value');
            }
        });

        it('229 - Deve manter filtros selecionados na URL após busca', async () => {
            await resumoPage.filtrarPor('1', '2025', 'despesa');
            const url = await driver.getCurrentUrl();
            expect(url).to.include('mes=1').and.include('ano=2025').and.include('tipo=despesa');
        });

        it('230 - Deve exibir mensagem apropriada para filtros sem resultados', async () => {
            await resumoPage.filtrarPor('1', '2020', 'receita');
            const elemento = await resumoPage.findElementWithText('Nenhuma movimentação encontrada para este período.');
            expect(await elemento.isDisplayed()).to.be.true;
        });

        it('231 - Deve filtrar por mês 01/2025 e tipo receita e validar movimentações', async () => {
            await resumoPage.filtrarPor('1', '2025', 'receita');
            const linhas = await resumoPage.getLinhasTabela();
            for (const linha of linhas) {
                const dataMovimentacao = await linha.findElement(By.css('td:nth-child(2)')).getText();
                const valorClasse = await linha.findElement(By.css('td:nth-child(5)')).getAttribute('class');
                const situacao = await linha.findElement(By.css('td:nth-child(6)')).getText();

                expect(dataMovimentacao).to.match(/^2025-01-\d{2}$/);
                expect(valorClasse).to.include('positive-value');
                expect(situacao).to.include('Pago');
            }
        });

        it('232 - Deve filtrar por mês 02/2025 e tipo despesa e validar movimentações', async () => {
            await resumoPage.filtrarPor('2', '2025', 'despesa');
            const linhas = await resumoPage.getLinhasTabela();
            for (const linha of linhas) {
                const dataMovimentacao = await linha.findElement(By.css('td:nth-child(2)')).getText();
                const valorClasse = await linha.findElement(By.css('td:nth-child(5)')).getAttribute('class');
                const situacao = await linha.findElement(By.css('td:nth-child(6)')).getText();

                expect(dataMovimentacao).to.match(/^2025-02-\d{2}$/);
                expect(valorClasse).to.include('negative-value');
                expect(situacao).to.include('Pendente');
            }
        });

        it('233 - Deve carregar o resumo de Março de 2025 (Receitas) diretamente via URL', async () => {
        await driver.get(`${baseUrl}/resumo?mes=3&ano=2025&tipo=receita`);
        await driver.wait(until.elementLocated(resumoPage.tabela), 10000);
        expect(await resumoPage.getFiltroValue(resumoPage.mesSelect)).to.equal('3');
        expect(await resumoPage.getFiltroValue(resumoPage.anoSelect)).to.equal('2025');
        expect(await resumoPage.getFiltroValue(resumoPage.tipoSelect)).to.equal('receita');
        const linhas = await resumoPage.getLinhasTabela();
        expect(linhas.length).to.equal(8);
        const bodyText = await driver.findElement(By.tagName('body')).getText();
        expect(bodyText).to.include('Venda H');
        expect(bodyText).to.include('Venda C');
        expect(bodyText).to.not.include('Compra Z');
    });

        it('234 - Deve exibir todas as 7 movimentações de Janeiro de 2025 (Receita e Despesa)', async () => {
            await resumoPage.filtrarPor('1', '2025', 'todos');
            const linhas = await resumoPage.getLinhasTabela();
            expect(linhas.length).to.equal(7);
            expect(await resumoPage.findElementWithText('Compra D').then(el => el.isDisplayed())).to.be.true;
            expect(await resumoPage.findElementWithText('Venda F').then(el => el.isDisplayed())).to.be.true;
            expect(await resumoPage.findElementWithText('Venda A').then(el => el.isDisplayed())).to.be.true;
        });

        it('235 - Deve exibir apenas as despesas de Janeiro de 2025 (1 movimentação)', async () => {
            await resumoPage.filtrarPor('1', '2025', 'despesa');
            const linhas = await resumoPage.getLinhasTabela();
            expect(linhas.length).to.equal(1);
            const elemento = await resumoPage.findElementWithText('Compra D');
            expect(await elemento.isDisplayed()).to.be.true;
        });
    });

describe('Exclusão de Movimentação', () => {
        const user = { email: 'resumo.excluir@resumoexcluir.com', senha: 'login_10' };
        let dynamicMovDescription;

        beforeEach(async function() {
            this.timeout(45000); 
            await driver.manage().deleteAllCookies();
            await loginPage.login(user.email, user.senha);
            await driver.wait(until.urlContains('/home'), 15000);

            dynamicMovDescription = `Excluir ${Date.now()}`;

            await movimentacaoPage.visitar();
            await movimentacaoPage.selecionarTipo('despesa');
            await movimentacaoPage.preencherDataMovimentacao('02-07-2025'); // Use a data conforme seu log
            await movimentacaoPage.preencherDataPagamento('02-07-2025'); // Use a data conforme seu log
            await movimentacaoPage.preencherDescricao(dynamicMovDescription);
            await movimentacaoPage.preencherInteressado('Cliente A'); 
            await movimentacaoPage.preencherValor(123.45);
            await movimentacaoPage.selecionarConta('Conta 1');
            await movimentacaoPage.selecionarSituacao('pago');
            await movimentacaoPage.submeter();

            // AJUSTE: Aumentar o timeout para a URL e a mensagem de sucesso
            await driver.wait(until.urlContains('/resumo'), 15000); // Aumentado para 15s
            await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Despesa incluída com sucesso!')]")), 15000); // Aumentado para 15s
            
            // AJUSTE: Aumentar o timeout para a descrição da movimentação na tabela
            await driver.wait(until.elementLocated(resumoPage.tabela), 10000); // Aumentado para 10s
            await driver.wait(until.elementLocated(By.xpath(`//*[contains(text(),'${dynamicMovDescription}')]`)), 10000); // Aumentado para 10s
        });

        it('236 - Deve cancelar exclusão se usuário negar confirmação', async () => {
            await resumoPage.excluirMovimentacao(dynamicMovDescription, false); // false para negar
            const elementoApos = await resumoPage.findElementWithText(dynamicMovDescription);
            expect(await elementoApos.isDisplayed()).to.be.true;
        });

        it('237 - Deve excluir uma movimentação com sucesso', async () => {
            await resumoPage.excluirMovimentacao(dynamicMovDescription, true); // true para confirmar
            await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Movimentação excluída com sucesso!')]")), 5000);
            const bodyText = await driver.findElement(By.tagName('body')).getText();
            expect(bodyText).to.not.include(dynamicMovDescription);
        });
    });
});