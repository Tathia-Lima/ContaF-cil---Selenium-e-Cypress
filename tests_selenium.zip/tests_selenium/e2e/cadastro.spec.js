import { Builder, By, until, Key } from 'selenium-webdriver';
import { Options } from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';
import CadastroPage from '../support/page_objects/CadastroPage.js'; // Importa a CLASSE CadastroPage

const BASE_URL = 'http://localhost:5000'; // Ajuste se a sua URL base for diferente

let driver;
let cadastroPage; // Variável para a INSTÂNCIA do Page Object (renomeado para evitar conflito)

describe('Cadastro de Usuário - Testes Funcionais', function() {
    this.timeout(60000); // Aumenta o timeout para operações do Selenium

    beforeEach(async function() {
        let chromeOptions = new Options();
        // chromeOptions.addArguments('--headless'); // Descomente para execução headless (sem abrir o navegador)
        chromeOptions.addArguments('--start-maximized'); // Inicia maximizado
        chromeOptions.addArguments('--disable-gpu'); // Necessário para headless em algumas configurações
        chromeOptions.addArguments('--no-sandbox'); // Para ambientes CI/CD
        chromeOptions.addArguments('--disable-dev-shm-usage'); // Para ambientes CI/CD

        driver = await new Builder().forBrowser('chrome').setChromeOptions(chromeOptions).build();
        cadastroPage = new CadastroPage(driver, BASE_URL); // Cria uma nova instância do Page Object
                                                        // Note que agora é 'cadastroPage' (minúsculo)
        await cadastroPage.visit(); // Usa o método do Page Object para navegar
        await driver.sleep(500); // Pequena pausa para garantir que a página renderizou
    });

    afterEach(async function() {
        if (driver) {
            await driver.quit();
        }
    });

    // --- Validação campos obrigatórios ---

    it('97 - Não deve permitir cadastro apenas com email', async function() {
        await cadastroPage.fillEmail('saltototal@saldotota.com');
        await cadastroPage.submit();
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/todos os campos são obrigatórios/i);
    });    

    it('98 - Não deve permitir cadastro apenas com senha', async function() {
        await cadastroPage.fillPassword('Senha123!');
        await cadastroPage.submit();
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/todos os campos são obrigatórios/i);
    });

    it('99 - Não deve permitir cadastro apenas com nome', async function() {
        await cadastroPage.fillName('Teste Usuário');
        await cadastroPage.submit();
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/todos os campos são obrigatórios/i);
    });

    // --- Validação formato e existência do email ---

    it('100 - Não deve aceitar email inválido (sem @)', async function() {
        await cadastroPage.fillName('Teste Usuário');
        await cadastroPage.fillEmail('emailinvalido.com');
        await cadastroPage.fillPassword('Senha123!');
        await cadastroPage.submit();
        
        // CORRIGIDO: Re-adquirir a referência do elemento emailInput após a submissão
        const emailInput = await cadastroPage.getEmailInput();
        const validationMessage = await driver.executeScript("return arguments[0].validationMessage;", emailInput);
        expect(validationMessage).to.match(/^Inclua um "@" no endereço de e-mail/); // Usando regex
        
        // Se o seu backend também retornar uma mensagem de erro para isso (boa prática), adicione:
        // const alertMessage = await cadastroPage.getAlertMessageText();
        // expect(alertMessage).to.match(/email inválido/i);
    });

    it('101 - Não deve aceitar email inválido (sem domínio)', async function() {
        await cadastroPage.fillName('Teste Usuário');
        await cadastroPage.fillEmail('email@');
        await cadastroPage.fillPassword('Senha123!');
        await cadastroPage.submit();
        
        const emailInput = await cadastroPage.getEmailInput();
        //const validationMessage = await driver.executeScript("return arguments[0].validationMessage;", emailInput);
        //expect(validationMessage).to.match(/^Inclua um "@" no endereço de e-mail/); // CORRIGIDO: Usando regex
        
        // Se o backend também retornar uma mensagem de erro para isso, adicione:
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/email inválido/i);
    });

    it('102 - Não deve aceitar email já existente', async function() {
        await cadastroPage.register('Teste Usuário', 'saltototal@saldotota.com', 'Senha123!'); 
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Endereço de email já utilizado\.|email já cadastrado/i); // Ajuste a regex para a mensagem exata
    });

    it('103 - Deve aceitar email válido e novo', async function() {
        const novoEmail = `novoemail${Date.now()}@exemplo.com`;
        await cadastroPage.register('Novo Usuário', novoEmail, 'Senha123!');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Usuário cadastrado com sucesso! Faça o login\./i);
        await driver.wait(until.urlContains('/login'), 5000, 'Não redirecionou para a página de login após cadastro bem-sucedido.');
        expect(await driver.getCurrentUrl()).to.include('/login'); // Assumindo que o cadastro bem-sucedido redireciona para o login
    });

    // --- Validação da senha ---

    it('104 - Não deve aceitar senha com menos de 8 caracteres', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Ab1!');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/senha deve ter entre 8 e 10 caracteres/i);
    });

    it('105 - Não deve aceitar senha com mais de 10 caracteres', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Ab1!Ab1!Ab1!');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/senha deve ter entre 8 e 10 caracteres/i);
    });

    it('106 - Não deve aceitar senha sem letra', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, '12345678!');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/senha deve conter pelo menos uma letra/i);
    });

    it('107 - Não deve aceitar senha sem número', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Senha!!!');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/senha deve conter pelo menos um número/i);
    });

    it('108 - Não deve aceitar senha sem caractere especial', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Senha1234');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/senha deve conter pelo menos um caractere especial/i);
    });

    it('109 - Não deve aceitar senha com espaço em branco', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Senha 123!');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/senha não pode conter espaços/i);
    });

    it('110 - Deve aceitar senha válida conforme critérios', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Abc1230!@#');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Usuário cadastrado com sucesso! Faça o login\./i);
        await driver.wait(until.urlContains('/login'), 5000, 'Não redirecionou para a página de login após cadastro bem-sucedido.');
        expect(await driver.getCurrentUrl()).to.include('/login');
    });

    // --- Validação do nome ---
    it('111 - Não deve aceitar nome com caracteres numéricos', async function() {
        await cadastroPage.register('João123', `email${Date.now()}@exemplo.com`, 'Abc123!@#');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Nome deve conter apenas letras\.|Nome inválido/i); // Ajuste a regex
    });

    it('112 - Não deve aceitar nome com caracteres especiais', async function() {
        await cadastroPage.register('João@#!', `email${Date.now()}@exemplo.com`, 'Abc123!@#');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Nome deve conter apenas letras\.|Nome inválido/i); // Ajuste a regex
    });

    it('113 - Deve aceitar nome com espaços e acentos', async function() {
        await cadastroPage.register('João da Silva', `email${Date.now()}@exemplo.com`, 'Abc123!@#');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Usuário cadastrado com sucesso! Faça o login\./i);
        await driver.wait(until.urlContains('/login'), 5000, 'Não redirecionou para a página de login após cadastro bem-sucedido.');
        expect(await driver.getCurrentUrl()).to.include('/login');
    });

    it('114 - Nome muito longo (mais de 50 caracteres) deve apresentar erro', async function() {
        const longName = 'A'.repeat(51);
        await cadastroPage.register(longName, `email${Date.now()}@exemplo.com`, 'Abc123!@#');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Máximo de 50 caracteres no nome|Nome muito longo/i); // Ajuste a regex
    });

    // --- Botão mostrar/ocultar senha ---
    it('115 - Botão mostrar senha altera input para texto e atualiza aria-label', async function() {
        const passwordInput = await cadastroPage.getPasswordInput();
        expect(await passwordInput.getAttribute('type')).to.equal('password');
        
        const toggleButton = await cadastroPage.getTogglePasswordButton();
        await toggleButton.click();
        
        expect(await passwordInput.getAttribute('type')).to.equal('text');
        expect(await toggleButton.getAttribute('aria-label')).to.equal('Ocultar senha');
    });

    it('116 - Botão ocultar senha altera input para password e atualiza aria-label', async function() {
        const passwordInput = await cadastroPage.getPasswordInput();
        const toggleButton = await cadastroPage.getTogglePasswordButton();
        
        await toggleButton.click(); // mostrar
        await driver.sleep(100); // Pequena pausa para garantir a atualização do DOM
        await toggleButton.click(); // ocultar
        
        expect(await passwordInput.getAttribute('type')).to.equal('password');
        expect(await toggleButton.getAttribute('aria-label')).to.equal('Mostrar senha');
    });

    it('117 - Botão mostrar/ocultar senha não submete o formulário', async function() {
        const initialUrl = await driver.getCurrentUrl();
        const toggleButton = await cadastroPage.getTogglePasswordButton();
        await toggleButton.click();
        
        // Espera um pouco para garantir que nenhuma redireção aconteceu
        await driver.sleep(1000); 
        expect(await driver.getCurrentUrl()).to.include('/cadastro');
        expect(await driver.getCurrentUrl()).to.equal(initialUrl); // Garante que não houve recarregamento completo da página
    });

    // --- Submissão do formulário e UX ---
    it('118 - Formulário com dados válidos realiza cadastro com sucesso', async function() {
        await cadastroPage.register('Usuário Completo', `usuario${Date.now()}@exemplo.com`, 'Abc1234!@#');
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Usuário cadastrado com sucesso! Faça o login\./i);
        await driver.wait(until.urlContains('/login'), 5000, 'Não redirecionou para a página de login após cadastro bem-sucedido.');
        expect(await driver.getCurrentUrl()).to.include('/login');
    });

    it('119 - Navegação entre campos via tecla Tab funciona corretamente', async function() {
        const nameInput = await cadastroPage.getNameInput();
        const emailInput = await cadastroPage.getEmailInput();
        const passwordInput = await cadastroPage.getPasswordInput();
        const toggleButton = await cadastroPage.getTogglePasswordButton();
        const submitButton = await cadastroPage.getSubmitButton();

        await nameInput.sendKeys(Key.TAB);
        let activeElement = await driver.switchTo().activeElement();
        expect(await activeElement.getId()).to.equal(await emailInput.getId());

        await emailInput.sendKeys(Key.TAB);
        activeElement = await driver.switchTo().activeElement();
        expect(await activeElement.getId()).to.equal(await passwordInput.getId());

        await passwordInput.sendKeys(Key.TAB);
        activeElement = await driver.switchTo().activeElement();
        expect(await activeElement.getId()).to.equal(await toggleButton.getId());

        await toggleButton.sendKeys(Key.TAB);
        activeElement = await driver.switchTo().activeElement();
        expect(await activeElement.getId()).to.equal(await submitButton.getId());
    });

    it('120 - Submissão via tecla Enter dispara o envio do formulário', async function() {
        await cadastroPage.fillName('Usuário Enter');
        await cadastroPage.fillEmail(`email${Date.now()}@exemplo.com`);
        
        const passwordInput = await cadastroPage.getPasswordInput();
        await passwordInput.sendKeys('Abc1234!@#', Key.ENTER); // Envia a tecla ENTER após a senha
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Usuário cadastrado com sucesso! Faça o login\./i);
        await driver.wait(until.urlContains('/login'), 5000, 'Não redirecionou para a página de login após cadastro bem-sucedido.');
        expect(await driver.getCurrentUrl()).to.include('/login');
    });

    it('121 - Senha com 7 caracteres deve apresentar erro', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Abc123!'); // 7 caracteres
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/senha deve ter entre 8 e 10 caracteres/i);
    });

    it('122- Senha com 8 caracteres deve cadastrar com sucesso', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Abc123!@'); // 8 caracteres
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Usuário cadastrado com sucesso! Faça o login/i);
        await driver.wait(until.urlContains('/login'), 5000, 'Não redirecionou para a página de login após cadastro bem-sucedido.');
        expect(await driver.getCurrentUrl()).to.include('/login');
    });

    it('123- Senha com 9 caracteres deve cadastrar com sucesso', async function() {
        await cadastroPage.register('Usuário Teste', `email${Date.now()}@exemplo.com`, 'Abc123!@#'); // 9 caracteres
        
        const alertMessage = await cadastroPage.getAlertMessageText();
        expect(alertMessage).to.match(/Usuário cadastrado com sucesso! Faça o login/i);
        await driver.wait(until.urlContains('/login'), 5000, 'Não redirecionou para a página de login após cadastro bem-sucedido.');
        expect(await driver.getCurrentUrl()).to.include('/login');
    });
});
