// Testes de Usabilidade e Acessibilidade - Página Resumo (Selenium WebDriver) - Refatorado

import { Builder, By, Key, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';

// Importa os Page Objects necessários
import LoginPage from '../../support/page_objects/LoginPage.js';
import MovimentacaoPage from '../../support/page_objects/MovimentacaoPage.js';
import ResumoPage from '../../support/page_objects/ResumoPage.js';

const baseUrl = 'http://localhost:5000';
const USER_EMAIL = 'resumo.movimento@resumo.com';
const USER_PASSWORD = 'login_10';

let driver;
let loginPage; 
let movimentacaoPage;
let resumoPage; 

/**
 * Função auxiliar para validar a presença e visibilidade de mensagens de erro ou sucesso.
 * @param {string} mensagem O texto esperado na mensagem.
 * @param {string} [seletorClasse=\'alert\'] A classe CSS dos elementos que podem conter as mensagens (ex: \'alert\').
 * @param {number} [timeout=5000] O tempo limite em milissegundos para esperar pela mensagem.
 */
async function validarMensagem(mensagem, seletorClasse = 'alert', timeout = 5000) {
    try {
        const xpathSelector = `//*[contains(@class, \'${seletorClasse}\') and contains(normalize-space(.), \'${mensagem}\')]`;
        
        const elementoMensagem = await driver.wait(
            until.elementLocated(By.xpath(xpathSelector)),
            timeout 
        );
        
        expect(await elementoMensagem.isDisplayed()).to.be.true;
        expect(await elementoMensagem.getText()).to.include(mensagem);
        console.log(`Mensagem validada: \"${mensagem}\" encontrada em um elemento visível.`);
    } catch (error) {
        throw new Error(`Mensagem \"${mensagem}\" não encontrada ou não visível: ${error.message}`);
    }
}

// Função auxiliar para criar uma movimentação para os testes de exclusão
async function criarMovimentacaoParaTeste(descricao) {
    await movimentacaoPage.visitar();
    const movimentacaoParaTeste = {
        descricao: descricao,
        interessado: 'Teste Exclusão Selenium',
        tipo: 'despesa',
        dataMovimentacao: '2025-07-03',
        dataPagamento: '2025-07-03',
        valor: '123.45',
        conta: 'Conta para Testes', 
        situacao: 'pago',
    };

    try {
        await movimentacaoPage.selecionarOpcao(movimentacaoPage.contaSelect, movimentacaoParaTeste.conta);
    } catch (error) {
        console.warn(`Aviso: Conta \"${movimentacaoParaTeste.conta}\" não encontrada. Tentando selecionar a primeira conta disponível.`);
        const contaSelectElement = await driver.findElement(movimentacaoPage.contaSelect);
        const options = await contaSelectElement.findElements(By.css('option'));
        if (options.length > 1) {
            const firstValidOptionText = await options[1].getText(); 
            await movimentacaoPage.selecionarOpcao(movimentacaoPage.contaSelect, firstValidOptionText); 
            movimentacaoParaTeste.conta = firstValidOptionText; 
            console.log(`Conta selecionada: \"${movimentacaoParaTeste.conta}\" (primeira disponível).`);
        } else {
            throw new Error("Nenhuma conta disponível para seleção após falha na conta \'Conta para Testes\'.");
        }
    }

    await movimentacaoPage.preencherFormulario(movimentacaoParaTeste);
    await movimentacaoPage.submeter();
    await driver.wait(until.urlContains('/resumo'), 10000);
    await validarMensagem('Despesa incluída com sucesso!', 'alert-success', 10000); 
}

describe('Usabilidade e Acessibilidade - Página Resumo', function () {
    this.timeout(40000); 

    before(async () => {
        driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(new chrome.Options().addArguments('--start-maximized'))
            .build();

        loginPage = new LoginPage(driver, baseUrl);
        movimentacaoPage = new MovimentacaoPage(driver, baseUrl);
        resumoPage = new ResumoPage(driver, baseUrl);

        await loginPage.login(USER_EMAIL, USER_PASSWORD);
        await driver.wait(until.urlContains('/home'), 10000);
    });

    beforeEach(async () => {
        await resumoPage.visitar();
        await driver.wait(until.elementLocated(By.css('table tbody tr')), 10000);
    });

    after(async () => {
        await driver.quit();
    });

    // Teste 239: Filtros - Tabela não atualiza sem clicar em Buscar
    it('239. Filtros - Tabela não atualiza sem clicar em Buscar', async () => {
        const initialRows = await resumoPage.getLinhasTabela();
        expect(initialRows.length).to.be.greaterThan(0);

        await resumoPage.selecionarOpcao(resumoPage.mesSelect, '1'); 

        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.not.include('mes=1');

        expect(await resumoPage.getFiltroValue(resumoPage.mesSelect)).to.equal('1');
        
        await driver.sleep(500); 
        const afterSelectRows = await resumoPage.getLinhasTabela();
        expect(afterSelectRows.length).to.equal(initialRows.length);
    });

    // Teste 240: Cada linha deve ter botão \"Excluir\" visível e dentro de um form
    it('240. Cada linha deve ter botão \"Excluir\" visível e dentro de um form', async () => {
        await resumoPage.filtrarPor('1', '2025', 'todos'); 

        const rows = await resumoPage.getLinhasTabela();
        for (const row of rows) {
            const rowText = await row.getText();
            if (!rowText.includes('Nenhuma movimentação encontrada')) {
                const formElement = await row.findElement(By.css('form'));
                expect(formElement).to.exist;

                const deleteButton = await formElement.findElement(By.css('button.btn-danger.btn-sm'));
                expect(await deleteButton.isDisplayed()).to.be.true;
                expect(await deleteButton.getText()).to.include('Excluir');
            }
        }
    });

    // Teste 241: Não deve exibir mensagens de erro inesperadas
    it('241. Não deve exibir mensagens de erro inesperadas', async () => {
        const dangerFlashes = await driver.findElements(By.css('.flash.danger'));
        expect(dangerFlashes.length).to.equal(0, 'Não deve haver mensagens flash de perigo.');

        const alertDangers = await driver.findElements(By.css('.alert-danger'));
        expect(alertDangers.length).to.equal(0, 'Não deve haver alertas de perigo.');

        const errorTexts = await driver.findElements(By.xpath("//*[contains(text(), 'Erro:')]"));
        expect(errorTexts.length).to.equal(0, 'Não deve haver texto contendo \"Erro:\".');
    });

    // Teste 242: Valores de Receita são verdes e formatados corretamente
    it('242. Valores de Receita são verdes e formatados corretamente', async () => {
        await resumoPage.filtrarPor('1', '2025', 'receita');

        const receitaRow = await driver.wait(until.elementLocated(By.xpath("//table/tbody/tr[./td[contains(text(), 'Venda A')]]")), 5000);
        const valorCell = await receitaRow.findElement(By.xpath('./td[5]')); 
        
        expect(await valorCell.getText()).to.include('R$'); 
        const color = await valorCell.getCssValue('color');
        expect(color).to.match(/rgb\(0,\s?128,\s?0\)|rgba\(0,\s?128,\s?0,\s?1\)|rgb\(0,\s?255,\s?0\)|rgba\(0,\s?255,\s?0,\s?1\)/); 
    });

    // Teste 243: Valores de Despesa são vermelhos e formatados
    it('243. Valores de Despesa são vermelhos e formatados', async () => {
        await resumoPage.filtrarPor('1', '2025', 'despesa');

        const despesaRow = await driver.wait(until.elementLocated(By.xpath("//table/tbody/tr[./td[contains(text(), 'Compra D')]]")), 5000);
        const valorCell = await despesaRow.findElement(By.xpath('./td[5]')); 

        expect(await valorCell.getText()).to.include('R$ 120,00'); 
        const color = await valorCell.getCssValue('color');
        expect(color).to.match(/rgb\(255,\s?36,\s?0\)|rgba\(255,\s?36,\s?0,\s?1\)/);
    });

    // Teste 244: Situações \"Pago\" e \"Pendente\" capitalizadas
    it('244. Situações \"Pago\" e \"Pendente\" capitalizadas', async () => {
        await resumoPage.filtrarPor('2', '2025', 'todos');
        const pendenteRow = await driver.wait(until.elementLocated(By.xpath("//table/tbody/tr[./td[contains(text(), 'Compra G')]]")), 5000);
        const situacaoCellPendente = await pendenteRow.findElement(By.xpath('./td[6]')); 
        expect(await situacaoCellPendente.getText()).to.match(/^Pendente$/);

        await resumoPage.filtrarPor('1', '2025', 'todos');
        const pagoRow = await driver.wait(until.elementLocated(By.xpath("//table/tbody/tr[./td[contains(text(), 'Venda F')]]")), 5000);
        const situacaoCellPago = await pagoRow.findElement(By.xpath('./td[6]')); 
        expect(await situacaoCellPago.getText()).to.match(/^Pago$/);
    });

    // Teste 245: Mensagem \"Nenhuma movimentação encontrada\" aparece corretamente
    it('245. Mensagem \"Nenhuma movimentação encontrada\" aparece corretamente', async () => {
        await resumoPage.filtrarPor('12', '2020', 'todos'); 

        const rows = await resumoPage.getLinhasTabela();
        expect(rows.length).to.equal(1); 

        const noMovMessage = await rows[0].findElement(By.css('td[colspan="7"]'));
        expect(await noMovMessage.getText()).to.include('Nenhuma movimentação encontrada para este período.');
    });

    // Teste 247: Navegação por tabulação e preenchimento do formulário
    it('247. Navegação por tabulação e preenchimento do formulário', async () => {
        await driver.get(`${baseUrl}/resumo`); 
        
        const mesSelect = await resumoPage.driver.findElement(resumoPage.mesSelect);
        await mesSelect.sendKeys(Key.TAB); 

        const anoSelect = await driver.switchTo().activeElement();
        expect(await anoSelect.getAttribute('id')).to.equal('ano');
        await resumoPage.selecionarOpcao(resumoPage.anoSelect, '2025'); 

        await anoSelect.sendKeys(Key.TAB); 

        const tipoSelect = await driver.switchTo().activeElement();
        expect(await tipoSelect.getAttribute('id')).to.equal('tipo');
        await resumoPage.selecionarOpcao(resumoPage.tipoSelect, 'receita'); 

        await tipoSelect.sendKeys(Key.TAB); 

        const buscarButton = await driver.switchTo().activeElement();
        expect(await buscarButton.getText()).to.include('Buscar');
        await buscarButton.sendKeys(Key.ENTER); 

        await driver.wait(until.urlContains('ano=2025'), 5000);
        await driver.wait(until.urlContains('tipo=receita'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('ano=2025');
        expect(currentUrl).to.include('tipo=receita');
        
        const rows = await resumoPage.getLinhasTabela();
        expect(rows.length).to.be.greaterThan(0);
    });

    // Teste 248: Validar busca utilizando o preenchimento padrão do app, mês e ano atual
    it('248. Validar busca utilizando o preenchimento padrão do app, mês e ano atual', async () => {
        const hoje = new Date();
        const mesAtual = (hoje.getMonth() + 1).toString();
        const anoAtual = hoje.getFullYear().toString();

        await driver.get(`${baseUrl}/resumo`); 
        
        expect(await resumoPage.getFiltroValue(resumoPage.mesSelect)).to.equal(mesAtual);
        expect(await resumoPage.getFiltroValue(resumoPage.anoSelect)).to.equal(anoAtual);
    });

    // Teste 249: Elementos não interativos não recebem foco por tabulação
    it('249. Elementos não interativos não recebem foco por tabulação', async () => {
        const serverDateElement = await driver.findElements(By.id('server-date'));
        if (serverDateElement.length > 0) {
            expect(await serverDateElement[0].isDisplayed()).to.be.false; 
            const tabIndex = parseInt(await serverDateElement[0].getAttribute('tabindex') || '-1');
            expect(tabIndex).to.be.lessThan(0); 
        } else {
            console.warn("Elemento '#server-date' não encontrado para verificação de focabilidade.");
        }
    });
});

describe('Exclusão de Movimentação via teclado (Resumo)', function () {

  this.timeout(40000);

  const USER_EMAIL_EXCLUSAO = 'excluir.tab@excluir.com';
  const USER_PASSWORD_EXCLUSAO = 'login_10';

  let driver, loginPage, movimentacaoPage, resumoPage;
  let dynamicMovDescription;

  before(async () => {
    driver = await new Builder()
      .forBrowser("chrome")
      .setChromeOptions(new chrome.Options().addArguments("--headless", "--window-size=1920,1080"))
      .build();

    loginPage = new LoginPage(driver, baseUrl);
    movimentacaoPage = new MovimentacaoPage(driver, baseUrl);
    resumoPage = new ResumoPage(driver, baseUrl);

    await loginPage.login(USER_EMAIL_EXCLUSAO, USER_PASSWORD_EXCLUSAO);
    await driver.wait(until.urlContains("/home"), 10000);

    dynamicMovDescription = `Excluir ${Date.now()}`;

    await movimentacaoPage.visitar();
    await movimentacaoPage.preencherFormulario({
      tipo: 'despesa',
      dataMovimentacao: '2025-07-03',
      dataPagamento: '2025-07-03',
      descricao: dynamicMovDescription,
      interessado: 'Teste Exclusão Selenium',
      valor: '123.45',
      conta: 'Conta 1',
      situacao: 'pago'
    });
    await movimentacaoPage.submeter();
    await resumoPage.visitar();
  });

  beforeEach(async () => {
    await loginPage.login(USER_EMAIL_EXCLUSAO, USER_PASSWORD_EXCLUSAO);
    await resumoPage.visitar();
    await driver.wait(until.elementLocated(By.css("table tbody tr")), 10000);
  });

  after(async () => {
    if (driver) await driver.quit();
  });

  it('250 - Deve validar cancelar exclusão via teclado (tab + enter para cancelar)', async () => {
    const movimentacaoRow = await driver.wait(
      until.elementLocated(By.xpath(`//td[contains(text(), '${dynamicMovDescription}')]/..`)),
      10000
    );
    expect(await movimentacaoRow.isDisplayed()).to.be.true;

    const deleteButton = await movimentacaoRow.findElement(By.css('button.btn-danger'));
    await deleteButton.sendKeys(Key.TAB); // Foco é simbólico aqui
    await deleteButton.sendKeys(Key.ENTER);

    const alert = await driver.wait(until.alertIsPresent(), 5000);
    expect(await alert.getText()).to.include('Tem certeza que deseja excluir');
    await alert.dismiss();

    await resumoPage.visitar(); // Garante DOM atualizado
    const updatedRows = await resumoPage.getLinhasTabela();
    const found = await Promise.any(updatedRows.map(async (row) => {
      return (await row.getText()).includes(dynamicMovDescription);
    })).catch(() => false);
    expect(found).to.be.true;
  });

  it('251 - Deve validar confirmar exclusão via teclado (tab + enter para confirmar)', async () => {
    const movimentacaoRow = await driver.wait(
      until.elementLocated(By.xpath(`//td[contains(text(), '${dynamicMovDescription}')]/..`)),
      10000
    );
    expect(await movimentacaoRow.isDisplayed()).to.be.true;

    const deleteButton = await movimentacaoRow.findElement(By.css('button.btn-danger'));
    await deleteButton.sendKeys(Key.TAB); // Simulação de foco
    await deleteButton.sendKeys(Key.ENTER);

    const alert = await driver.wait(until.alertIsPresent(), 5000);
    expect(await alert.getText()).to.include('Tem certeza que deseja excluir');
    await alert.accept();

    // Mensagem de sucesso
    const alerta = await driver.wait(until.elementLocated(By.css('.alert-success')), 10000);
    expect(await alerta.getText()).to.include('Movimentação excluída');

    await resumoPage.visitar();
    const elementos = await driver.findElements(By.xpath(`//td[contains(text(),'${dynamicMovDescription}')]`));
    expect(elementos.length).to.equal(0);
  });
});


