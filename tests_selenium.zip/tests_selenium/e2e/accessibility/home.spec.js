import { Builder, By, Key, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';

import LoginPage from '../../support/page_objects/LoginPage.js';
import HomePage from '../../support/page_objects/HomePage.js';

const baseUrl = 'http://localhost:5000';
const userWithAccounts = { email: 'LoginPage@LoginPage.com', senha: 'login_10' };

let driver;
let loginPage;
let homePage;

describe('Acessibilidade - Página Home', function () {
  this.timeout(30000);

  before(async () => {
    driver = await new Builder()
      .forBrowser('chrome')
      .setChromeOptions(new chrome.Options().addArguments('--start-maximized'))
      .build();

    homePage = new HomePage(driver, baseUrl);
    loginPage = new LoginPage(driver, baseUrl);

    await loginPage.login(userWithAccounts.email, userWithAccounts.senha);
    await homePage.navigateToHome();
  });

  beforeEach(async () => {
    await homePage.navigateToHome();
  });

  after(async () => {
    await driver.quit();
  });

  it('18 - Deve conter cabeçalho com texto acessível', async () => {
    const text = await homePage.getH2Text();
    expect(text).to.include('Olá, LoginPage! Seja bem-vindo(a) ao ContaFácil');
  });

  it('19 - Deve conter uma tabela com títulos claros e identificáveis', async () => {
    const headers = await homePage.getTableHeaders();
    const texts = await Promise.all(headers.map(async (th) => await th.getText()));
    expect(texts[0]).to.include('Conta');
    expect(texts[1]).to.include('Receitas');
    expect(texts[2]).to.include('Despesas');
    expect(texts[3]).to.include('Saldo');
  });

  it('20 - Deve permitir navegação por teclado com foco visível', async () => {
    await driver.actions().sendKeys(Key.TAB).perform();
    const focused = await driver.switchTo().activeElement();
    const isDisplayed = await focused.isDisplayed();
    expect(isDisplayed).to.be.true;
  });

  it('21 - Deve passar nas verificações automáticas do axe-core (MANUAL)', async () => {
    console.log('Este teste deve ser feito manualmente com axe-core injetado.');
  });

  it('22 - Todos os elementos interativos devem ser acessíveis por teclado', async () => {
    const selectors = ['button', 'a', 'input', 'select', 'textarea'];
    const elements = await driver.findElements(By.css(selectors.join(', ')));
    for (const el of elements) {
      await driver.executeScript('arguments[0].focus();', el);
      const isFocused = await driver.executeScript('return arguments[0] === document.activeElement;', el);
      expect(isFocused).to.be.true;
    }
  });

  it('23 - Elementos devem possuir contraste adequado (MANUAL)', async () => {
    console.log('Esse teste deve ser realizado com ferramenta externa (axe-core, Lighthouse).');
  });

  it('24 - Botões devem conter texto ou aria-label', async () => {
    const botoes = await driver.findElements(By.css('button'));
    for (const botao of botoes) {
      const texto = await botao.getText();
      const aria = await botao.getAttribute('aria-label');
      expect(texto.trim().length > 0 || aria !== null).to.be.true;
    }
  });

  it('25 - Links devem ser descritivos (sem textos como "clique aqui")', async () => {
    const links = await driver.findElements(By.css('a'));
    for (const link of links) {
      if (await link.isDisplayed()) {
        const text = await link.getText();
        expect(text.trim().length).to.be.greaterThan(0);
        expect(text.toLowerCase()).to.not.include('clique aqui');
      }
    }
  });

  it('26 - Página deve possuir uma linguagem definida no HTML', async () => {
    const lang = await driver.executeScript('return document.documentElement.lang');
    expect(lang).to.match(/^[a-z]{2}(-[A-Z]{2})?$/);
  });

  it('27 - Página não requer foco inicial automático, teste ignorado', async () => {
    console.log('Foco inicial não é necessário nesta página porque o usuário decide a ação.');
  });

  it('28 - Nenhum elemento deve estar com tabindex="-1" indevidamente', async () => {
    const elements = await driver.findElements(By.css('[tabindex="-1"]'));
    if (elements.length === 0) {
      console.log('Nenhum tabindex="-1" encontrado. Teste aprovado.');
    } else {
      for (const el of elements) {
        const ariaLive = await el.getAttribute('aria-live');
        expect(ariaLive).to.not.be.null;
      }
    }
  });

  it('227 - Deve ser visualmente claro que o nome da conta é um link (MANUAL + FUNCIONAL)', async () => {
    const rows = await homePage.getTableRows();
    if (rows.length === 0) {
      console.log('Nenhuma conta cadastrada. Teste ignorado.');
      return;
    }

    const originalWindow = await driver.getWindowHandle();

    const link = await rows[0].findElement(By.css('td:first-child a'));
    const href = await link.getAttribute('href');
    const target = await link.getAttribute('target');
    const rel = await link.getAttribute('rel');

    expect(target).to.equal('_blank');
    expect(rel).to.include('noopener');

    await link.click();

    await driver.wait(async () => {
      const handles = await driver.getAllWindowHandles();
      return handles.length > 1;
    }, 10000);

    const handles = await driver.getAllWindowHandles();
    const newWindow = handles.find(handle => handle !== originalWindow);

    await driver.switchTo().window(newWindow);
    await driver.wait(until.urlContains('/contas/detalhes/'), 10000);

    const currentUrl = await driver.getCurrentUrl();
    expect(currentUrl).to.include(href);

    const h2 = await driver.findElement(By.css('h2'));
    const h2Text = await h2.getText();
    expect(h2Text).to.include('Detalhes da Conta');

    await driver.close();
    await driver.switchTo().window(originalWindow);
  });

  describe('Navegation', function () {
  
    // Teste 29: Deve clicar no menu ContaFácil e abrir home
    it('29 - Deve clicar no menu ContaFácil e abrir home', async () => {
        // Encontra o link da marca "ContaFácil" (assumindo que tem a classe 'brand' ou outro seletor único)
        const brandLink = await driver.findElement(By.css('a.brand'));
        await brandLink.click();
        // Verifica se a URL contém '/home'
        await driver.wait(until.urlContains('/home'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('/home');
    });

    // Teste 30: Deve abrir a página home pelo menu
    it('30 - Deve abrir a página home pelo menu', async () => {
        // Encontra o link "Home" no menu de navegação
        const homeLink = await driver.findElement(By.xpath("//a[contains(text(), 'Home')]"));
        await homeLink.click();
        // Verifica se a URL contém '/home'
        await driver.wait(until.urlContains('/home'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('/home');
    });

    // Teste 31: Deve abrir página Contas > Adicionar
    it('31 - Deve abrir página Contas > Adicionar', async () => {
        // Clica no botão do dropdown "Contas"
        const contasDropdown = await driver.findElement(By.css('.dropdown .dropbtn'));
        await contasDropdown.click();
        // Espera que o conteúdo do dropdown esteja visível
        await driver.wait(until.elementLocated(By.css('.dropdown-content a')), 2000);
        // Clica no link "Adicionar" dentro do dropdown
        const adicionarLink = await driver.findElement(By.xpath("//div[@class='dropdown-content']//a[contains(text(), 'Adicionar')]"));
        await adicionarLink.click();
        // Verifica se a URL contém '/contas/adicionar'
        await driver.wait(until.urlContains('/contas/adicionar'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('/contas/adicionar');
    });

    // Teste 32: Deve abrir página Contas > Listar
    it('32 - Deve abrir página Contas > Listar', async () => {
        // Clica no botão do dropdown "Contas"
        const contasDropdown = await driver.findElement(By.css('.dropdown .dropbtn'));
        await contasDropdown.click();
        // Espera que o conteúdo do dropdown esteja visível
        await driver.wait(until.elementLocated(By.css('.dropdown-content a')), 2000);
        // Clica no link "Listar" dentro do dropdown
        const listarLink = await driver.findElement(By.xpath("//div[@class='dropdown-content']//a[contains(text(), 'Listar')]"));
        await listarLink.click();
        // Verifica se a URL contém '/contas' (ou '/contas/listar' se for o caso)
        await driver.wait(until.urlContains('/contas'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('/contas');
        // Valida o título da página para garantir que a lista foi carregada
        const pageTitle = await driver.findElement(By.css('h1'));
        expect(await pageTitle.getText()).to.include('Contas Cadastradas');
    });

    // Teste 33: Deve abrir página Criar Movimentação
    it('33 - Deve abrir página Criar Movimentação', async () => {
        // Encontra o link "Criar Movimentação" no menu de navegação
        const movimentacaoLink = await driver.findElement(By.xpath("//a[contains(text(), 'Criar Movimentação')]"));
        await movimentacaoLink.click();
        // Verifica se a URL contém '/movimentacao'
        await driver.wait(until.urlContains('/movimentacao'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('/movimentacao');
    });

    // Teste 34: Deve abrir página Resumo Mensal
    it('34 - Deve abrir página Resumo Mensal', async () => {
        // Encontra o link "Resumo Mensal" no menu de navegação
        const resumoLink = await driver.findElement(By.xpath("//a[contains(text(), 'Resumo Mensal')]"));
        await resumoLink.click();
        // Verifica se a URL contém '/resumo'
        await driver.wait(until.urlContains('/resumo'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('/resumo');
    });

    // Teste 35: Deve clicar em sair e ir para login
    it('35 - Deve clicar em sair e ir para login', async () => {
        // Encontra o link "Sair" no menu de navegação
        const sairLink = await driver.findElement(By.xpath("//a[contains(text(), 'Sair')]"));
        await sairLink.click();
        // Verifica se a URL contém '/login'
        await driver.wait(until.urlContains('/login'), 5000);
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.include('/login');
    });
  });
});
