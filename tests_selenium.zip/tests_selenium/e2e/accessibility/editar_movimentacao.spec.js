// Testes de Acessibilidade - Página Editar Movimentação (versão corrigida sem nova aba em editar)

import { Builder, By, until, Key } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';
import axeSource from 'axe-core/axe.min.js';

import LoginPage from '../../support/page_objects/LoginPage.js';
import EditarMovimentacaoPage from '../../support/page_objects/EditarMovimentacaoPage.js';

const baseUrl = 'http://localhost:5000';
const user = { email: 'editarMovimentacao@movimentacao.com', senha: 'login_10' };

let driver;
let loginPage;
let editarMovimentacaoPage;

async function login() {
  await loginPage.login(user.email, user.senha);
  await driver.wait(until.urlContains('/home'), 10000);
}

async function abrirDetalhesConta(nomeConta) {
  await driver.get(`${baseUrl}/home`);
  const xpathDetalhes = `//tr[td/a[normalize-space(text())='${nomeConta}']]//a[contains(@class, 'btn-primary') and contains(normalize-space(text()), 'Detalhes')]`;
  await driver.wait(until.elementLocated(By.xpath(xpathDetalhes)), 10000);
  const detalhesLink = await driver.findElement(By.xpath(xpathDetalhes));
  const detalhesUrl = await detalhesLink.getAttribute('href');

  const handlesAntes = await driver.getAllWindowHandles();
  await driver.switchTo().newWindow('tab');

  await driver.wait(async () => {
    const handlesAgora = await driver.getAllWindowHandles();
    return handlesAgora.length > handlesAntes.length;
  }, 10000);

  const handlesDepois = await driver.getAllWindowHandles();
  const novaAba = handlesDepois.find(h => !handlesAntes.includes(h));
  await driver.switchTo().window(novaAba);

  await driver.get(detalhesUrl);
  await driver.wait(until.urlContains('/contas/detalhes/'), 10000);
  return novaAba;
}

async function abrirEditarMovimentacao() {
  const xpathEditar = "//table//a[contains(text(),'Editar')]";
  await driver.wait(until.elementLocated(By.xpath(xpathEditar)), 10000);
  const editarLink = await driver.findElement(By.xpath(xpathEditar));

  await editarLink.click();
  await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);

  return await driver.getWindowHandle();
}

async function acessarEditarMovimentacao(nomeConta = 'Conta 3') {
  const originalWindow = await driver.getWindowHandle();
  const detalhesTab = await abrirDetalhesConta(nomeConta);
  const editarTab = await abrirEditarMovimentacao();
  return { originalWindow, detalhesTab, editarTab }; 
}

async function runAxe(driver) {
  await driver.executeScript(axeSource);
  return await driver.executeAsyncScript(function (done) {
    axe.run({
      runOnly: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'],
      resultTypes: ['violations'],
      impact: ['critical', 'serious']
    }, function (err, results) {
      if (err) done(err);
      else done(results);
    });
  });
}

async function isElementFocableAndVisible(element) {
    if (!element) return false;
    try {
        const isDisplayed = await element.isDisplayed();
        const isDisabled = await element.getAttribute('disabled');
        const tabIndex = await element.getAttribute('tabindex');

        return isDisplayed && (isDisabled === null || isDisabled === 'false') && (tabIndex !== '-1');
    } catch (error) {

        return false;
    }
}

describe('Acessibilidade - Página Editar Movimentação', () => {
  let originalWindow, detalhesTab, editarTab;

  before(async () => {
    const options = new chrome.Options();
    options.addArguments('--start-maximized');
    driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build();

    loginPage = new LoginPage(driver, baseUrl);
    editarMovimentacaoPage = new EditarMovimentacaoPage(driver);
  });

  beforeEach(async () => {
    await login();
    const abas = await acessarEditarMovimentacao();
    originalWindow = abas.originalWindow;
    detalhesTab = abas.detalhesTab;
    editarTab = abas.editarTab;
    await driver.switchTo().window(editarTab);
  });

  after(async () => {
    await driver.quit();
  });

//  it('323 - Deve ter zero violações de acessibilidade críticas ou sérias', async () => {
//    const results = await runAxe(driver);
//    expect(results.violations.length).to.equal(0, JSON.stringify(results.violations, null, 2));
//  });

  it('324 - Elementos interativos são focáveis e visíveis ao tabular', async () => {
    const body = await driver.findElement(By.css('body'));
    await body.sendKeys('\uE004'); // Tab
    for (let i = 0; i < 20; i++) {
      const active = await driver.switchTo().activeElement();
      const isVisible = await active.isDisplayed();
      expect(isVisible).to.be.true;
      await active.sendKeys('\uE004');
    }
  });

  it('325 - Campos possuem labels visíveis ou atributos ARIA', async () => {
    const inputs = await driver.findElements(By.css('input:not([type="hidden"]), select, textarea'));
    for (const input of inputs) {
      const id = await input.getAttribute('id');
      if (id) {
        const label = await driver.findElements(By.css(`label[for="${id}"]`));
        expect(label.length).to.be.greaterThan(0);
      } else {
        const aria = await input.getAttribute('aria-label') || await input.getAttribute('aria-labelledby');
        expect(aria).to.exist;
      }
    }
  });

  it('326 - Botão "Salvar Alterações" possui texto descritivo e tipo submit', async () => {
    const btn = await driver.findElement(By.css('button[type="submit"]'));
    const text = await btn.getText();
    expect(text).to.include('Salvar Alterações');
  });

it('327 - Deve garantir que campos com formato específico (valor, data) possuem informações acessíveis sobre o formato', async () => {
  const valorInput = await driver.findElement(By.id('valor'));

  const idAttr = await valorInput.getAttribute('id');
  const ariaDescId = await valorInput.getAttribute('aria-describedby');
  const ariaLabel = await valorInput.getAttribute('aria-label');

  if (ariaDescId) {

    const describedElem = await driver.findElement(By.id(ariaDescId));
    await driver.wait(until.elementIsVisible(describedElem), 5000);
    const text = await describedElem.getText();
    expect(text).to.include('mínimo: 0.01');
  } else if (ariaLabel) {
    expect(ariaLabel).to.include('mínimo: 0.01');
  } else {
 
    const labelElem = await driver.findElement(By.css(`label[for="${idAttr}"] .text-muted`));
    await driver.wait(until.elementIsVisible(labelElem), 5000);
    const labelText = await labelElem.getText();
    expect(labelText).to.include('(mínimo: 0.01)');
  }

  const camposData = ['data_movimentacao', 'data_pagamento'];
  for (const id of camposData) {
    const input = await driver.findElement(By.id(id));

    const ariaLabelData = await input.getAttribute('aria-label') || '';
    const placeholderData = await input.getAttribute('placeholder') || '';

    const labelElem = await driver.findElement(By.css(`label[for="${id}"]`));
    const labelText = await labelElem.getText();

    const acessibilidadeTexto = ariaLabelData || placeholderData || labelText;

    expect(acessibilidadeTexto).to.match(/(YYYY-MM-DD|ano-mês-dia|DD\/MM\/YYYY|data|formato)/i);

  }
});

it('328 - Deve garantir que a ordem de tabulação dos elementos do formulário segue uma sequência lógica no DOM', async () => {
        const originalWindow = await driver.getWindowHandle();
        let detalhesTab;
        let editarTab;

        try {
            detalhesTab = await abrirDetalhesConta('Conta 3');
            await driver.switchTo().window(detalhesTab);
            const editarBtn = await driver.findElement(By.css('table tbody tr:first-child a.btn-warning'));
            await editarBtn.click();

            await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
            const expectedFocusOrder = [
                'tipo',
                'data_movimentacao',
                'data_pagamento',
                'descricao',
                'interessado', // <-- ALTERADO: Interessado antes de valor
                'valor',       // <-- ALTERADO: Valor depois de interessado
                'conta_id',
                'situacao',
                'submit',
                'cancelar'
            ];
            const form = await driver.findElement(By.css('form'));
            const allFocableElements = await driver.findElements(By.css(
                'nav.navbar a:not(.dropdown-content a), nav.navbar button, ' +
                '.dropdown-content a, ' +
                'form input:not([type="hidden"]), form select, form button, form a.btn-secondary'
            ));

            let currentElement = null;
            let currentElementName = '';
            let actualFocusOrder = [];
            await driver.findElement(By.css('body')).sendKeys(Key.TAB);

            for (let i = 0; i < allFocableElements.length + 5; i++) {
                await driver.actions().sendKeys(Key.TAB).perform();
                await driver.sleep(100);

                let activeElement = await driver.switchTo().activeElement();
                let tagName = await activeElement.getTagName();
                let nameAttribute = await activeElement.getAttribute('name');
                let idAttribute = await activeElement.getAttribute('id');
                let textContent = await activeElement.getText();
                let typeAttribute = await activeElement.getAttribute('type');
                let classAttribute = await activeElement.getAttribute('class');

                let identifier = '';
                if (nameAttribute) {
                    identifier = nameAttribute;
                } else if (idAttribute) {
                    identifier = idAttribute;
                } else if (tagName === 'button' && textContent.toLowerCase().includes('salvar')) {
                    identifier = 'submit';
                } else if (tagName === 'a' && classAttribute.includes('btn-secondary') && textContent.toLowerCase().includes('cancelar')) {
                    identifier = 'cancelar';
                } else if (tagName === 'a' && textContent) {
                    identifier = textContent.trim();
                } else if (tagName === 'button' && textContent.toLowerCase().includes('contas')) {
                    identifier = 'contas_dropdown_btn';
                }

                if (identifier && !actualFocusOrder.includes(identifier)) {
                    actualFocusOrder.push(identifier);
                }
                if (actualFocusOrder.length >= expectedFocusOrder.length && actualFocusOrder.slice(-expectedFocusOrder.length).every((val, index) => val === expectedFocusOrder[index])) {
                    break;
                }
            }
            const formFocusOrder = actualFocusOrder.filter(item => expectedFocusOrder.includes(item));

            let startIndex = -1;
            for (let i = 0; i < formFocusOrder.length; i++) {
                if (formFocusOrder[i] === expectedFocusOrder[0]) {
                    startIndex = i;
                    break;
                }
            }

            if (startIndex === -1) {
                throw new Error(`O primeiro elemento esperado do formulário (${expectedFocusOrder[0]}) não foi encontrado na ordem de tabulação.`);
            }
            const actualFormFocusOrder = formFocusOrder.slice(startIndex, startIndex + expectedFocusOrder.length);

            expect(actualFormFocusOrder).to.deep.equal(expectedFocusOrder);

        } finally {

            const handlesAfter = await driver.getAllWindowHandles();
            if (editarTab && handlesAfter.includes(editarTab)) {
                await driver.switchTo().window(editarTab);
                await driver.close();
            }
            if (detalhesTab && handlesAfter.includes(detalhesTab)) {
                await driver.switchTo().window(detalhesTab);
                await driver.close();
            }
            await driver.switchTo().window(originalWindow);
        }
    });

  it('329 - Deve manter legibilidade e usabilidade da página com zoom de 200%', async () => {
    await driver.executeScript("document.body.style.zoom='200%'");
    const form = await driver.findElement(By.css('form'));
    const isVisible = await form.isDisplayed();
    expect(isVisible).to.be.true;

    const btn = await driver.findElement(By.css('button[type="submit"]'));
    const isBtnVisible = await btn.isDisplayed();
    const isBtnEnabled = await btn.isEnabled();
    expect(isBtnVisible).to.be.true;
    expect(isBtnEnabled).to.be.true;

    const scrollWidth = await driver.executeScript('return document.body.scrollWidth');
    const clientWidth = await driver.executeScript('return document.body.clientWidth');
    expect(scrollWidth).to.be.lessThan(clientWidth + 50);
  });
});
