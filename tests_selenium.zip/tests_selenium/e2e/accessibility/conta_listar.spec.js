import { Builder, By, Key, until } from 'selenium-webdriver';
import { Options } from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';
import AxeBuilder from 'axe-webdriverjs';
import LoginPage from '../../support/page_objects/LoginPage.js';

const BASE_URL = 'http://localhost:5000';
const USER_EMAIL = 'ordemAlfabetica@ordem.com';
const USER_PASSWORD = 'login_10';

let driver;
let loginPage;

async function getElementIdentifier(element) {
  const tag = await element.getTagName();
  const id = await element.getAttribute('id');
  const text = await element.getText();
  const className = await element.getAttribute('class');
  const name = await element.getAttribute('name');
  return `<${tag}${id ? `#${id}` : ''}${className ? `.${className.replace(/\s+/g, '.')}` : ''}${name ? ` name="${name}"` : ''}> "${text}"`;
}

describe('Acessibilidade - Página Lista Contas', function() {
  this.timeout(60000); // Aumenta o timeout para operações do Selenium

  before(async () => {
    let chromeOptions = new Options();
    // chromeOptions.addArguments('--headless'); // Descomente para execução headless
    chromeOptions.addArguments('--start-maximized');
    chromeOptions.addArguments('--disable-gpu');
    chromeOptions.addArguments('--no-sandbox');
    chromeOptions.addArguments('--disable-dev-shm-usage');

    driver = await new Builder().forBrowser('chrome').setChromeOptions(chromeOptions).build();
    loginPage = new LoginPage(driver, BASE_URL);

    // Realiza o login uma vez para toda a suíte
    await loginPage.login(USER_EMAIL, USER_PASSWORD);
    await driver.wait(until.urlContains('/home'), 15000);
  });

  beforeEach(async () => {
    // Navega para a página de listagem de contas antes de cada teste
    await driver.get(`${BASE_URL}/contas`);
    await driver.wait(until.urlContains('/contas'), 5000);
    await driver.wait(until.elementLocated(By.css('table')), 5000); // Espera a tabela carregar
  });

  after(async () => {
    if (driver) {
      await driver.quit();
    }
  });

  // 166 - Deve ter uma tabela com cabeçalho e roles semânticos adequados
  it('166 - Deve ter uma tabela com cabeçalho e roles semânticos adequados', async () => {
    const table = await driver.findElement(By.css('table'));
    const thead = await driver.findElement(By.css('thead'));
    const ths = await driver.findElements(By.css('thead th'));

    expect(await table.isDisplayed()).to.be.true;
    expect(await thead.isDisplayed()).to.be.true;
    expect(ths.length).to.be.at.least(1); // Garante que há pelo menos um cabeçalho

    for (const th of ths) {
      const scopeAttr = await th.getAttribute('scope');
      expect(scopeAttr).to.match(/col|row/);
    }
  });

  // 167 - Os botões possuem textos claros e acessíveis
  it('167 - Os botões possuem textos claros e acessíveis', async () => {
    const textosEsperados = ['Detalhes', 'Editar', 'Excluir', 'Adicionar Conta'];
    for (const texto of textosEsperados) {
      // Tenta encontrar o elemento pelo texto, seja botão ou link
      const element = await driver.wait(until.elementLocated(By.xpath(`//button[contains(text(),'${texto}')] | //a[contains(text(),'${texto}')]`)), 5000, `Elemento com texto "${texto}" não encontrado.`);
      expect(await element.isDisplayed()).to.be.true;
      expect(await element.getText()).to.not.be.empty;
    }
  });

  // 168 - O formulário de exclusão possui token CSRF oculto
  it('168 - O formulário de exclusão possui token CSRF oculto', async () => {
    const forms = await driver.findElements(By.css('form'));
    expect(forms.length).to.be.at.least(1); // Deve haver pelo menos um formulário

    for (const form of forms) {
      const csrfInput = await form.findElement(By.css('input[name="csrf_token"]'));
      expect(await csrfInput.isDisplayed()).to.be.false; // Deve ser oculto
      expect(await csrfInput.getAttribute('type')).to.equal('hidden');
    }
  });

// 169 - Botão "Excluir" confirma exclusão e é focável via teclado
it('169 - Botão "Excluir" confirma exclusão e é focável via teclado', async () => {
  const deleteButton = await driver.findElement(By.css('form button.btn-danger'));
  await driver.executeScript("arguments[0].focus();", deleteButton);

  const activeElement = await driver.switchTo().activeElement();
  const activeId = await activeElement.getId();
  const expectedId = await deleteButton.getId();

  expect(activeId).to.deep.equal(expectedId);
});

// 170 - Link "Adicionar Conta" é focável e possui texto descritivo
it('170 - Link "Adicionar Conta" é focável e possui texto descritivo', async () => {
  const addAccountLink = await driver.findElement(By.css('a.btn-success'));
  expect(await addAccountLink.isDisplayed()).to.be.true;
  expect(await addAccountLink.getText()).to.include('Adicionar Conta');

  await driver.executeScript("arguments[0].focus();", addAccountLink);
  const activeElement = await driver.switchTo().activeElement();

  const activeId = await activeElement.getId();
  const expectedId = await addAccountLink.getId();

  expect(activeId).to.deep.equal(expectedId);
});

// 171 - Deve focar elementos da tabela corretamente com TAB
it('171 - Deve focar elementos da tabela corretamente com TAB', async () => {
  await driver.get(`${BASE_URL}/contas`);
  await driver.wait(until.urlContains('/contas'), 5000);
  await driver.wait(until.elementLocated(By.css('a.btn-success')), 5000);

  // 1. Foca o botão "Adicionar Conta"
  const adicionarContaBtn = await driver.findElement(By.css('a.btn-success'));
  await driver.executeScript("arguments[0].focus();", adicionarContaBtn);
  let active = await driver.switchTo().activeElement();
  let text = await active.getText();
  let className = await active.getAttribute('class');

  expect(text).to.include('Adicionar Conta');
  expect(className).to.include('btn-success');

  // 2. Tab para "Detalhes"
  await driver.actions().sendKeys(Key.TAB).perform();
  active = await driver.switchTo().activeElement();
  text = await active.getText();
  className = await active.getAttribute('class');

  expect(text).to.include('Detalhes');
  expect(className).to.include('btn-primary');

  // 3. Tab para "Editar"
  await driver.actions().sendKeys(Key.TAB).perform();
  active = await driver.switchTo().activeElement();
  text = await active.getText();
  className = await active.getAttribute('class');

  expect(text).to.include('Editar');
  expect(className).to.include('btn-warning');

  // 4. Tab para "Excluir"
  await driver.actions().sendKeys(Key.TAB).perform();
  active = await driver.switchTo().activeElement();
  text = await active.getText();
  className = await active.getAttribute('class');

  expect(text).to.include('Excluir');
  expect(className).to.include('btn-danger');
});

  // 172 - Deve passar na verificação de contraste de cores (Placeholder)

  it('172 - Deve passar na verificação de contraste de cores (Acessibilidade)', async () => {
    const results = await new AxeBuilder(driver).analyze();

    // Filtra apenas violações relacionadas a contraste de cor
    const contrastViolations = results.violations.filter(v => v.id === 'color-contrast');

    if (contrastViolations.length > 0) {
      console.log('Problemas de contraste de cores encontrados:');
      console.log(JSON.stringify(contrastViolations, null, 2));
    }

    expect(contrastViolations.length).to.equal(0, 'Problemas de contraste de cores encontrados.');
  });

  });

