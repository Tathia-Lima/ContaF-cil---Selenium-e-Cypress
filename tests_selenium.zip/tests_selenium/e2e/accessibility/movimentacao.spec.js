// Testes de Acessibilidade - Página Criar Movimentação (Selenium WebDriver)

import { Builder, By, Key, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';

// Importa os Page Objects necessários
import LoginPage from '../../support/page_objects/LoginPage.js';
import MovimentacaoPage from '../../support/page_objects/MovimentacaoPage.js'; // O Page Object de Movimentação

const baseUrl = 'http://localhost:5000';
// Usuário de teste para login
const user = { email: 'movimentacao@movimentacao.com', senha: 'login_10' };

let driver; // Instância do WebDriver
let loginPage; // Instância do Page Object de Login
let movimentacaoPage; // Instância do Page Object de Movimentação

/**
 * Função auxiliar para validar a presença e visibilidade de mensagens de erro ou sucesso.
 * @param {string} mensagem O texto esperado na mensagem.
 * @param {string} [seletor='.alert'] O seletor CSS do elemento que contém a mensagem.
 */
async function validarMensagem(mensagem, seletor = '.alert') {
    try {
        const elementoMensagem = await driver.wait(until.elementLocated(By.css(seletor)), 5000);
        expect(await elementoMensagem.isDisplayed()).to.be.true;
        expect(await elementoMensagem.getText()).to.include(mensagem);
        console.log(`Mensagem validada: "${mensagem}"`);
    } catch (error) {
        throw new Error(`Mensagem "${mensagem}" não encontrada ou não visível: ${error.message}`);
    }
}

describe('Acessibilidade - Página Criar Movimentação', function () {
    this.timeout(40000); // Aumenta o timeout para testes de acessibilidade

    before(async () => {
        driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(new chrome.Options().addArguments('--start-maximized'))
            .build();

        loginPage = new LoginPage(driver, baseUrl);
        movimentacaoPage = new MovimentacaoPage(driver, baseUrl);

        // Realiza o login uma vez antes de todos os testes
        await loginPage.login(user.email, user.senha);
        // Verifica se o login foi bem-sucedido e a URL mudou para /home
        await driver.wait(until.urlContains('/home'), 10000);
    });

    beforeEach(async () => {
        // Navega para a página de criação de movimentação antes de cada teste
        await movimentacaoPage.visitar();
        // Nota: Cypress tem `setupClockBasedOnServerDate` e `restoreClock`.
        // Selenium não tem um equivalente direto para mocking do clock do navegador.
        // Se a lógica da data for crítica e baseada no cliente, isso exigiria uma solução de mock de tempo mais complexa via `executeScript`.
    });

    after(async () => {
        await driver.quit();
    });

    // --- Testes de Acessibilidade ---

    // 1. Navegação por Teclado (WCAG 2.1.1, 2.4.3, 2.4.7)
    // Teste Manual: Ordem de foco lógica e visibilidade do indicador de foco
    it('202 - Deve verificar a ordem de foco lógica e a visibilidade do indicador de foco (MANUAL)', async () => {
        console.log('**Teste Manual (202):** Comece no topo da página e pressione a tecla `Tab` repetidamente.');
        console.log('**Verifique:**');
        console.log('1. O foco deve se mover de forma lógica e previsível por todos os elementos interativos (links da navbar, campos do formulário, botões "Salvar" e "Cancelar").');
        console.log('2. A ordem deve ser da esquerda para a direita, de cima para baixo.');
        console.log('3. O indicador de foco deve ser sempre visível e ter contraste suficiente com o fundo.');
    });

    // Teste Automatizado: Focabilidade de elementos interativos
    it('203 - Deve garantir que todos os elementos interativos são focáveis via teclado (abordagem robusta)', async () => {
        // Elementos da navbar que são visíveis por padrão
        let navbarElements = await driver.findElements(By.css('nav.navbar a:not(.dropdown-content a), nav.navbar button'));
        for (const el of navbarElements) {
            expect(await el.isDisplayed()).to.be.true; // Deve estar visível
            const tagName = await el.getTagName();
            const isDisabled = await el.getAttribute('disabled') !== null;
            const tabIndex = parseInt(await el.getAttribute('tabindex') || '0'); // Default 0 if not set

            expect(isDisabled, `Elemento ${tagName} não deve estar desabilitado`).to.be.false;
            expect(tabIndex, `Elemento ${tagName} não deve ter tabindex=-1`).to.not.equal(-1);
        }

        // Testar elementos do dropdown APÓS abri-lo
        try {
            const dropdownButton = await driver.findElement(By.css('button.dropbtn'));
            await dropdownButton.click(); // Clica no botão "Contas" para abrir o dropdown
            await driver.wait(until.elementLocated(By.css('.dropdown-content a')), 2000); // Espera que os links apareçam

            let dropdownLinks = await driver.findElements(By.css('.dropdown-content a'));
            for (const el of dropdownLinks) {
                expect(await el.isDisplayed()).to.be.true; // Agora devem estar visíveis
                const tagName = await el.getTagName();
                const isDisabled = await el.getAttribute('disabled') !== null;
                const tabIndex = parseInt(await el.getAttribute('tabindex') || '0');

                expect(isDisabled, `Elemento ${tagName} no dropdown não deve estar desabilitado`).to.be.false;
                expect(tabIndex, `Elemento ${tagName} no dropdown não deve ter tabindex=-1`).to.not.equal(-1);
            }
        } catch (error) {
            console.warn('Aviso: Não foi possível interagir com o dropdown da navbar. Verifique se ele existe ou se o seletor está correto.');
        }

        // Campos do formulário: inputs, selects, buttons
        // Excluímos inputs do tipo 'hidden' da verificação de visibilidade e focabilidade
        let formElements = await driver.findElements(By.css('form input:not([type="hidden"]), form select, form button'));
        for (const el of formElements) {
            expect(await el.isDisplayed()).to.be.true; // Deve estar visível
            const tagName = await el.getTagName();
            const type = await el.getAttribute('type'); // Pode ser null para select/button
            const isDisabled = await el.getAttribute('disabled') !== null;
            const tabIndex = parseInt(await el.getAttribute('tabindex') || '0');

            expect(isDisabled, `Campo ${tagName} (type: ${type}) não deve estar desabilitado`).to.be.false;
            expect(tabIndex, `Campo ${tagName} (type: ${type}) não deve ter tabindex=-1`).to.not.equal(-1);
        }

        // Links de ação (Cancelar)
        const cancelButton = await driver.findElement(By.css('a.btn-secondary'));
        expect(await cancelButton.isDisplayed()).to.be.true;
        expect(await cancelButton.getAttribute('disabled')).to.be.null; // 'disabled' deve ser null se não estiver desabilitado
        expect(parseInt(await cancelButton.getAttribute('tabindex') || '0')).to.not.equal(-1);
    });

    // Teste Manual: Operação de campos via teclado
    it('204 - Deve permitir a operação de todos os campos de formulário usando apenas o teclado (MANUAL)', async () => {
        console.log('**Teste Manual (204):** Tente interagir com todos os campos do formulário usando apenas o teclado.');
        console.log('**Verifique:**');
        console.log('1. Campos de Texto: Digite, selecione, copie/cole.');
        console.log('2. Campos de Data: Digite a data ou use o seletor de data (se houver) com setas e Enter.');
        console.log('3. Selects: Abra, navegue e selecione opções com Enter/Espaço e setas.');
        console.log('4. Radio Buttons: Navegue entre as opções com setas e selecione com Espaço.');
        console.log('5. Botões: Ative com Enter ou Espaço.');
    });

    // 2. Rótulos e Instruções de Formulário (WCAG 1.3.1, 3.3.2)
    it('205 - Deve verificar que todos os campos de formulário possuem rótulos associados', async () => {
        // Campos de input e select visíveis e com atributo 'name'
        const formInputsAndSelects = await driver.findElements(By.css('form input[name]:not([type="hidden"]), form select[name]'));
        for (const el of formInputsAndSelects) {
            const id = await el.getAttribute('id');
            const name = await el.getAttribute('name');
            if (id) {
                const label = await driver.findElement(By.css(`label[for="${id}"]`));
                expect(await label.isDisplayed()).to.be.true;
            } 
        }
        // Radio buttons - verificação mais específica para garantir que cada um tem um label
        const radioButtons = await driver.findElements(By.css('input[name="situacao"]'));
        for (const radio of radioButtons) {
            const id = await radio.getAttribute('id');
            const label = await driver.findElement(By.css(`label[for="${id}"]`));
            expect(await label.isDisplayed()).to.be.true;
        }
    });

    // Teste Manual: Rótulos descritivos e claros
    it('206 - Deve verificar que os rótulos são descritivos e claros (MANUAL)', async () => {
        console.log('**Teste Manual (206):** Leia os rótulos de cada campo do formulário.');
        console.log('**Verifique:** Os rótulos devem ser claros, concisos e descrever a finalidade do campo de forma inequívoca.');
    });

    it('207 - Deve verificar o agrupamento semântico dos Radio Buttons', async () => {
        // Verifica se existe um fieldset
        const fieldset = await driver.findElement(By.css('fieldset'));
        expect(await fieldset.isDisplayed()).to.be.true;

        // Verifica se o legend está dentro do fieldset e contém o texto "Situação"
        const legend = await fieldset.findElement(By.css('legend'));
        expect(await legend.getText()).to.include('Situação');
        expect(await legend.isDisplayed()).to.be.true;

        // Verifica se os radio buttons estão dentro do fieldset
        const radiosInFieldset = await fieldset.findElements(By.css('input[name="situacao"]'));
        expect(radiosInFieldset.length).to.equal(2);
    });

    // 3. Tratamento de Erros (WCAG 3.3.1, 3.3.3)
    it('208 - Deve exibir mensagens de erro claras para campos obrigatórios', async () => {
      const mensagensEsperadas = [
        'Selecione o tipo de movimentação.',
        'Informe a data da movimentação.',
        'Informe a data de pagamento.',
        'Descrição é obrigatória.',
        'Informe um valor.',
        'Você precisa selecionar uma conta.'
      ];

      // Submete o formulário vazio
      await driver.findElement(By.css('button[type="submit"]')).click();

      // Aguarda mensagens visíveis
      await driver.sleep(500); // ou aguarde por um seletor se possível

      // Captura todas as mensagens de erro visíveis
      const mensagensErro = await driver.findElements(By.css('.alert, .alert-danger'));
      const textos = await Promise.all(mensagensErro.map(el => el.getText()));

      // Valida todas as mensagens esperadas
      for (const esperada of mensagensEsperadas) {
        const encontrada = textos.some(texto => texto.includes(esperada));
        expect(encontrada, `Mensagem "${esperada}" não foi encontrada`).to.be.true;
      }
    });


    it('209 - Deve exibir mensagem de erro para valor não numérico', async () => {
        await movimentacaoPage.preencherFormulario({
            tipo: 'receita',
            dataMovimentacao: '2025-06-20',
            dataPagamento: '2025-06-20',
            descricao: 'Teste valor não numérico',
            valor: 'abc', // Valor não numérico
            conta: 'Conta 1', // Certifique-se que 'Conta 1' existe
            situacao: 'pago'
        });
        await movimentacaoPage.submeter();
        await validarMensagem('Valor inválido.');
    });

    it('210 - Deve exibir mensagem de erro para descrição com mais de 30 caracteres', async () => {
        const descricaoLonga = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'; // 31 caracteres
        await movimentacaoPage.preencherFormulario({
            tipo: 'receita',
            dataMovimentacao: '2025-06-20',
            dataPagamento: '2025-06-20',
            descricao: descricaoLonga,
            valor: 100,
            conta: 'Conta 1',
            situacao: 'pago'
        });
        await movimentacaoPage.submeter();
        await validarMensagem('Descrição deve ter no máximo 30 caracteres.');
        // Verifica se permanece na página de formulário (URL ainda contém /movimentacao)
        expect(await driver.getCurrentUrl()).to.include('/movimentacao');
    });

    // Teste Manual: Foco movido para o primeiro campo com erro
    it('211 - Deve verificar que o foco é movido para o primeiro campo com erro (MANUAL/LEITOR DE TELA)', async () => {
        console.log('**Teste Manual (211):** Submeta o formulário com múltiplos erros (ex: tipo vazio, descrição longa).');
        console.log('**Verifique:**');
        console.log('1. O foco do teclado deve se mover para o primeiro campo que contém um erro.');
        console.log('2. Use um leitor de tela para verificar se o erro é anunciado automaticamente.');
    });

    // 4. Contraste de Cores (WCAG 1.4.3)
    // Teste Manual/Ferramenta: Contraste de cores
    it('212 - Deve verificar o contraste de cores do texto e elementos da UI (MANUAL/FERRAMENTA)', async () => {
        console.log('**Teste Manual/Ferramenta (212):** Use uma ferramenta de verificação de contraste (ex: WebAIM Contrast Checker, Axe DevTools) para analisar o contraste de cores.');
        console.log('**Verifique:**');
        console.log('1. Texto dos rótulos e fundo do formulário.');
        console.log('2. Texto dos inputs e fundo dos inputs.');
        console.log('3. Texto das mensagens flash e fundo das mensagens flash.');
        console.log('4. Texto dos links da navbar e fundo da navbar.');
        console.log('5. Indicador de foco (contorno ao tabular) e o elemento focado.');
        console.log('**Resultado Esperado:** O contraste deve atender aos requisitos mínimos (4.5:1 para texto normal, 3:1 para texto grande).');
    });

    // 5. Compatibilidade com Leitor de Tela (WCAG 1.3.1, 4.1.2)
    // Teste Manual: Leitura correta de rótulos e tipos de campo por leitor de tela
    it('213 - Deve verificar a leitura correta de rótulos e tipos de campo por leitor de tela (MANUAL/LEITOR DE TELA)', async () => {
        console.log('**Teste Manual (213):** Navegue pela página usando um leitor de tela (ex: NVDA). Interaja com cada campo do formulário.');
        console.log('**Verifique:** O leitor de tela deve anunciar corretamente o rótulo de cada campo e o tipo de input (ex: "Tipo da Movimentação, caixa de combinação", "Data da Movimentação, campo de data", "Descrição, campo de edição"). Para radio buttons, deve anunciar "Pago, botão de rádio, marcado" ou "Pendente, botão de rádio, não marcado".');
    });

    // Teste Manual: Anúncio automático de mensagens flash por leitor de tela
    it('214 - Deve verificar o anúncio automático de mensagens flash por leitor de tela (MANUAL/LEITOR DE TELA)', async () => {
        console.log('**Teste Manual (214):** Submeta o formulário para gerar uma mensagem flash (sucesso ou erro).');
        console.log('**Verifique:** O leitor de tela deve anunciar a mensagem flash automaticamente assim que ela aparecer, sem que o usuário precise navegar até ela. (Isso geralmente requer `role="alert"` ou `aria-live="assertive"` nas divs de alerta).');
    });

    // 6. Estrutura e Semântica (WCAG 1.3.1)
    it('215 - Deve verificar o uso semântico de headings', async () => {
        console.log('Executando teste 215: Verificando uso semântico de headings.');
        const h2 = await driver.findElement(By.css('h2'));
        expect(await h2.getText()).to.include('Criar Movimentação');
        expect(await h2.isDisplayed()).to.be.true;
        // Se houver um h1 principal no base.html, pode-se verificar que não há outro h1 aqui
        // const h1Elements = await driver.findElements(By.css('h1'));
        // expect(h1Elements.length).to.equal(0, 'Não deve haver múltiplos h1 na página.');
    });

    // Teste Manual/Ferramenta: Uso correto de atributos ARIA
    it('216 - Deve verificar o uso correto de atributos ARIA (MANUAL/FERRAMENTA)', async () => {
        console.log('**Teste Manual/Ferramenta (216):** Use ferramentas como Axe DevTools ou inspecione o HTML para verificar o uso de atributos ARIA.');
        console.log('**Verifique:** Atributos ARIA (ex: `aria-label`, `aria-describedby`, `aria-expanded`) devem ser usados corretamente para melhorar a acessibilidade de componentes complexos (como dropdowns, seletor de data, etc.) quando o HTML semântico não é suficiente.');
    });

    // 7. Responsividade e Zoom (WCAG 1.4.4, 1.4.10)
    // Teste Manual: Conteúdo legível e utilizável com zoom
    it('217 - Deve garantir que o conteúdo é legível e utilizável com zoom de 200% e 400% (MANUAL)', async () => {
        console.log('**Teste Manual (217):** Aumente o zoom do navegador para 200% e depois para 400%.');
        console.log('**Verifique:** O conteúdo da página deve se adaptar, sem sobreposição, corte de texto ou necessidade de rolagem horizontal. Todos os elementos devem permanecer acessíveis e legíveis.');
    });

    // Teste Manual: Layout responsivo em diferentes tamanhos de tela
    it('218 - Deve garantir que o layout é responsivo e utilizável em diferentes tamanhos de tela (MANUAL)', async () => {
        console.log('**Teste Manual (218):** Redimensione a janela do navegador para simular telas menores (ex: mobile, tablet).');
        console.log('**Verifique:** O layout deve se ajustar fluidamente, e todos os elementos devem ser acessíveis e utilizáveis sem rolagem horizontal.');
    });

    it('219 - Deve verificar que o título da página é único e descritivo', async () => {
        console.log('Executando teste 219: Verificando título da página.');
        const pageTitle = await driver.getTitle();
        expect(pageTitle).to.match(/Movimentação/i);
    });
});
