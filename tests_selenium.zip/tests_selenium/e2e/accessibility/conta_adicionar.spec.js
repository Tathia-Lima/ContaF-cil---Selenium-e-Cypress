// e2e/accessibility/conta_adicionar.spec.js
import { Builder, By, until, Key } from 'selenium-webdriver';
import { Options } from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';
import LoginPage from '../../support/page_objects/LoginPage.js'; // Ajuste o caminho
import ContaAdicionarPage from '../../support/page_objects/ContaAdicionarPage.js'; // Ajuste o caminho

const BASE_URL = 'http://localhost:5000';
const USER_EMAIL = 'LoginPage@LoginPage.com';
const USER_PASSWORD = 'login_10';

let driver;
let loginPage;
let contaAdicionarPage;

describe('Acessibilidade - Página Adicionar Conta', function( ) {
  this.timeout(60000);

  before(async () => {
    let chromeOptions = new Options();
    // chromeOptions.addArguments('--headless');
    chromeOptions.addArguments('--start-maximized');
    chromeOptions.addArguments('--disable-gpu');
    chromeOptions.addArguments('--no-sandbox');
    chromeOptions.addArguments('--disable-dev-shm-usage');

    driver = await new Builder().forBrowser('chrome').setChromeOptions(chromeOptions).build();
    loginPage = new LoginPage(driver, BASE_URL);
    contaAdicionarPage = new ContaAdicionarPage(driver, BASE_URL);

    // Login uma vez para a sessão
    await loginPage.login(USER_EMAIL, USER_PASSWORD);
    await driver.wait(until.urlContains('/home'), 15000);
  });

  beforeEach(async function() {
    await contaAdicionarPage.visit();
    await driver.sleep(500); // Pequena pausa para renderização
  });

  after(async () => {
    if (driver) {
      await driver.quit();
    }
  });

  // 139 - Deve conter apenas um elemento <main> na página
  it('139 - Deve conter apenas um elemento <main> na página', async () => {
    const mainElements = await contaAdicionarPage.getMainElements();
    expect(mainElements.length).to.equal(1);
  });

  // 140 - Deve conter um heading visível e semântico <h2> com o texto correto
  it('140 - Deve conter um heading visível e semântico <h2> com o texto correto', async () => {
    const h2Element = await driver.findElement(contaAdicionarPage.pageTitle);
    expect(await h2Element.getText()).to.equal('Adicionar Conta');
    expect(await h2Element.isDisplayed()).to.be.true;
    expect(await h2Element.getTagName()).to.equal('h2');
  });

  // 141 - O campo "nome" deve ter rótulo associado via <label for="..."> e id correspondente
  it('141 - O campo "nome" deve ter rótulo associado via <label for="..."> e id correspondente', async () => {
    const labelNome = await driver.findElement(contaAdicionarPage.nomeLabel);
    expect(await labelNome.isDisplayed()).to.be.true;
    expect(await labelNome.getText()).to.include('Nome');

    const inputNome = await contaAdicionarPage.getNomeInput();
    expect(await inputNome.isDisplayed()).to.be.true;
    expect(await inputNome.getAttribute('id')).to.equal('nome');
    expect(await inputNome.getAttribute('name')).to.equal('nome');
  });

  // 142 - O campo "nome" deve ser acessível por teclado (focável)
  it('142 - O campo "nome" deve ser acessível por teclado (focável)', async () => {
    const nomeInput = await contaAdicionarPage.getNomeInput();
    await driver.executeScript("arguments[0].focus();", nomeInput);
    const activeElement = await driver.switchTo().activeElement();
    expect(await activeElement.getAttribute('id')).to.equal('nome');
  });

  // 143 - O formulário deve conter botão do tipo submit e botão de cancelamento acessíveis via teclado
  it('143 - O formulário deve conter botão do tipo submit e botão de cancelamento acessíveis via teclado', async () => {
    const salvarButton = await contaAdicionarPage.getSalvarButton();
    expect(await salvarButton.getText()).to.include('Salvar');
    expect(await salvarButton.getAttribute('type')).to.equal('submit');
    
    await driver.executeScript("arguments[0].focus();", salvarButton);
    let activeElement = await driver.switchTo().activeElement();
    expect(await activeElement.getText()).to.include('Salvar');

    const cancelarLink = await contaAdicionarPage.getCancelarLink();
    expect(await cancelarLink.getText()).to.include('Cancelar');
    
    await driver.executeScript("arguments[0].focus();", cancelarLink);
    activeElement = await driver.switchTo().activeElement();
    expect(await activeElement.getText()).to.include('Cancelar');
  });

  // 144 - Deve exibir mensagem de erro acessível se o campo "nome" for enviado vazio
  it('144 - Deve exibir mensagem de erro acessível se o campo "nome" for enviado vazio', async () => {
    await contaAdicionarPage.typeNome(''); // Garante que o campo está vazio
    await contaAdicionarPage.clickSalvar();

    // Espera pela mensagem de alerta. Ajustado para o seletor .alert
    const alertElement = await driver.wait(until.elementLocated(contaAdicionarPage.flashMessage), 5000);
    expect(await alertElement.isDisplayed()).to.be.true;
    expect(await alertElement.getText()).to.include('O nome da conta é obrigatório.');
    // Se o seu alerta tiver role="alert" ou aria-live, você pode adicionar a verificação aqui:
    // expect(await alertElement.getAttribute('role')).to.equal('alert');
  });

it('145 - O formulário deve ser navegável via teclado (tabindex natural)', async () => {
  // Lista da ordem esperada dos elementos ao pressionar Tab
  const ordemEsperada = [
    'a.brand',
    'xpath://a[text()="Home"]',
    'button.dropbtn',
    'xpath://a[text()="Adicionar"]',
    'xpath://a[text()="Listar"]',
    'xpath://a[text()="Criar Movimentação"]',
    'xpath://a[text()="Resumo Mensal"]',
    'xpath://a[text()="Sair"]',
    'input#nome',
    'button[type="submit"]',
    'a.btn-secondary'
  ];

  for (const selector of ordemEsperada) {
    // Pressiona TAB (tecla unicode \uE004)
    await driver.actions().sendKeys('\uE004').perform();

    // Espera o elemento ativo e recupera
    const activeElement = await driver.switchTo().activeElement();

    // Define como buscar o seletor
    let esperado;
    if (selector.startsWith('xpath:')) {
      esperado = await driver.findElement(By.xpath(selector.replace('xpath:', '')));
    } else {
      esperado = await driver.findElement(By.css(selector));
    }

    // Compara os elementos: o ativo no momento com o esperado
    const isSame = await driver.executeScript(
      'return arguments[0] === arguments[1];',
      activeElement,
      esperado
    );

    if (!isSame) {
      const tag = await activeElement.getTagName();
      const id = await activeElement.getAttribute('id');
      const text = await activeElement.getText();
      throw new Error(`Foco esperado em "${selector}", mas estava em <${tag} id="${id}"> "${text}"`);
    }
  }
});

  // 146 - Botões "Salvar" e "Cancelar" devem ser acessíveis com foco via teclado
  it('146 - Botões "Salvar" e "Cancelar" devem ser acessíveis com foco via teclado', async () => {
    const salvarButton = await contaAdicionarPage.getSalvarButton();
    await driver.executeScript("arguments[0].focus();", salvarButton);
    let activeElement = await driver.switchTo().activeElement();
    expect(await activeElement.getText()).to.include('Salvar');

    const cancelarLink = await contaAdicionarPage.getCancelarLink();
    await driver.executeScript("arguments[0].focus();", cancelarLink);
    activeElement = await driver.switchTo().activeElement();
    expect(await activeElement.getText()).to.include('Cancelar');
  });

  // 147 - Deve exibir mensagem de erro se campo "nome" estiver vazio após envio
  it('147 - Deve exibir mensagem de erro se campo "nome" estiver vazio após envio', async () => {
    await contaAdicionarPage.typeNome(''); // Garante que o campo está vazio
    await contaAdicionarPage.clickSalvar();
    
    // Espera que a URL permaneça a mesma ou inclua '/contas/adicionar'
    await driver.wait(until.urlContains('/contas/adicionar'), 5000);
    expect(await driver.getCurrentUrl()).to.include('/contas/adicionar');

    // Verifica a mensagem de erro (reutiliza a lógica do teste 144)
    const alertElement = await driver.wait(until.elementLocated(contaAdicionarPage.flashMessage), 5000);
    expect(await alertElement.isDisplayed()).to.be.true;
    expect(await alertElement.getText()).to.include('O nome da conta é obrigatório.');
  });
});
