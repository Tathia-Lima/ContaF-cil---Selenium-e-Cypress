// e2e/accessibility/conta_detalhes.spec.js
import { Builder, By, until, Key } from 'selenium-webdriver';
import { Options } from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';
import LoginPage from '../../support/page_objects/LoginPage.js';
import ContaDetalhesPage from '../../support/page_objects/ContaDetalhesPage.js';

const BASE_URL = 'http://localhost:5000';
const USER_EMAIL = 'conta_detalhes@conta.com'; // Email do usuário que possui as contas de teste
const USER_PASSWORD = 'login_10';

// Nomes das contas de teste que VOCÊ DEVE CONFIGURAR NO SEU AMBIENTE
// e corresponder aos IDs usados nos testes funcionais
const CONTA_NOME_COM_DADOS = 'Conta 1'; // Ex: Para a conta com muitos dados/movimentações
const CONTA_NOME_SALDO_NEGATIVO = 'Conta 4'; // Ex: Para a conta com saldo negativo
const CONTA_NOME_SALDO_POSITIVO = 'Conta 1'; // Ex: Para a conta com saldo positivo (pode ser a mesma CONTA_NOME_COM_DADOS)
const CONTA_NOME_SEM_DADOS = 'Conta 5'; // Ex: Para a conta sem movimentações

// Cores para validação (usando regex para aceitar rgb ou rgba )
const greenColorRegex = /(?:rgb|rgba)\(0,\s*255,\s*0(?:,\s*1)?\)/;
const redColorRegex = /(?:rgb|rgba)\(255,\s*36,\s*0(?:,\s*1)?\)/;
const yellowColorRegex = /(?:rgb|rgba)\(255,\s*152,\s*0(?:,\s*1)?\)/;

let driver;
let loginPage;
let contaDetalhesPage;

describe('Acessibilidade e Navegação - Página Detalhes da Conta (Selenium)', function() {
    this.timeout(60000);

    before(async () => {
        let chromeOptions = new Options();
        // chromeOptions.addArguments('--headless'); // Descomente para executar em modo headless (sem interface gráfica)
        chromeOptions.addArguments('--start-maximized');
        chromeOptions.addArguments('--disable-gpu');
        chromeOptions.addArguments('--no-sandbox');
        chromeOptions.addArguments('--disable-dev-shm-usage');

        driver = await new Builder().forBrowser('chrome').setChromeOptions(chromeOptions).build();
        loginPage = new LoginPage(driver, BASE_URL);
        contaDetalhesPage = new ContaDetalhesPage(driver, BASE_URL);

        // Login inicial para todos os testes
        await loginPage.login(USER_EMAIL, USER_PASSWORD);
        await driver.wait(until.urlContains('/home'), 15000);
    });

    // Função auxiliar para abrir a conta certa e garantir que não abre nova aba
    async function abrirDetalhesContaParaAcessibilidade(nomeConta, page = 1) {
        // Volta para a página home para garantir o ponto de partida limpo
        await driver.get(`${BASE_URL}/home`);
        await driver.wait(until.urlContains('/home'), 5000);
        await driver.wait(until.elementLocated(By.css('table.table')), 5000);

        // Encontra o link "Detalhes" na linha da conta com o nome especificado
        const detalhesLink = await driver.wait(
            until.elementLocated(
                By.xpath(`//tr[.//a[normalize-space(text())='${nomeConta}']]//a[contains(text(), 'Detalhes')]`)
            ), 10000, `Link 'Detalhes' para a conta '${nomeConta}' não encontrado na home.`
        );

        // Remove o atributo target="_blank" para forçar a abertura na mesma aba
        await driver.executeScript("arguments[0].removeAttribute('target')", detalhesLink);

        // Clica no link
        await detalhesLink.click();

        // Confirma que a navegação para a página de detalhes ocorreu na mesma aba
        await driver.wait(until.urlContains('/contas/detalhes/'), 10000, 'A navegação para a página de detalhes falhou.');
        await driver.wait(until.elementLocated(By.css('h2')), 5000);

        // Se uma página específica for solicitada (para testes de paginação, por exemplo)
        if (page > 1) {
            await driver.get(`${await driver.getCurrentUrl().then(url => url.split('?')[0])}?page=${page}`);
            await driver.wait(until.urlContains(`page=${page}`), 5000);
            await driver.sleep(500); // Pequena pausa para carregar dados da página
        }
    }

    // O beforeEach agora vai sempre para a Conta de Dados (CONTA_NOME_COM_DADOS) na página 3
    // para a maioria dos testes de acessibilidade que precisam de dados para funcionar.
    beforeEach(async function() {
        console.log(`[beforeEach] Iniciando teste para a conta: ${CONTA_NOME_COM_DADOS} na página 3`);
        await abrirDetalhesContaParaAcessibilidade(CONTA_NOME_COM_DADOS, 3);
        await driver.sleep(500); // Pequena pausa para garantir a renderização completa da página
    });

    after(async () => {
        if (driver) {
            await driver.quit();
        }
    });

    // Função auxiliar para obter o identificador do elemento para mensagens de erro
    async function getElementIdentifier(element) {
        try {
            const id = await element.getAttribute('id');
            if (id) return `*[id="${id}"]`;
            const text = await element.getText();
            if (text.trim() !== '') return `"${text.trim()}"`;
            const tagName = await element.getTagName();
            return `<${tagName}>`;
        } catch (e) {
            return 'Elemento desconhecido ou inalcançável';
        }
    }

    // --- TESTES DE ACESSIBILIDADE ---

    // 277 - Deve ter elementos semânticos essenciais (main, nav, table, thead, tbody)
    it('277 - Deve ter elementos semânticos essenciais (main, nav, table, thead, tbody)', async () => {
        const mainElement = await driver.findElement(By.css('main'));
        const navElement = await driver.findElement(By.css('nav[aria-label="Navegação de Movimentações"]'));
        const tableElement = await driver.findElement(By.css('table'));
        const theadElement = await driver.findElement(By.css('thead'));
        const tbodyElement = await driver.findElement(By.css('tbody'));

        expect(await mainElement.isDisplayed(), 'Elemento <main> deve estar visível').to.be.true;
        expect(await navElement.isDisplayed(), 'Elemento <nav> com aria-label "Navegação de Movimentações" deve estar visível').to.be.true; 
        expect(await tableElement.isDisplayed(), 'Elemento <table> deve estar visível').to.be.true;
        expect(await theadElement.isDisplayed(), 'Elemento <thead> deve estar visível').to.be.true;
        expect(await tbodyElement.isDisplayed(), 'Elemento <tbody> deve estar visível').to.be.true;
    });

    // 278 - Labels devem estar visíveis e coerentes com os dados exibidos
    it('278 - Labels devem estar visíveis e coerentes com os dados exibidos', async () => {
        const labels = await driver.findElements(By.css('.conta-info-grid label'));
        expect(labels.length).to.be.at.least(1, 'Pelo menos uma label deve ser encontrada.');

        for (const label of labels) {
            const labelText = await label.getText();
            expect(labelText.trim()).to.not.be.empty, `Texto da label "${await getElementIdentifier(label)}" não deve ser vazio.`;
            expect(await label.isDisplayed(), `Label "${await getElementIdentifier(label)}" deve estar visível.`).to.be.true;

            const divElement = await label.findElement(By.xpath('./following-sibling::div'));
            const divText = await divElement.getText();
            expect(divText.trim()).to.not.be.empty, `Conteúdo do <div> associado à label "${await getElementIdentifier(label)}" não deve ser vazio.`;
            expect(await divElement.isDisplayed(), `<div> associado à label "${await getElementIdentifier(label)}" deve estar visível.`).to.be.true;
        }
    });

    // 279 - Botões e links devem ter texto legível e aria-label quando aplicável
    it('279 - Botões e links devem ter texto legível e aria-label quando aplicável', async () => {
        const elements = await driver.findElements(By.css('a.btn, button, a.page-link'));
        expect(elements.length).to.be.at.least(1, 'Pelo menos um botão ou link deve ser encontrado.');

        for (const el of elements) {
            const isVisible = await el.isDisplayed();
            if (!isVisible) continue; // Pula elementos não visíveis, pois não seriam interativos ou foco.

            const text = await el.getText();
            const ariaLabel = await el.getAttribute('aria-label');
            
            const hasText = text.trim().length > 0;
            const hasAriaLabel = ariaLabel && ariaLabel.trim().length > 0;
            
            expect(hasText || hasAriaLabel, `Elemento ${await getElementIdentifier(el)} deve ter texto ou aria-label`).to.be.true;
        }
    });

    // 280 - Deve haver um título principal visível e acessível
    it('280 - Deve haver um título principal visível e acessível', async () => {
        const titleElement = await driver.findElement(contaDetalhesPage.title);
        expect(await titleElement.getText()).to.include('Detalhes da Conta'), 'Título principal deve conter "Detalhes da Conta".';
        expect(await titleElement.isDisplayed(), 'Título principal deve estar visível').to.be.true;
        expect(await titleElement.getTagName(), 'Título principal deve ser um <h2>').to.equal('h2');
    });

    // 281-286 - Navegação por tabulação deve seguir a ordem esperada
    it('281-286 - Navegação por tabulação deve seguir a ordem esperada', async () => {
        // É CRÍTICO que esta ordem corresponda à sua navegação manual na página.
        // Se a ordem real mudar, este teste precisará ser atualizado.
        const ordemEsperadaLocators = [
            // Elementos de navegação global (cabeçalho)
            By.css('a.brand'), // ContaFácil
            By.xpath('//a[text()="Home"]'),
            By.xpath('//button[contains(text(), "Contas")]'), // O dropdown "Contas"
            By.xpath('//a[text()="Adicionar"]'), // Sub-item do dropdown "Contas"
            By.xpath('//a[text()="Listar"]'), // Sub-item do dropdown "Contas"
            By.xpath('//a[text()="Criar Movimentação"]'), // Link direto na barra de navegação
            By.xpath('//a[text()="Resumo Mensal"]'),
            By.xpath('//a[text()="Sair"]'),

            // Botões principais da página de detalhes (no rodapé visual)
            contaDetalhesPage.btnVoltar, // "Voltar para Contas"
            By.xpath("//a[contains(text(), 'Editar Conta')]"), // "Editar Conta"
            contaDetalhesPage.btnNovaMovimentacao, // "Nova Movimentação"

            // Controles de Paginação (se houver paginação visível)
            By.xpath('//nav[@aria-label="Navegação de Movimentações"]//a[text()="Anterior"]'), // Botão "Anterior"
            By.xpath('//nav[@aria-label="Navegação de Movimentações"]//a[text()="1"]'), // Página 1
            By.xpath('//nav[@aria-label="Navegação de Movimentações"]//a[text()="2"]'), // Página 2
            By.xpath('//nav[@aria-label="Navegação de Movimentações"]//a[text()="3"]'), // Página 3 (ativa, mas ainda tabulável)
            By.xpath('//nav[@aria-label="Navegação de Movimentações"]//a[text()="Próximo"]'), // Botão "Próximo"
            
            // Primeiro botão "Editar" da tabela de movimentações (na página atual)
            By.css('table tbody tr:first-child td:last-child a.btn-warning'), 
            // Adicione mais By.css('table tbody tr:nth-child(X) td:last-child a.btn-warning') se a tabulação continuar para outros botões "Editar"
        ];

        await driver.findElement(By.css('body')).click(); // Clica no body para garantir que nenhum elemento esteja focado inicialmente.
        await driver.sleep(100); // Pequena pausa para garantir o "desfoco"

        for (let i = 0; i < ordemEsperadaLocators.length; i++) {
            const expectedLocator = ordemEsperadaLocators[i];
            
            // Pressiona TAB
            await driver.switchTo().activeElement().sendKeys(Key.TAB);
            
            let activeElement;
            try {
                // Aguarda até que o novo elemento ativo seja o esperado, ou falha após timeout
                activeElement = await driver.wait(async () => {
                    const currentActive = await driver.switchTo().activeElement();
                    try {
                        // Tenta encontrar o elemento esperado para comparação
                        const expectedEl = await driver.findElement(expectedLocator);
                        // Retorna o elemento ativo se ele for igual ao esperado
                        if (await expectedEl.equals(currentActive)) {
                            return currentActive;
                        }
                    } catch (e) {
                        // Se o elemento esperado não for encontrado, ele não pode ser o ativo ainda
                    }
                    // Continua esperando
                    return false; 
                }, 3000, `O foco não chegou ao elemento esperado após ${i + 1} tabs: ${expectedLocator.value || 'desconhecido'}`);
            } catch (error) {
                const currentActiveIdentifier = await getElementIdentifier(await driver.switchTo().activeElement());
                throw new Error(`Foco esperado em "${expectedLocator.value || 'desconhecido'}", mas após tabulação, o foco permaneceu ou foi para "${currentActiveIdentifier}". Erro: ${error.message}`);
            }
            
            // Asserção final após o wait
            expect(activeElement).to.exist, 'Elemento ativo não deve ser nulo.'; // Garante que encontramos um elemento
            const expectedElAfterWait = await driver.findElement(expectedLocator); // Re-encontra para garantir que é o mesmo
            expect(await expectedElAfterWait.equals(activeElement), `Foco no elemento incorreto na tabulação ${i + 1}. Esperado: "${await getElementIdentifier(expectedElAfterWait)}", Atual: "${await getElementIdentifier(activeElement)}"`).to.be.true;
        }
    });

    // 287 - Botões com foco exibem outline visível
    it('287 - Botões com foco exibem outline visível', async () => {
        const elements = await driver.findElements(By.css('a.btn, button, a.page-link'));
        expect(elements.length).to.be.at.least(1, 'Pelo menos um botão ou link deve ser encontrado para verificar o outline.');

        for (const el of elements) {
            // Verifica se o elemento está visível e habilitado antes de tentar focar
            if (await el.isDisplayed() && await el.isEnabled()) {
                await driver.executeScript("arguments[0].focus();", el); // Força o foco via JS
                const outlineStyle = await el.getCssValue('outline-style');
                const outlineColor = await el.getCssValue('outline-color');

                expect(outlineStyle).to.not.equal('none', `Elemento ${await getElementIdentifier(el)} não tem outline-style definido ao receber foco.`);
                expect(outlineColor).to.not.equal('rgba(0, 0, 0, 0)', `Elemento ${await getElementIdentifier(el)} tem outline-color transparente ao receber foco.`);
            }
        }
    });

    // 288 - A tabela de movimentações tem cabeçalhos com scope="col"
    it('288 - A tabela de movimentações tem cabeçalhos com scope="col"', async () => {
        const headers = await driver.findElements(By.css('table thead th'));
        expect(headers.length).to.be.at.least(1, 'Pelo menos um cabeçalho de tabela (<th>) deve ser encontrado.');
        for (const header of headers) {
            expect(await header.getAttribute('scope'), `Cabeçalho ${await getElementIdentifier(header)} deve ter scope="col".`).to.equal('col');
        }
    });

    // 289 - A paginação possui aria-label "Navegação de Movimentações"
    it('289 - A paginação possui aria-label "Navegação de Movimentações"', async () => {
        try {
            const navElement = await driver.findElement(By.css('nav[aria-label="Navegação de Movimentações"]'));
            expect(await navElement.getAttribute('aria-label'), 'O elemento <nav> da paginação deve ter aria-label="Navegação de Movimentações".').to.equal('Navegação de Movimentações');
        } catch (error) {
            if (error.name === 'NoSuchElementError') {
                console.warn('Teste 289: Elemento de navegação da paginação não encontrado. Pulando este teste (pode ocorrer se não houver movimentações suficientes para paginação).');
                this.skip(); // Ignora o teste se a paginação não estiver presente
            } else {
                throw error; // Relança outros erros
            }
        }
    });

    // 290 - Botões de paginação desabilitados possuem aria-disabled="true"
    it('290 - Botões de paginação desabilitados possuem aria-disabled="true"', async () => {
        // Garante que estamos na primeira página para testar o botão "Anterior" desabilitado
        await abrirDetalhesContaParaAcessibilidade(CONTA_NOME_COM_DADOS, 1);
        
        const previousButton = await contaDetalhesPage.getPreviousButton();
        if (previousButton) { // Verifica se o botão "Anterior" existe
            const isDisabled = await contaDetalhesPage.isPaginationButtonDisabled(previousButton);
            if (isDisabled) {
                expect(await previousButton.getAttribute('aria-disabled'), 'O botão "Anterior" deve ter aria-disabled="true" quando desabilitado.').to.equal('true');
            } else {
                console.log('Teste 290: Botão "Anterior" não está desabilitado na primeira página. Pode indicar problema ou cenário de teste específico.');
                // Se a paginação sempre tem "Anterior" habilitado mesmo na primeira página, o teste precisaria ser revisado.
            }
        } else {
            console.log('Teste 290: Botão "Anterior" não encontrado. Pulando este teste (pode ocorrer se não houver paginação).');
            this.skip();
        }

        // Você pode estender este teste para verificar o botão "Próximo" em uma última página, se aplicável.
    });

    // 291 - Botão ativo na paginação possui classe "btn-primary"
    it('291 - Botão ativo na paginação possui classe "btn-primary"', async () => {
        // O beforeEach já garante que estamos na página 3 da CONTA_NOME_COM_DADOS.
        const activeLink = await driver.findElement(By.css('nav[aria-label="Navegação de Movimentações"] li.page-item.active a.page-link'));
        expect(await activeLink.getAttribute('class'), 'O botão de paginação ativo deve ter a classe "btn-primary".').to.include('btn-primary');
        expect(await activeLink.getText(), 'O texto do botão de paginação ativo deve ser "3".').to.include('3'); // Confirma que é a página 3 que está ativa
    });

    // 292 - Valores positivos possuem classe "positive-value" e negativos "negative-value"
    it('292 - Valores positivos possuem classe "positive-value" e negativos "negative-value"', async () => {
        // Testa saldo positivo
        await abrirDetalhesContaParaAcessibilidade(CONTA_NOME_SALDO_POSITIVO);
        const saldoPositivoElement = await driver.findElement(By.css('.saldo-info div'));
        expect(await saldoPositivoElement.getAttribute('class'), 'Elemento do saldo positivo deve ter a classe "positive-value".').to.include('positive-value');
        expect(await saldoPositivoElement.getText(), 'Formato do saldo positivo deve ser "R$ X.XXX,XX".').to.match(/R\$ \d{1,3}(\.\d{3})*,\d{2}/);
        
        // Testa saldo negativo
        await abrirDetalhesContaParaAcessibilidade(CONTA_NOME_SALDO_NEGATIVO);
        const saldoNegativoElement = await driver.findElement(By.css('.saldo-info div'));
        expect(await saldoNegativoElement.getAttribute('class'), 'Elemento do saldo negativo deve ter a classe "negative-value".').to.include('negative-value');
        expect(await saldoNegativoElement.getText(), 'Formato do saldo negativo deve ser "R$ -X.XXX,XX".').to.match(/R\$ -\d{1,3}(\.\d{3})*,\d{2}/);
    });

    // 293 - Saldo atual está visível com destaque
    it('293 - Saldo atual está visível com destaque', async () => {
        const saldoInfo = await driver.findElement(By.css('.saldo-info'));
        expect(await saldoInfo.isDisplayed(), 'Elemento de informação de saldo deve estar visível.').to.be.true;
        const saldoValue = await driver.findElement(By.css('.saldo-info > div'));
        const text = await saldoValue.getText();
        expect(text, 'Formato do saldo atual deve ser "R$ +/-X.XXX,XX".').to.match(/R\$ -?\d{1,3}(\.\d{3})*,\d{2}/);
    });

    // 294 - Paginação altera URL e mantém a página atual ativa
    it('294 - Paginação altera URL e mantém a página atual ativa', async () => {
        // Começa na página 1 para poder testar o clique na página 2
        await abrirDetalhesContaParaAcessibilidade(CONTA_NOME_COM_DADOS, 1); 
        
        // Verifica se há pelo menos o link da página 2 para clicar
        const paginationLinks = await driver.findElements(By.css('nav[aria-label="Navegação de Movimentações"] a.page-link:not([aria-disabled])'));
        if (paginationLinks.length < 2) {
            console.log('Teste 294: Menos de 2 páginas navegáveis disponíveis para testar a navegação. Pulando.');
            this.skip();
            return;
        }

        // Antes de clicar, verifica que a página 1 está ativa
        const initialActivePageElement = await driver.findElement(By.css('nav[aria-label="Navegação de Movimentações"] li.page-item.active a.page-link'));
        expect(await initialActivePageElement.getText(), 'A página 1 deve estar ativa inicialmente.').to.include('1');

        // Clica no link da página 2
        const page2Link = await driver.findElement(By.xpath('//nav[@aria-label="Navegação de Movimentações"]//a[text()="2"]'));
        await page2Link.click();
        
        // Aguarda a URL mudar para a página 2
        await driver.wait(until.urlContains('page=2'), 5000);
        
        // Verifica se a página 2 se tornou ativa
        const newActivePageElement = await driver.findElement(By.css('nav[aria-label="Navegação de Movimentações"] li.page-item.active a.page-link'));
        expect(await newActivePageElement.getText(), 'A página 2 deve estar ativa após o clique.').to.include('2');
    });

    // 295 - Tabela possui estrutura acessível com linhas e colunas coerentes
    it('295 - Tabela possui estrutura acessível com linhas e colunas coerentes', async () => {
        await abrirDetalhesContaParaAcessibilidade(CONTA_NOME_COM_DADOS); // Garante que estamos em uma conta com dados para a tabela
        const rows = await driver.findElements(By.css('table tbody tr'));
        expect(rows.length).to.be.at.least(1, 'A tabela deve ter pelo menos uma linha de dados (<tr>).');
        for (const row of rows) {
            const cells = await row.findElements(By.css('td'));
            expect(cells.length).to.equal(6, `Cada linha da tabela (tr) deve ter 6 células de dados (td). Linha: ${await getElementIdentifier(row)}`);
        }
    });

    // 296 - Tabela de movimentações possui textos com contraste visível
    it('296 - Tabela de movimentações possui textos com contraste visível', async () => {
        await abrirDetalhesContaParaAcessibilidade(CONTA_NOME_COM_DADOS);
        const cells = await driver.findElements(By.css('table tbody tr td'));
        expect(cells.length).to.be.at.least(1, 'A tabela deve ter pelo menos uma célula de dados (<td>).');
        for (const cell of cells) {
            expect(await cell.isDisplayed(), `Célula "${await getElementIdentifier(cell)}" não está visível.`).to.be.true;
            // Para uma verificação de contraste real em Selenium, você precisaria de uma abordagem mais avançada:
            // 1. Obter a cor do texto (color) e a cor de fundo (background-color).
            // 2. Usar uma biblioteca ou função para calcular a razão de contraste WCAG.
            // Exemplo conceitual (não funcional sem a função calculateContrastRatio):
            // const textColor = await cell.getCssValue('color');
            // const backgroundColor = await cell.getCssValue('background-color');
            // expect(calculateContrastRatio(textColor, backgroundColor)).to.be.at.least(4.5, `Contraste da célula ${await getElementIdentifier(cell)} é insuficiente.`);
        }
    });

    // 297 - Links na página devem possuir href válido e navegável
    it('297 - Links na página devem possuir href válido e navegável', async () => {
        const links = await driver.findElements(By.css('a[href]'));
        expect(links.length).to.be.at.least(1, 'Pelo menos um link com atributo href deve ser encontrado.');
        for (const link of links) {
            const href = await link.getAttribute('href');
            expect(href, `Link ${await getElementIdentifier(link)} tem um href inválido: ${href}`).to.match(/^http(s)?:\/\//).or.to.match(/^\//); // Permite URLs absolutas (http/https) ou relativas (começando com /)
        }
    });
});