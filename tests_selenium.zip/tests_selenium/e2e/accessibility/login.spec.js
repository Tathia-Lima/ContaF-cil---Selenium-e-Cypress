// Testes de Acessibilidade - Página de Login (Selenium WebDriver)

import { Builder, By, Key, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';

// Importa os Page Objects necessários
import LoginPage from '../../support/page_objects/LoginPage.js';
import HomePage from '../../support/page_objects/HomePage.js'; // Importação adicionada para HomePage

// Define a URL base da aplicação
const baseUrl = 'http://localhost:5000';
// Define um usuário de teste para cenários de login
const userWithAccounts = { email: 'LoginPage@LoginPage.com', senha: 'login_10' };

let driver; // Variável para a instância do WebDriver
let loginPage; // Instância do Page Object de Login
let homePage; // Instância do Page Object de Home (necessário para o 'before' hook)

describe('Acessibilidade - Página de Login', function () {
    // Define um timeout global para todos os testes neste bloco
    this.timeout(30000); // 30 segundos

    // Hook 'before' é executado uma vez antes de todos os testes
    before(async () => {
        // Constrói uma nova instância do Chrome WebDriver
        driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(new chrome.Options().addArguments('--start-maximized')) // Inicia maximizado
            .build();

        // Instancia os Page Objects
        homePage = new HomePage(driver, baseUrl); // Instância de HomePage
        loginPage = new LoginPage(driver, baseUrl);

        // Realiza um login inicial para garantir que o ambiente está pronto.
        // Embora os testes de login visitem a página de login em cada beforeEach,
        // este login inicial pode ser para configurar um estado de sessão ou dados.
        await loginPage.login(userWithAccounts.email, userWithAccounts.senha);
        await driver.get(baseUrl); // Volta para a página inicial ou home após o login
    });

    // Hook 'beforeEach' é executado antes de cada teste individual
    beforeEach(async () => {
        // Navega para a página de login antes de cada teste para garantir um estado limpo
        await loginPage.visit();
    });

    // Hook 'after' é executado uma vez depois de todos os testes
    after(async () => {
        // Encerra a sessão do WebDriver
        await driver.quit();
    });

    // Teste 01: Verifica se os labels estão associados corretamente aos inputs
    it('01 - Deve ter labels associados aos campos de formulário', async () => {
        // Verifica o label e o input de email
        const emailLabel = await driver.findElement(By.css('label[for="email"]'));
        expect(await emailLabel.getText()).to.include('Email');
        const emailInput = await driver.findElement(By.id('email'));
        expect(await emailInput.isDisplayed()).to.be.true;
        expect(await emailInput.getAttribute('id')).to.equal('email');

        // Verifica o label e o input de senha
        const passwordLabel = await driver.findElement(By.css('label[for="senha"]'));
        expect(await passwordLabel.getText()).to.include('Senha');
        const passwordInput = await driver.findElement(By.id('senha'));
        expect(await passwordInput.isDisplayed()).to.be.true;
        expect(await passwordInput.getAttribute('id')).to.equal('senha');
    });

    // Teste 02: Verifica a navegação por teclado via TAB
    it('02 - Deve permitir navegação por teclado', async () => {
        // Foca no campo de email
        const emailInput = await loginPage.getEmailInput();
        await emailInput.sendKeys(Key.TAB); // Pressiona TAB para focar o próximo elemento

        // Verifica se o foco está no campo de senha
        const focusedElement1 = await driver.switchTo().activeElement();
        expect(await focusedElement1.getAttribute('id')).to.equal('senha');

        // Pressiona TAB novamente para focar o botão de toggle da senha
        await focusedElement1.sendKeys(Key.TAB);
        const focusedElement2 = await driver.switchTo().activeElement();
        expect(await focusedElement2.getAttribute('id')).to.equal('togglePassword');

        // Pressiona TAB novamente para focar o botão "Entrar"
        await focusedElement2.sendKeys(Key.TAB);
        const focusedElement3 = await driver.switchTo().activeElement();
        expect(await focusedElement3.getText()).to.include('Entrar');
    });

    // Teste 03: Verifica contraste de cores básico para leitura confortável
    it('03 - Deve ter contraste adequado para leitura', async () => {
        // Nota: A verificação de contraste exata é complexa e idealmente feita com Axe-core ou ferramentas especializadas.
        // Aqui, verificamos se as cores correspondem aos valores RGB esperados pelo teste Cypress,
        // incluindo a variação RGBA para cores opacas.

        // Verifica a cor do texto do cabeçalho (h2)
        const h2 = await driver.findElement(By.css('h2'));
        const h2Color = await h2.getCssValue('color');
        expect(h2Color).to.be.oneOf([
            'rgb(0, 0, 0)', 'rgb(255, 215, 0)', 'rgb(255, 235, 59)',
            'rgba(0, 0, 0, 1)', 'rgba(255, 215, 0, 1)', 'rgba(255, 235, 59, 1)' // Adicionado RGBA para cores opacas
        ]);

        // Verifica a cor de fundo do corpo (body)
        const bodyBgColor = await driver.findElement(By.css('body')).getCssValue('background-color');
        expect(bodyBgColor).to.be.oneOf([
            'rgb(255, 255, 255)', 'rgb(26, 26, 26)',
            'rgba(255, 255, 255, 1)', 'rgba(26, 26, 26, 1)' // Adicionado RGBA para cores opacas
        ]);

        // Verifica a cor do texto e de fundo do botão "Entrar"
        // O teste Cypress apenas verifica se as propriedades existem, não valores específicos para o botão.
        const submitButton = await loginPage.getSubmitButton();
        const buttonColor = await submitButton.getCssValue('color');
        const buttonBgColor = await submitButton.getCssValue('background-color');
        expect(buttonColor).to.not.equal('rgba(0, 0, 0, 0)'); // Garante que não é transparente
        expect(buttonBgColor).to.not.equal('rgba(0, 0, 0, 0)'); // Garante que não é transparente
    });

    // Teste 04: Verifica se botão de mostrar/ocultar senha tem aria-label para acessibilidade
    it('04 - Botão toggle senha deve ter aria-label para screen readers', async () => {
        const toggleButton = await driver.findElement(By.id('togglePassword'));
        const ariaLabel = await toggleButton.getAttribute('aria-label');
        expect(ariaLabel).to.exist; // Garante que o atributo existe
        expect(ariaLabel).to.match(/mostrar|ocultar senha/i); // Verifica se o valor corresponde ao esperado
    });

    // Teste 05: Verifica se o formulário possui role="form" para melhor semântica
    it('05 - Formulário deve ter role="form"', async () => {
        const formElement = await driver.findElement(By.css('form'));
        const role = await formElement.getAttribute('role');
        expect(role).to.equal('form');
    });

    // Teste 06: Verifica que campos obrigatórios possuem atributo required
    it('06 - Campos obrigatórios devem ter atributo required', async () => {
        const emailInput = await loginPage.getEmailInput();
        const passwordInput = await loginPage.getPasswordInput();

        // No Selenium, getAttribute('required') retorna 'true' ou null para atributos booleanos
        expect(await emailInput.getAttribute('required')).to.equal('true');
        expect(await passwordInput.getAttribute('required')).to.equal('true');
    });

    // Teste 07: Verifica se mensagens de erro estão associadas via aria-describedby
    it('07 - Mensagens de erro devem ser associadas via aria-describedby', async () => {
        // Este teste verifica se o atributo 'aria-describedby' existe nos inputs.
        // Se a aplicação só adiciona o atributo (com um ID válido) quando há um erro,
        // este teste precisaria de um passo para disparar o erro primeiro.
        // Por enquanto, verificamos apenas a existência do atributo.

        const emailInput = await loginPage.getEmailInput();
        const passwordInput = await loginPage.getPasswordInput();

        // Verifica se o atributo aria-describedby existe (mesmo que o valor esteja vazio inicialmente)
        expect(await emailInput.getAttribute('aria-describedby')).to.exist;
        expect(await passwordInput.getAttribute('aria-describedby')).to.exist;
    });

    // Teste 08: Verifica se os ícones têm textos alternativos ou aria-hidden
    it('08 - Ícones devem ter texto alternativo ou aria-hidden para acessibilidade', async () => {
        const toggleButton = await driver.findElement(By.id('togglePassword'));
        const hasAriaLabel = await toggleButton.getAttribute('aria-label') !== null;
        const hasAriaHidden = await toggleButton.getAttribute('aria-hidden') !== null;

        // O ícone dentro do botão deve ter aria-hidden="true" se o botão pai já tem aria-label.
        // Ou o próprio ícone tem um texto alternativo/aria-label.
        // Aqui, estamos verificando o botão pai, que é o elemento interativo.
        expect(hasAriaLabel || hasAriaHidden).to.be.true;
    });

    // Teste 09: Verifica se a página possui título (title) e cabeçalho (h2) claros
    it('09 - Deve possuir título da página e cabeçalho claros', async () => {
        const pageTitle = await driver.getTitle();
        expect(pageTitle).to.include('ContaFácil - Login');

        const h2 = await driver.findElement(By.css('h2'));
        expect(await h2.getText()).to.include('Login');
    });

    // Teste 10: Deve exibir mensagem de campo obrigatório ao tentar logar sem preencher o email
    it('10 - Deve exibir mensagem de campo obrigatório ao tentar logar sem preencher o email', async () => {
        // Não preenche o email
        await loginPage.fillPassword('any_password'); // Preenche a senha para focar no erro do email
        await loginPage.submit();

        // Para pegar a mensagem de validação nativa do navegador, precisamos de JavaScript.
        const emailInput = await loginPage.getEmailInput();
        const validationMessage = await driver.executeScript('return arguments[0].validationMessage;', emailInput);
        
        // O texto da mensagem de validação nativa depende do idioma do navegador.
        expect(validationMessage).to.include('Preencha este campo.'); 
    });

    // Teste 11: Elementos interativos devem exibir foco visível
    it('11 - Elementos interativos devem exibir foco visível', async () => {
        const elementsToFocus = [
            await loginPage.getEmailInput(),
            await loginPage.getPasswordInput(),
            await driver.findElement(By.id('togglePassword')), // Botão de toggle
            await loginPage.getSubmitButton()
        ];

        for (const el of elementsToFocus) {
            const elementId = await el.getAttribute('id') || await el.getTagName(); // Para logs mais informativos

            await driver.executeScript('arguments[0].focus();', el); // Foca o elemento via JavaScript
            await driver.sleep(200); // Aumentado o delay para garantir que o foco seja aplicado e renderizado

            const outlineStyle = await el.getCssValue('outline-style');
            const outlineWidth = parseFloat(await el.getCssValue('outline-width'));
            const outlineColor = await el.getCssValue('outline-color');

            const boxShadow = await el.getCssValue('box-shadow');
            
            const borderStyle = await el.getCssValue('border-style');
            const borderWidth = parseFloat(await el.getCssValue('border-width'));
            const borderColor = await el.getCssValue('border-color');

            // Verifica se há algum indicador visual de foco
            // Aprimorada a lógica para ser mais robusta na detecção de foco
            const hasVisibleFocus =
                // Verifica outline
                (outlineStyle && outlineStyle !== 'none' && outlineWidth > 0 && outlineColor !== 'rgba(0, 0, 0, 0)') ||
                // Verifica box-shadow (exclui sombras totalmente transparentes)
                (boxShadow && boxShadow !== 'none' && !boxShadow.includes('rgba(0, 0, 0, 0)') && !boxShadow.includes('0px 0px 0px')) ||
                // Verifica borda (se a borda for sólida e visível)
                (borderStyle && borderStyle !== 'none' && borderWidth > 0 && borderColor !== 'rgba(0, 0, 0, 0)');

            expect(hasVisibleFocus).to.be.true, `Elemento ${elementId} não tem foco visível.`;
        }
    });

    // Teste 12: Deve ativar o botão mostrar/ocultar senha com a tecla Enter
    it('12 - Deve ativar o botão mostrar/ocultar senha via teclado (Enter)', async () => {
        const toggleButton = await driver.findElement(By.id('togglePassword'));
        await toggleButton.sendKeys(Key.ENTER); // Pressiona Enter no botão
        
        const passwordInput = await loginPage.getPasswordInput();
        const typeAfterEnter = await passwordInput.getAttribute('type');
        // Verifica se o tipo do input de senha é 'text' ou 'password' (mudou ou permaneceu)
        expect(typeAfterEnter).to.be.oneOf(['text', 'password']); 
    });

    // Teste 13: Deve ativar o botão mostrar/ocultar senha com a tecla Espaço
    it('13 - Deve ativar o botão mostrar/ocultar senha via teclado (Espaço)', async () => {
        const toggleButton = await driver.findElement(By.id('togglePassword'));
        await toggleButton.sendKeys(Key.SPACE); // Pressiona Espaço no botão

        const passwordInput = await loginPage.getPasswordInput();
        const typeAfterSpace = await passwordInput.getAttribute('type');
        // Verifica se o tipo do input de senha é 'text' ou 'password' (mudou ou permaneceu)
        expect(typeAfterSpace).to.be.oneOf(['text', 'password']); 
    });

    // Teste 14: Deve ativar o botão Entrar com a tecla Enter
    it('14 - Deve ativar o botão Entrar via teclado (Enter)', async () => {
        await loginPage.fillEmail(userWithAccounts.email);
        await loginPage.fillPassword(userWithAccounts.senha);

        const submitButton = await loginPage.getSubmitButton();
        await submitButton.sendKeys(Key.ENTER); // Pressiona Enter no botão de submissão

        // Espera que a URL mude para fora da página de login (assumindo redirecionamento para /home)
        await driver.wait(until.urlContains('/home'), 10000); 
        const currentUrl = await driver.getCurrentUrl();
        expect(currentUrl).to.not.include('/login');
    });

    // Teste 15: Deve ativar o link Novo usuário com a tecla Enter
    it('15 - Deve ativar o link Novo usuário via teclado (Enter) e validar título Cadastro de Usuário', async () => {
        // Encontra o link "Novo usuário" pelo texto visível
        const newUserLink = await driver.findElement(By.linkText('Novo usuário')); 
        await newUserLink.sendKeys(Key.ENTER); // Pressiona Enter no link

        // Espera que a URL mude para a página de cadastro
        await driver.wait(until.urlContains('/cadastro'), 10000);
        const h1 = await driver.findElement(By.css('h1'));
        expect(await h1.getText()).to.include('Cadastro de Usuário');
    });

    // Teste 16: Deve alternar para o campo de senha ao pressionar Tab
    it('16 - Deve alternar para o campo de senha ao pressionar Tab', async () => {
        const emailInput = await loginPage.getEmailInput();
        await emailInput.sendKeys(Key.TAB); // Pressiona TAB no campo de email

        const focusedElement = await driver.switchTo().activeElement();
        // Verifica se o foco está no campo de senha pelo atributo 'name'
        expect(await focusedElement.getAttribute('name')).to.equal('senha'); 
    });

    // Teste 17: Deve mostrar/ocultar a senha ao clicar no ícone de olho
    it('17 - Deve mostrar/ocultar a senha ao clicar no ícone de olho', async () => {
        const passwordInput = await loginPage.getPasswordInput();
        const toggleButton = await driver.findElement(By.id('togglePassword'));

        await passwordInput.sendKeys('senha123'); // Preenche a senha
        // Verifica se o tipo do input é 'password' inicialmente
        expect(await passwordInput.getAttribute('type')).to.equal('password'); 

        await toggleButton.click(); // Clica no botão de toggle
        // Verifica se o tipo mudou para 'text'
        expect(await passwordInput.getAttribute('type')).to.equal('text'); 

        await toggleButton.click(); // Clica novamente
        // Verifica se o tipo voltou para 'password'
        expect(await passwordInput.getAttribute('type')).to.equal('password'); 
    });
});
