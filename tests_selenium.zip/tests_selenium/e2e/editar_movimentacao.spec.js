import { Builder, By, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';
import { expect } from 'chai';
import moment from 'moment';

import LoginPage from '../support/page_objects/LoginPage.js';
import EditarMovimentacaoPage from '../support/page_objects/EditarMovimentacaoPage.js';

const baseUrl = 'http://localhost:5000';
const user = { email: 'editarMovimentacao@movimentacao.com', senha: 'login_10' };

let driver;
let loginPage;
let editarMovimentacaoPage;

// --- Funções Auxiliares para Manipulação de Data e Valor (Refatoradas ) ---

/**
 * Formata um objeto Date para a string 'DD-MM-YYYY'.
 * Usado para ENVIAR dados para inputs de data que esperam este formato.
 * @param {Date} date O objeto Date a ser formatado.
 * @returns {string} A data formatada para 'DD-MM-YYYY'.
 */
function formatDateToDD_MM_YYYY(date) {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
}

/**
 * Converte uma string de data (DD/MM/YYYY ou DD-MM-YYYY) para 'YYYY-MM-DD'.
 * Ideal para padronizar para comparações.
 * @param {string} dateStr A string da data (ex: "26/06/2025", "26-06-2025", "2025-06-26").
 * @returns {string} A data formatada para 'YYYY-MM-DD'.
 */
function standardizeDateForComparison(dateStr) {
  if (!dateStr) return '';
  const cleanedDateStr = dateStr.trim();
  // Tenta capturar DD, MM, YYYY com / ou -
  const match = cleanedDateStr.match(/^(\d{2})[/\-](\d{2})[/\-](\d{4})$/);

  if (match) {
    const [, day, month, year] = match;
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  }

  // Se já está no formato YYYY-MM-DD, apenas retorna
  if (cleanedDateStr.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return cleanedDateStr;
  }
  // Se não reconhecido, retorna a string original (pode indicar um problema)
  return cleanedDateStr;
}

/**
 * Retorna a data atual no formato 'YYYY-MM-DD' (ISO local).
 * Garante que a data não seja afetada por fusos horários ao ser criada.
 * @returns {string} A data atual formatada para 'YYYY-MM-DD'.
 */
function getTodayDateISO() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Normaliza uma string de valor monetário para um formato numérico float.
 * Remove "R$", pontos de milhar, e converte vírgula decimal para ponto.
 * @param {string} valorStr A string do valor monetário (ex: "R$ 1.000,50", "100,00", "200").
 * @returns {number} O valor numérico float.
 */
function parseValorMonetario(valorStr) {
  if (!valorStr) return 0;
  let str = valorStr.replace('R$', '').trim();
  const hasComma = str.includes(',');
  const hasDot = str.includes('.');

  if (hasComma && hasDot) { // Ex: "1.000,50" (ponto milhar, vírgula decimal)
    str = str.replace(/\./g, ''); // Remove pontos de milhar
    str = str.replace(',', '.'); // Substitui vírgula por ponto decimal
  } else if (hasComma) { // Ex: "100,50" (apenas vírgula decimal)
    str = str.replace(',', '.'); // Substitui vírgula por ponto decimal
  }
  // Se não tem vírgula, e tem ponto, assume que é decimal (e.g. "100.50") ou inteiro ("100")
  return parseFloat(str);
}

// Função para abrir detalhes da conta em nova aba com XPath robusto e logs
async function abrirDetalhesConta(nomeConta) {
  const xpathDetalhes = `//tr[td/a[normalize-space(text())='${nomeConta}']]//a[contains(@class, 'btn-primary') and contains(normalize-space(text()), 'Detalhes')]`;
  console.log(`[abrirDetalhesConta] Procurando link Detalhes com XPath: ${xpathDetalhes}`);

  await driver.wait(until.elementLocated(By.xpath(xpathDetalhes)), 10000);
  const detalhesLink = await driver.findElement(By.xpath(xpathDetalhes));

  const detalhesUrl = await detalhesLink.getAttribute('href');
  console.log(`[abrirDetalhesConta] URL Detalhes: ${detalhesUrl}`);

  const handlesAntes = await driver.getAllWindowHandles();
  await driver.switchTo().newWindow('tab');

  await driver.wait(async () => {
    const handlesAgora = await driver.getAllWindowHandles();
    return handlesAgora.length > handlesAntes.length;
  }, 10000);

  const handlesDepois = await driver.getAllWindowHandles();
  const novaAba = handlesDepois.find(h => !handlesAntes.includes(h));
  await driver.switchTo().window(novaAba);

  await driver.get(detalhesUrl);
  await driver.wait(until.urlContains('/contas/detalhes/'), 10000);

  const h2 = await driver.findElement(By.css('h2'));
  await driver.wait(until.elementIsVisible(h2), 5000);
  const textoH2 = await h2.getText();
  console.log(`[abrirDetalhesConta] Página Detalhes carregada, h2: ${textoH2}`);
  expect(textoH2).to.include('Detalhes da Conta');

  return novaAba;
}

// Função para abrir editar movimentação em nova aba
async function abrirEditarMovimentacao() {
  const xpathEditar = "//table//a[contains(text(),'Editar')]";
  console.log(`[abrirEditarMovimentacao] Procurando link Editar com XPath: ${xpathEditar}`);

  await driver.wait(until.elementLocated(By.xpath(xpathEditar)), 10000);
  const editarLink = await driver.findElement(By.xpath(xpathEditar));

  const editarUrl = await editarLink.getAttribute('href');
  console.log(`[abrirEditarMovimentacao] URL Editar: ${editarUrl}`);

  const handlesAntes = await driver.getAllWindowHandles();
  await driver.switchTo().newWindow('tab');

  await driver.wait(async () => {
    const handlesAgora = await driver.getAllWindowHandles();
    return handlesAgora.length > handlesAntes.length;
  }, 10000);

  const handlesDepois = await driver.getAllWindowHandles();
  const novaAba = handlesDepois.find(h => !handlesAntes.includes(h));
  await driver.switchTo().window(novaAba);

  await driver.get(editarUrl);
  await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);

  const h2 = await driver.findElement(By.css('h2'));
  await driver.wait(until.elementIsVisible(h2), 5000);
  const textoH2 = await h2.getText();
  console.log(`[abrirEditarMovimentacao] Página Editar Movimentação carregada, h2: ${textoH2}`);
  expect(textoH2).to.include('Editar Movimentação');

  return novaAba;
}

describe('Editar Movimentação com múltiplas abas', () => {
  before(async () => {
    const options = new chrome.Options();
    options.addArguments('--start-maximized');
    driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build();

    loginPage = new LoginPage(driver, baseUrl);
    editarMovimentacaoPage = new EditarMovimentacaoPage(driver);
  });

  beforeEach(async () => {
    await loginPage.login(user.email, user.senha);
    await driver.get(`${baseUrl}/home`);
    await driver.wait(until.urlContains('/home'), 10000);
    console.log('[beforeEach] Página /home carregada');

    // Verifica se tabela está presente
    await driver.wait(until.elementLocated(By.css('table.table')), 10000);
    console.log('[beforeEach] Tabela de contas presente');
  });

  after(async () => {
    await driver.quit();
  });

  it('298 - Validar dados no formulário editar movimentação com múltiplas abas', async () => {
    const originalWindow = await driver.getWindowHandle();

    const detalhesTab = await abrirDetalhesConta('Conta 1');
    const editarTab = await abrirEditarMovimentacao();

    // Validar campos do formulário
    const tipoElem = await editarMovimentacaoPage.getTipo();
    const tipoVal = await tipoElem.getAttribute('value');
    expect(tipoVal).to.be.oneOf(['receita', 'despesa']);

    const descricaoElem = await editarMovimentacaoPage.getDescricao();
    const descricaoVal = await descricaoElem.getAttribute('value');
    expect(descricaoVal).to.be.a('string').and.not.empty;

    const valorElem = await editarMovimentacaoPage.getValor();
    const valorVal = await valorElem.getAttribute('value');
    expect(parseFloat(valorVal.replace(',', '.'))).to.be.a('number').and.to.be.greaterThan(0);

    const dataMovElem = await editarMovimentacaoPage.getDataMovimentacao();
    const dataMovVal = await dataMovElem.getAttribute('value');
    expect(dataMovVal).to.match(/^\d{4}-\d{2}-\d{2}$/); // Espera YYYY-MM-DD do input

    const dataPagElem = await editarMovimentacaoPage.getDataPagamento();
    const dataPagVal = await dataPagElem.getAttribute('value');
    expect(dataPagVal).to.match(/^\d{4}-\d{2}-\d{2}$/); // Espera YYYY-MM-DD do input

    // Fecha abas na ordem inversa
    await driver.close(); // fecha aba editar
    await driver.switchTo().window(detalhesTab);

    await driver.close(); // fecha aba detalhes
    await driver.switchTo().window(originalWindow);
  });

 it('299 - Deve editar todos os campos com valores válidos e salvar com sucesso', async () => {

    const sufixo = Math.floor(Math.random() * 90 + 10);
    const originalWindow = await driver.getWindowHandle();

    const detalhesTab = await abrirDetalhesConta('Conta 2');
    const editarTab = await abrirEditarMovimentacao();

    // Obtém valor atual e calcula novo valor
    const valorAtualInput = await (await editarMovimentacaoPage.getValor()).getAttribute('value');
    const valorNumericoAtual = parseValorMonetario(valorAtualInput);
    const novoValorNumerico = valorNumericoAtual + 10;
    const novoValorParaInput = novoValorNumerico.toFixed(2);

    await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
    await (await editarMovimentacaoPage.getValor()).clear();
    await (await editarMovimentacaoPage.getValor()).sendKeys(novoValorParaInput);

    // Usar datas dinâmicas e o formato DD-MM-YYYY para sendKeys
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    // Para "pago", a data de pagamento deve ser hoje ou no passado.
    // Usaremos hoje para garantir que a validação passe.
    const dataMovimentacaoStr = formatDateToDD_MM_YYYY(yesterday);
    const dataPagamentoStr = formatDateToDD_MM_YYYY(today);

    await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
    await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(dataMovimentacaoStr);

    await (await editarMovimentacaoPage.getDataPagamento()).clear();
    await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(dataPagamentoStr);

    await (await editarMovimentacaoPage.getDescricao()).clear();
    await (await editarMovimentacaoPage.getDescricao()).sendKeys(`Despesa editada ${sufixo}`);
    await (await editarMovimentacaoPage.getInteressado()).clear();
    await (await editarMovimentacaoPage.getInteressado()).sendKeys(`Fornecedor X ${sufixo}`);
    await (await editarMovimentacaoPage.getContaId()).sendKeys('Conta 2');
    await (await editarMovimentacaoPage.getSituacao('pago')).click();

    const submitBtn = await driver.findElement(By.css('button[type="submit"]'));
    await submitBtn.click();

    await driver.wait(
      until.urlContains('/contas/detalhes/'),
      10000,
      'Esperado redirecionamento para /contas/detalhes/ após salvar.'
    );
    await driver.wait(until.elementLocated(By.css('.alert-success')), 5000, 'Esperado alerta de sucesso após salvar.');

    const alertaSucesso = await driver.findElement(By.css('.alert-success'));
    const textoAlerta = await alertaSucesso.getText();
    expect(textoAlerta).to.include('Movimentação atualizada com sucesso');

    // Validação da descrição na tabela
    const tabelaTexto = await driver.findElement(By.tagName('table')).getText();
    expect(tabelaTexto).to.include(`Despesa editada ${sufixo}`);

    // Validação numérica precisa na linha da despesa editada
    const linhaDespesa = await driver.findElement(By.xpath(`//table//tr[contains(.,'Despesa editada ${sufixo}')]`));
    const valorCelula = await linhaDespesa.findElement(By.css('td:nth-child(4)')).getText();

    const valorNaTabelaNumerico = parseValorMonetario(valorCelula);
    expect(valorNaTabelaNumerico).to.be.closeTo(novoValorNumerico, 0.01); // Usar closeTo para floats

    // Fechar abas na ordem inversa
    const handlesAfter = await driver.getAllWindowHandles();
    if (handlesAfter.includes(editarTab)) {
        await driver.switchTo().window(editarTab);
        await driver.close();
    }
    if (handlesAfter.includes(detalhesTab)) {
        await driver.switchTo().window(detalhesTab);
        await driver.close();
    }
    await driver.switchTo().window(originalWindow);
  });

  it('300 - Deve validar campos obrigatórios e exibir erros', async () => {
    const originalWindow = await driver.getWindowHandle();

    const detalhesTab = await abrirDetalhesConta('Conta 1');
    const editarTab = await abrirEditarMovimentacao();

    await (await editarMovimentacaoPage.getValor()).clear();
    await (await editarMovimentacaoPage.getDescricao()).clear();

    const submitBtn = await driver.findElement(By.css('button[type="submit"]'));
    await submitBtn.click();

    const alertaValor = await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Informe um valor.')]")), 5000);
    expect(alertaValor).to.exist;

    const alertaDescricao = await driver.findElement(By.xpath("//*[contains(text(),'Descrição é obrigatória.')]"));
    expect(alertaDescricao).to.exist;

    const urlAtual = await driver.getCurrentUrl();
    expect(urlAtual).to.include('/movimentacao/editar/');

    await driver.close(); // Fecha aba editar
    await driver.switchTo().window(detalhesTab);
    await driver.close(); // Fecha aba detalhes
    await driver.switchTo().window(originalWindow);
  });

  it('301 - Deve impedir seleção de conta inexistente ou inválida (manipulada via devtools)', async () => {
    const originalWindow = await driver.getWindowHandle();
    const detalhesTab = await abrirDetalhesConta('Conta 1');
    const editarTab = await abrirEditarMovimentacao();

    const contaId = await editarMovimentacaoPage.getContaId();
    await driver.executeScript("arguments[0].value = '9999';", contaId);

    const submitBtn = await driver.findElement(By.css('button[type="submit"]'));
    await submitBtn.click();

    const erroConta = await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Você precisa selecionar uma conta.')]")), 5000);
    expect(erroConta).to.exist;

    const urlAtual = await driver.getCurrentUrl();
    expect(urlAtual).to.include('/movimentacao/editar/');

    await driver.close();
    await driver.switchTo().window(detalhesTab);
    await driver.close();
    await driver.switchTo().window(originalWindow);
  });

  it('302 - Deve manter dados preenchidos após erro de validação', async () => {
    const originalWindow = await driver.getWindowHandle();
    const detalhesTab = await abrirDetalhesConta('Conta 1');
    const editarTab = await abrirEditarMovimentacao();

    await (await editarMovimentacaoPage.getDescricao()).clear();
    const submitBtn = await driver.findElement(By.css('button[type="submit"]'));
    await submitBtn.click();

    const erroDescricao = await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Descrição é obrigatória.')]")), 5000);
    expect(erroDescricao).to.exist;

    expect(await (await editarMovimentacaoPage.getValor()).getAttribute('value')).to.not.be.empty;
    expect(await (await editarMovimentacaoPage.getTipo()).getAttribute('value')).to.not.be.empty;
    expect(await driver.findElement(By.css('input[name="situacao"]:checked'))).to.exist;
    expect(await (await editarMovimentacaoPage.getInteressado()).getAttribute('value')).to.not.be.empty;
    expect(await (await editarMovimentacaoPage.getDataMovimentacao()).getAttribute('value')).to.not.be.empty;
    expect(await (await editarMovimentacaoPage.getDataPagamento()).getAttribute('value')).to.not.be.empty;
    expect(await (await editarMovimentacaoPage.getContaId()).getAttribute('value')).to.not.equal('0');
    expect(await (await editarMovimentacaoPage.getDescricao()).getAttribute('value')).to.equal('');

    const urlAtual = await driver.getCurrentUrl();
    expect(urlAtual).to.include('/movimentacao/editar/');

    await driver.close();
    await driver.switchTo().window(detalhesTab);
    await driver.close();
    await driver.switchTo().window(originalWindow);
  });

  it('303 - Deve redirecionar corretamente ao clicar em Cancelar', async () => {
    const originalWindow = await driver.getWindowHandle();
    const detalhesTab = await abrirDetalhesConta('Conta 3');
    const editarTab = await abrirEditarMovimentacao();

    const cancelarBtn = await driver.findElement(By.css('a.btn-secondary'));
    await cancelarBtn.click();

    await driver.wait(until.urlContains('/contas/detalhes/'), 10000);
    const h2 = await driver.findElement(By.css('h2'));
    const textoH2 = await h2.getText();
    expect(textoH2).to.include('Detalhes da Conta');

    await driver.close();
    await driver.switchTo().window(detalhesTab);
    await driver.close();
    await driver.switchTo().window(originalWindow);
  });

    it('304 - Deve validar campo Descrição como obrigatório', async () => {
    const originalWindow = await driver.getWindowHandle();
    const detalhesTab = await abrirDetalhesConta('Conta 1');
    const editarTab = await abrirEditarMovimentacao();

    await (await editarMovimentacaoPage.getDescricao()).clear();
    const submitBtn = await driver.findElement(By.css('button[type="submit"]'));
    await submitBtn.click();

    const erro = await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Descrição é obrigatória.')]")), 5000);
    expect(erro).to.exist;

    await driver.close();
    await driver.switchTo().window(detalhesTab);
    await driver.close();
    await driver.switchTo().window(originalWindow);
  });

  describe('Editar Movimentação - testes funcionais (equivalente a Cypress it(305) até it(322))', () => {

  // Reuso das funções abrirDetalhesConta e abrirEditarMovimentacao para navegar nas abas

  it('305 - Acessibilidade: todos os campos devem ser acessíveis via tabulação', async () => {
    await abrirDetalhesConta('Conta 3');

    // Clicar no botão editar da primeira movimentação
    const editarBtn = await driver.findElement(By.css('table tbody tr:first-child a.btn-warning'));
    await editarBtn.click();

    await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
    const h2 = await driver.findElement(By.css('h2'));
    const h2Text = await h2.getText();
    expect(h2Text).to.include('Editar Movimentação');

    // Testar navbar (links e botões) visíveis e tabIndex
    const navbarElements = await driver.findElements(By.css('nav.navbar a:not(.dropdown-content a), nav.navbar button'));
    for (const el of navbarElements) {
      expect(await el.isDisplayed()).to.be.true;
      const tag = await el.getTagName();
      const disabled = await el.getAttribute('disabled');
      const tabIndex = await el.getAttribute('tabindex');
      if (['a', 'button'].includes(tag)) {
        expect(disabled).to.be.oneOf([null, undefined, false], `Elemento ${tag} não deve estar desabilitado`);
        expect(tabIndex).to.not.equal('-1', `Elemento ${tag} não deve ter tabindex=-1`);
      } else {
        expect(Number(tabIndex)).to.be.at.least(0);
      }
    }

    // Abrir dropdown e testar links
    const dropbtn = await driver.findElement(By.css('button.dropbtn'));
    await dropbtn.click();

    const dropdownLinks = await driver.findElements(By.css('.dropdown-content a'));
    for (const el of dropdownLinks) {
      expect(await el.isDisplayed()).to.be.true;
      const disabled = await el.getAttribute('disabled');
      const tabIndex = await el.getAttribute('tabindex');
      expect(disabled).to.be.oneOf([null, undefined, false], 'Link no dropdown não deve estar desabilitado');
      expect(tabIndex).to.not.equal('-1', 'Link no dropdown não deve ter tabindex=-1');
    }

    // Testar campos do formulário (inputs, selects, buttons), excluindo hidden
    const campos = await driver.findElements(By.css('form input:not([type="hidden"]), form select, form button'));
    for (const el of campos) {
      expect(await el.isDisplayed()).to.be.true;
      const tag = await el.getTagName();
      const type = await el.getAttribute('type');
      const disabled = await el.getAttribute('disabled');
      const tabIndex = await el.getAttribute('tabindex');
      expect(disabled).to.be.oneOf([null, undefined, false], `Campo ${tag} (type: ${type}) não deve estar desabilitado`);
      expect(tabIndex).to.not.equal('-1', `Campo ${tag} (type: ${type}) não deve ter tabindex=-1`);
    }

    // Botão cancelar
    const cancelar = await driver.findElement(By.css('a.btn-secondary'));
    expect(await cancelar.isDisplayed()).to.be.true;
    const disabledCancel = await cancelar.getAttribute('disabled');
    const tabIndexCancel = await cancelar.getAttribute('tabindex');
    expect(disabledCancel).to.be.oneOf([null, undefined, false], 'Botão Cancelar não deve estar desabilitado');
    expect(tabIndexCancel).to.not.equal('-1', 'Botão Cancelar não deve ter tabindex=-1');
  });

it('306 - Deve comparar os dados da movimentação com os do formulário de edição', async () => {
  const originalWindow = await driver.getWindowHandle();

  function normalizarTexto(str) {
    return str.trim().toLowerCase().replace(/\s+/g, '');
  }

  try {
    // Acessa a home e a conta pelo nome (sem abrir aba)
    await driver.get(`${baseUrl}/home`);
    await driver.wait(until.elementLocated(By.css('table.table')), 10000);
    console.log('[306] Página /home e tabela carregadas');

    // Encontra linha da Conta 1
    const linha = await driver.findElement(By.xpath("//tr[td/a[normalize-space(text())='Conta 1']]"));
    const btnDetalhes = await linha.findElement(By.css('a.btn-primary'));

    const detalhesHref = await btnDetalhes.getAttribute('href');
    await driver.get(detalhesHref);
    await driver.wait(until.elementLocated(By.css('h2')), 10000);
    console.log('[306] Página de detalhes carregada');

    const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
    const tds = await primeiraLinha.findElements(By.css('td'));

    const rawData = {
      data: (await tds[0].getText()).trim(), // formato dd/mm/aaaa ou dd-mm-aaaa
      descricao: (await tds[1].getText()).trim(),
      tipo: (await tds[2].getText()).trim(),
      valor: (await tds[3].getText()).trim(),
      situacao: (await tds[4].getText()).trim(),
    };
    console.log('[306] Dados da tabela de detalhes:', rawData);

    // Clica no botão Editar
    const btnEditar = await primeiraLinha.findElement(By.css('a.btn-warning'));
    await btnEditar.click();
    await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
    console.log('[306] Página de edição carregada');

    // Validação: campo data_movimentacao
    const dataMovInput = await editarMovimentacaoPage.getDataMovimentacao();
    const dataMov = (await dataMovInput.getAttribute('value')).trim(); // Espera YYYY-MM-DD do input
    const dataMovEsperada = standardizeDateForComparison(rawData.data); // Padroniza a data da tabela
    expect(dataMov).to.equal(dataMovEsperada);

    // Validação: descrição
    const descricao = await (await editarMovimentacaoPage.getDescricao()).getAttribute('value');
    expect(descricao).to.equal(rawData.descricao);

    // Validação: tipo (normalizado)
    const tipo = await (await editarMovimentacaoPage.getTipo()).getAttribute('value');
    expect(normalizarTexto(tipo)).to.equal(normalizarTexto(rawData.tipo));

    // Validação: valor
    const valorFormRaw = await (await editarMovimentacaoPage.getValor()).getAttribute('value');
    const valorFormNum = parseFloat(valorFormRaw.replace(',', '.'));
    const valorTabelaNum = parseFloat(
      rawData.valor.replace('R$', '').replace(/\./g, '').replace(',', '.')
    );
    expect(valorFormNum).to.be.closeTo(valorTabelaNum, 0.01);

    // Validação: situação (radio button)
    const radio = await driver.findElement(By.css(`input[name="situacao"][value="${normalizarTexto(rawData.situacao)}"]`));
    const checked = await radio.isSelected();
    expect(checked).to.be.true;

  } finally {
    // Garante volta para janela original
    await driver.switchTo().window(originalWindow);
  }
});


 it('307 - Deve alternar a situação da movimentação e validar mudanças na tela de detalhes', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;
    let descricaoMovimentacaoOriginal; // Variável para armazenar a descrição original

    try {
        detalhesTab = await abrirDetalhesConta('Conta 3');

        const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
        const tds = await primeiraLinha.findElements(By.css('td'));

        // Capturar a descrição da movimentação que será editada
        descricaoMovimentacaoOriginal = await tds[1].getText(); // Supondo que a descrição está na 2ª coluna (índice 1)
        console.log(`[307] Descrição original da movimentação: "${descricaoMovimentacaoOriginal}"`);

        const situacaoAntesTexto = await tds[4].getText(); // Supondo que a situação está na 5ª coluna (índice 4)
        const situacaoAntes = situacaoAntesTexto.trim().toLowerCase();
        console.log(`[307] Situação antes da edição: "${situacaoAntes}"`);

        const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
        await editarBtn.click();

        await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);

        // Alternar situação
        let novaSituacao;
        if (situacaoAntes === 'pago') {
          novaSituacao = 'pendente';
        } else if (situacaoAntes === 'pendente') {
          novaSituacao = 'pago';
        } else {
          throw new Error(`Situação inesperada: ${situacaoAntes}`);
        }
        await driver.findElement(By.css(`input[name="situacao"][value="${novaSituacao}"]`)).click();
        console.log(`[307] Nova situação selecionada: "${novaSituacao}"`);


        // Lógica de data para respeitar a validação do backend: Data de pagamento deve ser <= 01/07/2025 (data atual)
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);

        let dataMovimentacaoStr;
        let dataPagamentoStr;

        dataPagamentoStr = formatDateToDD_MM_YYYY(today); // Data de pagamento sempre HOJE ou ANTERIOR
        dataMovimentacaoStr = formatDateToDD_MM_YYYY(yesterday);

        const dataMovimentacaoInput = await editarMovimentacaoPage.getDataMovimentacao();
        await dataMovimentacaoInput.clear();
        await dataMovimentacaoInput.sendKeys(dataMovimentacaoStr);
        console.log(`[307] Enviando Data Movimentação: ${dataMovimentacaoStr}`);


        const dataPagamentoInput = await editarMovimentacaoPage.getDataPagamento();
        await dataPagamentoInput.clear();
        await dataPagamentoInput.sendKeys(dataPagamentoStr);
        console.log(`[307] Enviando Data Pagamento: ${dataPagamentoStr}`);

        // Submeter formulário
        const submitBtn = await driver.findElement(By.css('button[type="submit"]'));
        await submitBtn.click();

        // Esperar redirecionamento para detalhes E esperar o alerta de sucesso aparecer
        await driver.wait(until.urlContains('/contas/detalhes/'), 10000, 'Esperado redirecionamento para /contas/detalhes/ após salvar.');
        await driver.wait(until.elementLocated(By.css('.alert.alert-success')), 5000, 'Esperado alerta de sucesso após salvar.');

        // Validar mensagem sucesso
        const alertaSucesso = await driver.findElement(By.css('.alert.alert-success'));
        expect(await alertaSucesso.getText()).to.include('Movimentação atualizada com sucesso!');

        // NOVO: Encontrar a linha da movimentação pela descrição original para validar
        // É importante re-localizar a linha após a atualização da página
        const linhaAtualizada = await driver.findElement(By.xpath(`//table//tr[td[normalize-space(text())="${descricaoMovimentacaoOriginal}"]]`));
        const situacaoDepoisTexto = await linhaAtualizada.findElement(By.css('td:nth-child(5)')).getText();
        const situacaoDepois = situacaoDepoisTexto.trim().toLowerCase();
        console.log(`[307] Situação validada na tabela: "${situacaoDepois}" (esperado: "${novaSituacao}")`);

        expect(situacaoDepois).to.equal(novaSituacao);

    } finally {
        // Fechar abas e voltar para a original, usando as variáveis declaradas no escopo pai
        const handlesAfter = await driver.getAllWindowHandles();
        if (editarTab && handlesAfter.includes(editarTab)) {
            await driver.switchTo().window(editarTab);
            await driver.close();
        }
        if (detalhesTab && handlesAfter.includes(detalhesTab)) {
            await driver.switchTo().window(detalhesTab);
            await driver.close();
        }
        await driver.switchTo().window(originalWindow);
    }
  });

  it('308 - Deve alterar movimentação de PENDENTE para PAGO e validar mudanças', async () => {
     const originalWindow = await driver.getWindowHandle();
    const initialStatus = 'Pendente';
    const targetStatus = 'Pago';

    await driver.get(`${baseUrl}/home`);
    await driver.wait(until.elementLocated(By.css('table.table')), 10000);

    // Acessa a Conta 3
    const conta3Row = await driver.findElement(By.xpath("//tr[td/a[normalize-space(text())='Conta 3']]"));
    const btnDetalhes = await conta3Row.findElement(By.css('a.btn-primary'));
    const detalhesHref = await btnDetalhes.getAttribute('href');
    await driver.get(detalhesHref);
    await driver.wait(until.elementLocated(By.css('h2')), 10000);

    // Encontra a primeira linha com status inicial
    const linhas = await driver.findElements(By.css('table tbody tr'));
    let linhaAlvo;
    let descricaoMovimentacaoAlvo; // Para identificar a linha após a atualização
    for (const linha of linhas) {
      const tds = await linha.findElements(By.css('td'));
      if (tds.length >= 5) {
        const statusText = (await tds[4].getText()).trim().toLowerCase();
        if (statusText === initialStatus.toLowerCase()) {
          linhaAlvo = linha;
          descricaoMovimentacaoAlvo = (await tds[1].getText()).trim(); // Captura a descrição
          break;
        }
      }
    }
    if (!linhaAlvo) throw new Error(`Nenhuma movimentação com status ${initialStatus} encontrada.`);

    // Clica no botão Editar
    const btnEditar = await linhaAlvo.findElement(By.css('a.btn-warning'));
    await btnEditar.click();
    await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
    await driver.wait(until.elementLocated(By.css('form')), 10000);

    const hoje = new Date();
    const hojeFormatado = formatDateToDD_MM_YYYY(hoje); // para preencher input

    // Altera situação para Pago
    const radio = await editarMovimentacaoPage.getSituacao('pago');
    await radio.click();

    // Preenche a data de pagamento
    const dataPag = await editarMovimentacaoPage.getDataPagamento();
    await dataPag.clear();
    await dataPag.sendKeys(hojeFormatado);

    // Submete o formulário
    await editarMovimentacaoPage.submit();

    // Aguarda redirecionamento e mensagem de sucesso
    await driver.wait(until.urlContains('/contas/detalhes/'), 10000);
    const successMsg = await driver.findElement(By.xpath("//*[contains(text(),'Movimentação atualizada com sucesso')]"));
    expect(await successMsg.isDisplayed()).to.be.true;

    // Validação final: situação na tabela
    // Re-localiza a linha pela descrição para garantir que estamos verificando a movimentação correta
    const novaLinha = await driver.wait(until.elementLocated(By.xpath(`//table//tr[td[normalize-space(text())="${descricaoMovimentacaoAlvo}"]]`)), 10000);
    const tds = await novaLinha.findElements(By.css('td'));

    const situacaoFinal = (await tds[4].getText()).trim().toLowerCase();
    expect(situacaoFinal).to.equal(targetStatus.toLowerCase());

    // REMOVIDA A VALIDAÇÃO DA DATA DE MOVIMENTAÇÃO, POIS ELA NÃO É ALTERADA PELO TESTE
    // E NÃO HÁ GARANTIA DE QUE A DATA DE PAGAMENTO ESTEJA NA PRIMEIRA COLUNA.

    // Volta para aba original
    await driver.switchTo().window(originalWindow);
  });
});

 it('309 - Deve exibir erro se "Descrição" estiver vazio', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getValor()).clear(); // Limpa para garantir que o erro de descrição seja o primeiro
      await (await editarMovimentacaoPage.getValor()).sendKeys('100,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203'); // Assumindo que 203 é um valor válido para select
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje); // Usando DD-MM-YYYY para input
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Descrição é obrigatória.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Descrição é obrigatória.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('310 - Deve exibir erro ao submeter com Valor inválido (zero)', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('0,00'); // Valor zero
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Valor Zero');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'O valor deve ser maior ou igual a 0.01.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'O valor deve ser maior ou igual a 0.01.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('311 - Deve exibir erro ao submeter movimentação PAGA com Data de Pagamento futura', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 2');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      const hoje = new Date();
      const dataHojeStr = formatDateToDD_MM_YYYY(hoje); // DD-MM-YYYY para input

      const dataFutura = new Date(hoje);
      dataFutura.setDate(dataFutura.getDate() + 1);
      const dataFuturaStr = formatDateToDD_MM_YYYY(dataFutura); // DD-MM-YYYY para input

      // A mensagem de erro do backend Python é dinâmica.
      // Precisamos construir a mensagem esperada.
      const dataMinima = new Date();
      dataMinima.setDate(dataMinima.getDate() - 3650); // 10 anos atrás
      const dataMinimaStrFormatada = dataMinima.toLocaleDateString('pt-BR'); // DD/MM/YYYY
      const dataMaximaStrFormatada = hoje.toLocaleDateString('pt-BR');        // DD/MM/YYYY

      const mensagemEsperada = `A data de pagamento deve estar entre ${dataMinimaStrFormatada} e ${dataMaximaStrFormatada}.`;

      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(dataHojeStr); // Data de movimentação hoje
      await (await editarMovimentacaoPage.getSituacao('pago')).click();
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(dataFuturaStr); // Data de pagamento futura
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Data Futura');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('50,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await editarMovimentacaoPage.submit();

      await driver.wait(until.elementLocated(By.xpath(`//*[contains(text(),'${mensagemEsperada}')]`)), 5000);
      expect(await driver.findElement(By.xpath(`//*[contains(text(),'${mensagemEsperada}')]`)).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('312 - Deve exibir erro se "Tipo" estiver vazio', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 2');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Tenta selecionar a opção vazia (se existir, ou apenas limpa se for um input)
      // Para select, podemos usar sendKeys com um valor vazio ou um valor que não existe para deselecionar
      // ou se o select tiver uma opção vazia, selecionar por ela.
      // Assumindo que getTipo() retorna um select element.
      // A forma mais robusta para "deselecionar" ou forçar o estado "vazio" em um select
      // é tentar selecionar uma opção com value="" ou a primeira opção se ela for a "placeholder".
      // Se não houver uma opção com value="", e o campo já vem preenchido,
      // a única forma de gerar o erro é se o backend validar que um tipo válido não foi selecionado.
      // Se o campo já vem com um valor padrão, e você não o altera, o teste pode não falhar.
      // Para simular o "vazio", se houver uma opção com value="", podemos tentar selecioná-la.
      // Caso contrário, se o campo já vem preenchido e não há opção vazia,
      // o teste pode não conseguir simular o "vazio" sem manipulação mais profunda do DOM.
      // Por enquanto, vamos tentar selecionar a opção com value="" se ela existir.
      // Se não existir, e o campo já vem preenchido, este teste pode precisar de um ajuste na aplicação.
      try {
        const tipoSelect = await editarMovimentacaoPage.getTipo();
        const emptyOption = await tipoSelect.findElement(By.css('option[value=""]'));
        await emptyOption.click();
      } catch (error) {
        console.warn("Opção vazia para 'Tipo' não encontrada. O teste pode não simular o cenário de 'vazio' corretamente se o campo já vem preenchido.");
        // Se não encontrar a opção vazia, não faz nada, assumindo que o campo já está em um estado que causará o erro
        // ou que o teste deve falhar por não conseguir simular o cenário.
      }


      // Preenche os outros campos com valores válidos para isolar o erro
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Tipo Vazio');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('100,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Selecione o tipo de movimentação.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Selecione o tipo de movimentação.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });


  it('313 - Deve exibir erro se "Data de movimentação" for futura', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Preenche a data de movimentação com uma data futura (amanhã)
      const amanha = new Date();
      amanha.setDate(amanha.getDate() + 1);
      const amanhaFormatado = formatDateToDD_MM_YYYY(amanha);

      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(amanhaFormatado);

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa'); // Assumindo que 'despesa' é um valor válido
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Data Futura Mov');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('50,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'A data da movimentação deve estar entre')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'A data da movimentação deve estar entre')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('314 - Deve exibir erro se "Data de movimentação" for muito no passado', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Preenche a data de movimentação com uma data muito no passado (ex: 2000-01-01)
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys('01-01-2000'); // Usando DD-MM-YYYY para input

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Data Passada Mov');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('50,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'A data da movimentação deve estar entre')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'A data da movimentação deve estar entre')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('315 - Deve exibir erro se "Data de pagamento" for anterior à Data de Movimentação para PENDENTE', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Preenche a data de movimentação (ex: hoje)
      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      // Preenche a data de pagamento com uma data anterior à data de movimentação (ex: ontem)
      const ontem = new Date();
      ontem.setDate(ontem.getDate() - 1);
      const ontemFormatado = formatDateToDD_MM_YYYY(ontem);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(ontemFormatado);

      // Define a situação como "pendente" (para ativar essa validação)
      await (await editarMovimentacaoPage.getSituacao('pendente')).click();

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Data Pag. < Data Mov.');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('75,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');

      await editarMovimentacaoPage.submit();

      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Para movimentações pendentes, a data de pagamento não pode ser no passado.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Para movimentações pendentes, a data de pagamento não pode ser no passado.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('316 - Deve exibir erro se "Descrição" exceder 30 caracteres', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Preenche a descrição com mais de 30 caracteres
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Esta é uma descrição muito, muito longa que excede o limite de 30 caracteres.');

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('100,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      // Valida a mensagem de erro
      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Descrição deve ter no máximo 30 caracteres.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Descrição deve ter no máximo 30 caracteres.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

 it('317 - Deve exibir erro se "Valor" estiver vazio', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Limpa o campo Valor
      await (await editarMovimentacaoPage.getValor()).clear();

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Valor Vazio');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      // Valida a mensagem de erro
      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Informe um valor.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Informe um valor.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('318 - Deve exibir erro se "Valor" for inválido (texto)', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Preenche o campo Valor com texto inválido
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('Valor inválido');

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Valor Texto');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      // Valida a mensagem de erro (a mensagem exata pode variar dependendo do WTForms e do navegador)
      // Uma mensagem comum é "Valor inválido." ou "Não é um número válido."
      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Valor inválido.')]")), 5000); // Ou 'Deve ser um número válido'
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Valor inválido.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('319 - Deve exibir erro se "Data de movimentação" estiver vazia', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Limpa o campo Data de movimentação
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Data Mov Vazia');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('100,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      // Valida a mensagem de erro
      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Informe a data da movimentação.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Informe a data da movimentação.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('320 - Deve exibir erro se "Conta" não for selecionada', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Seleciona a opção com valor 0 (geralmente "Selecione uma conta")
      // A forma mais robusta é encontrar a opção pelo seu valor e clicar nela.
      const contaSelect = await editarMovimentacaoPage.getContaId();
      const optionZero = await contaSelect.findElement(By.css('option[value="0"]'));
      await optionZero.click();

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Conta Vazia');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('100,00');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      // Valida a mensagem de erro
      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Você precisa selecionar uma conta.')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Você precisa selecionar uma conta.')]")).isDisplayed()).to.be.true;
      expect(await driver.getCurrentUrl()).to.include('/movimentacao/editar/');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });


  it('321 - Deve permitir limpar o campo "Interessado" (não obrigatório)', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      // Limpa o campo Interessado
      await (await editarMovimentacaoPage.getInteressado()).clear();

      // Preenche os outros campos com valores válidos (para garantir que a submissão aconteça)
      await (await editarMovimentacaoPage.getTipo()).sendKeys('despesa');
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Interessado Limpo');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('10,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      // Valida que a atualização foi um sucesso (redirecionou)
      await driver.wait(until.urlContains('/contas/detalhes/'), 10000);
      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Movimentação atualizada com sucesso!')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Movimentação atualizada com sucesso!')]")).isDisplayed()).to.be.true;

      // Opcional: Validar que o campo Interessado está de fato vazio na tabela de detalhes,
      // se essa coluna for visível e o teste se aplicar.
      // Para fazer isso, você precisaria encontrar a linha da movimentação na tabela de detalhes
      // e verificar o conteúdo da célula correspondente ao "Interessado".
      // Exemplo (requer que a descrição seja única ou que você tenha outro identificador):
      // const linhaMovimentacao = await driver.findElement(By.xpath(`//table//tr[td[normalize-space(text())='Teste Interessado Limpo']]`));
      // const celulaInteressado = await linhaMovimentacao.findElement(By.css('td:nth-child(<indice_coluna_interessado>)'));
      // expect(await celulaInteressado.getText()).to.equal('');

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });

  it('322 - Deve permitir preencher o campo "Interessado" (não obrigatório)', async () => {
    const originalWindow = await driver.getWindowHandle();
    let detalhesTab;
    let editarTab;

    try {
      detalhesTab = await abrirDetalhesConta('Conta 3');
      const primeiraLinha = await driver.findElement(By.css('table tbody tr:first-child'));
      const editarBtn = await primeiraLinha.findElement(By.css('a.btn-warning'));
      await editarBtn.click();
      await driver.wait(until.urlContains('/movimentacao/editar/'), 10000);
      await driver.wait(until.elementLocated(By.css('h2')), 5000);
      expect(await driver.findElement(By.css('h2')).getText()).to.include('Editar Movimentação');

      const interessado = 'Novo Interessado Teste';
      await (await editarMovimentacaoPage.getInteressado()).clear();
      await (await editarMovimentacaoPage.getInteressado()).sendKeys(interessado);

      // Preenche os outros campos com valores válidos
      await (await editarMovimentacaoPage.getTipo()).sendKeys('receita'); // Altera tipo para garantir mudança
      await (await editarMovimentacaoPage.getDescricao()).clear();
      await (await editarMovimentacaoPage.getDescricao()).sendKeys('Teste Interessado Preenchido');
      await (await editarMovimentacaoPage.getValor()).clear();
      await (await editarMovimentacaoPage.getValor()).sendKeys('200,00');
      await (await editarMovimentacaoPage.getContaId()).sendKeys('203');
      await (await editarMovimentacaoPage.getSituacao('pago')).click();

      const hoje = new Date();
      const hojeFormatado = formatDateToDD_MM_YYYY(hoje);
      await (await editarMovimentacaoPage.getDataPagamento()).clear();
      await (await editarMovimentacaoPage.getDataPagamento()).sendKeys(hojeFormatado);
      await (await editarMovimentacaoPage.getDataMovimentacao()).clear();
      await (await editarMovimentacaoPage.getDataMovimentacao()).sendKeys(hojeFormatado);

      await editarMovimentacaoPage.submit();

      // Valida que a atualização foi um sucesso (redirecionou)
      await driver.wait(until.urlContains('/contas/detalhes/'), 10000);
      await driver.wait(until.elementLocated(By.xpath("//*[contains(text(),'Movimentação atualizada com sucesso!')]")), 5000);
      expect(await driver.findElement(By.xpath("//*[contains(text(),'Movimentação atualizada com sucesso!')]")).isDisplayed()).to.be.true;

      // Opcional: Validar que o campo Interessado está de fato preenchido na tabela de detalhes,
      // se essa coluna for visível e o teste se aplicar.
      // Exemplo (requer que a descrição seja única ou que você tenha outro identificador):
      // const linhaMovimentacao = await driver.findElement(By.xpath(`//table//tr[td[normalize-space(text())='Teste Interessado Preenchido']]`));
      // const celulaInteressado = await linhaMovimentacao.findElement(By.css('td:nth-child(<indice_coluna_interessado>)'));
      // expect(await celulaInteressado.getText()).to.equal(interessado);

    } finally {
      const handlesAfter = await driver.getAllWindowHandles();
      if (editarTab && handlesAfter.includes(editarTab)) {
          await driver.switchTo().window(editarTab);
          await driver.close();
      }
      if (detalhesTab && handlesAfter.includes(detalhesTab)) {
          await driver.switchTo().window(detalhesTab);
          await driver.close();
      }
      await driver.switchTo().window(originalWindow);
    }
  });
});