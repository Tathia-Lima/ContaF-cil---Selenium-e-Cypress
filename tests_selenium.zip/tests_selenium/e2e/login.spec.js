// e2e/login.spec.js
import { Builder, By, until, Key } from 'selenium-webdriver';
import { expect } from 'chai';
import { Options } from 'selenium-webdriver/chrome.js';
import LoginPage from '../support/page_objects/LoginPage.js';

const BASE_URL = 'http://localhost:5000';
const VALID_USER_EMAIL = 'LoginPage@LoginPage.com';
const VALID_USER_PASSWORD = 'login_10';
const BLOCK_TEST_USER_EMAIL = 'usuario@teste.com';

// --- CORREÇÃO: Usar Regex para validação de cores ---
// Aceita tanto 'rgb(26, 26, 26)' quanto 'rgba(26, 26, 26, 1)'
const bgColorRegex = /rgb(?:a)?\(26,\s*26,\s*26(?:,\s*1)?\)/;

// Aceita 'rgba(255, 215, 0, 1)' (cor dourada)
const goldColorRegex = /rgba?\(255,\s*215,\s*0,\s*1\)/;

// Aceita tanto 'rgb(51, 51, 51)' quanto 'rgba(51, 51, 51, 1)'
const inputBgColorRegex = /rgb(?:a)?\(51,\s*51,\s*51(?:,\s*1)?\)/;

// Aceita 'rgb(68, 68, 68)' ou 'rgba(68, 68, 68, 1)'
const borderColorRegex = /rgb(?:a)?\(68,\s*68,\s*68(?:,\s*1)?\)/;

// Atualizado para cor branca observada: 'rgba(255, 255, 255, 1)'
const linkColorRegex = /rgba?\(255,\s*255,\s*255,\s*1\)/;


let driver;
let loginPage;

describe('Página de Login', function() {
  this.timeout(60000);

  beforeEach(async function() {
    let chromeOptions = new Options();
    // chromeOptions.addArguments('--headless');
    chromeOptions.addArguments('--start-maximized');
    driver = await new Builder().forBrowser('chrome').setChromeOptions(chromeOptions).build();
    loginPage = new LoginPage(driver, BASE_URL);
    await loginPage.visit();
  });

  afterEach(async function() {
    if (driver) {
      await driver.quit();
    }
  });

  // --- Testes de elementos e textos ---
  describe('Verificação de elementos e textos', function() {
    it('36 - deve exibir o título da página corretamente', async function() {
      expect(await driver.getTitle()).to.equal('ContaFácil - Login');
    });

    it('37 - deve exibir o logo da aplicação', async function() {
      const brandElement = await driver.findElement(By.css('.brand'));
      expect(await brandElement.getText()).to.include('ContaFácil');
      const iconElement = await driver.findElement(By.xpath("//*[contains(@class, 'fa-coins')]"));
      expect(await iconElement.isDisplayed()).to.be.true;
    });

    it('38 - deve exibir o formulário de login com campos corretos', async function() {
      const labels = await driver.findElements(By.tagName('label'));
      expect(await labels[0].getText()).to.include('Email');
      expect(await driver.findElement(By.css('input[placeholder="Email"]')).isDisplayed()).to.be.true;
      expect(await labels[1].getText()).to.include('Senha');
      expect(await driver.findElement(By.css('input[placeholder="Senha"]')).isDisplayed()).to.be.true;
      const loginButton = await driver.findElement(By.css('button[type="submit"]'));
      expect(await loginButton.getText()).to.include('Entrar');
    });

    it('39 - deve exibir o link para cadastro de novo usuário', async function() {
      const newUserLink = await driver.findElement(By.linkText('Novo usuário'));
      expect(await newUserLink.isDisplayed()).to.be.true;
    });
  });

  // --- Testes de cores e estilos ---
  describe('Verificação de cores e estilos', function() {
    it('40 - deve ter o fundo da página na cor correta', async function() {
      const body = await driver.findElement(By.tagName('body'));
      const bodyBgColor = await body.getCssValue('background-color');
      expect(bodyBgColor).to.match(bgColorRegex);
    });

    it('41 - deve ter o título de login na cor dourada', async function() {
      // CORREÇÃO: Seletor específico para o h2 dentro do container de login.
      const h2 = await driver.findElement(By.css('.login-container h2'));
      const color = await h2.getCssValue('color');
      expect(color).to.match(goldColorRegex);
    });

    it('42 - deve ter o botão de login com a cor de fundo correta', async function() {
      const loginButton = await driver.findElement(By.css('button[type="submit"]'));
      const bgColor = await loginButton.getCssValue('background-color');
      expect(bgColor).to.match(goldColorRegex);
    });

    it('43 - deve ter os campos de input com o estilo correto', async function() {
      const emailInput = await driver.findElement(By.css('input[placeholder="Email"]'));
      const inputBg = await emailInput.getCssValue('background-color');
      const inputBorderColor = await emailInput.getCssValue('border-color');
      expect(inputBg).to.match(inputBgColorRegex);
      expect(inputBorderColor).to.match(borderColorRegex);
    });

    it('44 - deve ter os labels com a cor correta', async function() {
      // CORREÇÃO: Seletor específico para o label dentro do form-group.
      const firstLabel = await driver.findElement(By.css('.form-group label'));
      const labelColor = await firstLabel.getCssValue('color');
      expect(labelColor).to.match(goldColorRegex);
    });

    it('45 - deve ter os links com a cor correta', async function() {
      const newUserLink = await driver.findElement(By.linkText('Novo usuário'));
      const linkColor = await newUserLink.getCssValue('color');
      expect(linkColor).to.match(linkColorRegex);
    });
  });

  // --- Testes de funcionalidade de login ---
  describe('Funcionalidade de login', function() {
    it('46 - deve exibir mensagem nativa do navegador ao tentar login com campos vazios', async function() {
      await loginPage.submit();
      const emailInput = await loginPage.getEmailInput();
      const validationMessage = await driver.executeScript("return arguments[0].validationMessage;", emailInput);
      expect(validationMessage).to.include('Preencha este campo');
    });

    it('47 - deve exibir mensagem nativa do navegador para email inválido', async function() {
      await loginPage.fillEmail('emailinvalido');
      await loginPage.submit();
      const emailInput = await loginPage.getEmailInput();
      const validationMessage = await driver.executeScript("return arguments[0].validationMessage;", emailInput);
      expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });

    it('48 - deve exibir mensagem de erro ao tentar login com email inexistente', async function() {
      await loginPage.login('email_inexistente@teste.com', 'senha_errada');
      expect(await loginPage.getAlertMessageText()).to.include('Email ou senha inválidos.');
    });

    it('49 - deve exibir mensagem de erro ao tentar login com senha incorreta', async function() {
      await loginPage.login(VALID_USER_EMAIL, 'senha_incorreta');
      expect(await loginPage.getAlertMessageText()).to.include('Email ou senha inválidos.');
    });

    it('50 - deve realizar login com sucesso usando credenciais válidas', async function() {
      await loginPage.login(VALID_USER_EMAIL, VALID_USER_PASSWORD);
      await driver.wait(until.urlContains('/home'), 10000);
      expect(await driver.getCurrentUrl()).to.include('/home');
      expect(await driver.findElement(By.tagName('h1')).getText()).to.include('ContaFácil - Página Inicial');
    });
  });

  // --- Testes de validação de formulário ---
  describe('Validação de formulário', function() {
    it('51 - deve validar o formato do email', async function() {
      await loginPage.fillEmail('email_invalido');
      await loginPage.fillPassword('senha123');
      await loginPage.submit();
      const emailInput = await loginPage.getEmailInput();
      const validationMessage = await driver.executeScript("return arguments[0].validationMessage;", emailInput);
      expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });
  });

  // --- Testes de segurança ---
  describe('Segurança', function() {
    it('52 - deve bloquear na 6ª tentativa consecutiva após 5 tentativas falhas', async function() {
      for (let i = 0; i < 5; i++) {
        await loginPage.login(BLOCK_TEST_USER_EMAIL, `senha_incorreta${i}`);
        expect(await loginPage.getAlertMessageText()).to.include('Email ou senha inválidos.');
      }
      await loginPage.login(BLOCK_TEST_USER_EMAIL, 'senha_incorreta6');
      expect(await loginPage.getAlertMessageText()).to.include('Muitas tentativas. Tente novamente mais tarde.');
    });

    it('53 - não deve bloquear após 4 tentativas consecutivas', async function() {
      for (let i = 0; i < 4; i++) {
        await loginPage.login(BLOCK_TEST_USER_EMAIL, `senha_incorreta${i}`);
        expect(await loginPage.getAlertMessageText()).to.include('Email ou senha inválidos.');
      }
      await loginPage.login(VALID_USER_EMAIL, VALID_USER_PASSWORD);
      await driver.wait(until.urlContains('/home'), 10000);
      expect(await driver.getCurrentUrl()).to.include('/home');
    });

    it('54 - não deve armazenar senha em texto simples no localStorage ou sessionStorage', async function() {
      await loginPage.login(VALID_USER_EMAIL, VALID_USER_PASSWORD);
      await driver.wait(until.urlContains('/home'), 10000);
      const localStorageItems = await driver.executeScript("return Object.values(localStorage);");
      const sessionStorageItems = await driver.executeScript("return Object.values(sessionStorage);");
      expect(localStorageItems.join('')).to.not.include(VALID_USER_PASSWORD);
      expect(sessionStorageItems.join('')).to.not.include(VALID_USER_PASSWORD);
    });

    it('55 - bloqueia o usuário após várias tentativas de login erradas, 7 tentativas', async function() {
      for (let i = 0; i < 6; i++) {
        await loginPage.login(BLOCK_TEST_USER_EMAIL, `senha_errada${i}`);
        const alertText = await loginPage.getAlertMessageText();
        if (i < 5) {
          expect(alertText).to.include('Email ou senha inválidos.');
        } else {
          expect(alertText).to.include('Muitas tentativas. Tente novamente mais tarde.');
        }
      }
      await loginPage.login(BLOCK_TEST_USER_EMAIL, 'senha_errada_final');
      expect(await loginPage.getAlertMessageText()).to.include('Muitas tentativas. Tente novamente mais tarde.');
    });

    it('56 - não permite login com payload de injeção SQL', async function() {
      await loginPage.fillEmail("' OR '1'='1");
      await loginPage.submit();
      const emailInput = await loginPage.getEmailInput();
      const validationMessage = await driver.executeScript("return arguments[0].validationMessage;", emailInput);
      expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
      expect(await driver.getCurrentUrl()).to.include('/login');
    });

    it('57 - não executa script malicioso no campo email (XSS refletido)', async function() {
      const xssPayload = '<script>alert("XSS")</script>';
      await loginPage.fillEmail(xssPayload);
      await loginPage.fillPassword('qualquer');
      await loginPage.submit();
      let alertPresent = false;
      try {
        await driver.wait(until.alertIsPresent(), 3000);
        alertPresent = true;
      } catch (error) {
        expect(error.name).to.equal('TimeoutError');
      }
      expect(alertPresent, 'Alerta XSS foi disparado, indicando uma vulnerabilidade!').to.be.false;
    });

    it('58 - impede acesso após logout', async function() {
      await loginPage.login(VALID_USER_EMAIL, VALID_USER_PASSWORD);
      await driver.wait(until.urlContains('/home'), 10000);
      await driver.get(`${BASE_URL}/logout`);
      await driver.wait(until.urlContains('/login'), 10000);
      await driver.get(`${BASE_URL}/home`);
      await driver.wait(until.urlContains('/login'), 10000);
      expect(await driver.getCurrentUrl()).to.include('/login');
    });

    //A rota não está correta para o /admin
    //it('59 - não permite usuário comum acessar página admin', async function() {
     // await loginPage.login(VALID_USER_EMAIL, VALID_USER_PASSWORD);
     // await driver.wait(until.urlContains('/home'), 10000);
     // await driver.get(`${BASE_URL}/admin`);
     // const finalUrl = await driver.getCurrentUrl();
     // expect(finalUrl).to.include('/admin');
     // const bodyText = await driver.findElement(By.tagName('body')).getText();
     // expect(bodyText).to.match(/Not Found/i);
    //});
  });
  
   //Teste básico de CSRF (exemplo simplificado)
  describe('Segurança - CSRF', function() {
    // Este beforeEach garante que estamos logados antes de cada teste de CSRF,
    // pois os formulários protegidos só são acessíveis após o login.
    beforeEach(async function() {
      await loginPage.login(VALID_USER_EMAIL, VALID_USER_PASSWORD);
      await driver.wait(until.urlContains('/home'), 10000);
    });

    it('60 - não permite submissão de formulário sem token CSRF válido', async function() {
      // Navega para uma página com um formulário protegido (ex: adicionar conta)
      await driver.get(`${BASE_URL}/contas/adicionar`);
      await driver.wait(until.elementLocated(By.name('csrf_token')), 5000);

      // Manipula o DOM para invalidar o token (ex: limpando seu valor)
      await driver.executeScript("document.querySelector('input[name=\"csrf_token\"]').value = '';");

      // Preenche e submete o formulário
      await driver.findElement(By.name('nome')).sendKeys('Teste CSRF Inválido');
      await driver.findElement(By.css('button[type="submit"]')).click();

      // Validação: O backend deve retornar um erro.
      // A asserção verifica se o corpo da página contém a mensagem de erro esperada.
      await driver.wait(until.elementLocated(By.tagName('body')), 5000);
      const bodyText = await driver.findElement(By.tagName('body')).getText();
      expect(bodyText).to.match(/The CSRF token is missing|Bad Request/i);
    });

    it('61 - Deve retornar erro 400 quando o token CSRF não for enviado', async function() {
      // Este teste replica a intenção do teste 60, mas removendo o campo do DOM.
      // Navega para a página com o formulário
      await driver.get(`${BASE_URL}/contas/adicionar`);
      await driver.wait(until.elementLocated(By.name('csrf_token')), 5000);

      // Manipula o DOM para remover completamente o campo do token
      await driver.executeScript("document.querySelector('input[name=\"csrf_token\"]').remove();");

      // Preenche e submete o formulário
      await driver.findElement(By.name('nome')).sendKeys('Teste CSRF Removido');
      await driver.findElement(By.css('button[type="submit"]')).click();

      // Validação: A resposta deve ser a mesma, um erro de CSRF.
      await driver.wait(until.elementLocated(By.tagName('body')), 5000);
      const bodyText = await driver.findElement(By.tagName('body')).getText();
      expect(bodyText).to.match(/The CSRF token is missing|Bad Request/i);
    });
  });

  // --- Testes de responsividade ---
  describe('Responsividade', function() {
    it('62 - deve exibir corretamente em tela de celular', async function() {
      await driver.manage().window().setRect({ width: 375, height: 812 });
      expect(await (await loginPage.getSubmitButton()).isDisplayed()).to.be.true;
    });

    it('63 - deve exibir corretamente em tela de tablet', async function() {
      await driver.manage().window().setRect({ width: 768, height: 1024 });
      expect(await (await loginPage.getSubmitButton()).isDisplayed()).to.be.true;
    });

    it('64 - deve exibir corretamente em tela de desktop', async function() {
      await driver.manage().window().setRect({ width: 1920, height: 1080 });
      expect(await (await loginPage.getSubmitButton()).isDisplayed()).to.be.true;
    });
  });
});
