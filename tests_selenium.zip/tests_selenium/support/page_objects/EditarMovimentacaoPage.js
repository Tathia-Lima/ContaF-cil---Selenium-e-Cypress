import { By } from 'selenium-webdriver';

export default class EditarMovimentacaoPage{
  constructor(driver) {
    this.driver = driver;
  }

  async visit(movimentacaoId) {
    await this.driver.get(`http://localhost:5000/movimentacao/editar/${movimentacaoId}`);
  }

  async getTipo() {
    return await this.driver.findElement(By.name('tipo'));
  }

  async getValor() {
    return await this.driver.findElement(By.name('valor'));
  }

  async getDataMovimentacao() {
    return await this.driver.findElement(By.name('data_movimentacao'));
  }

  async getDataPagamento() {
    return await this.driver.findElement(By.name('data_pagamento'));
  }

  async getDescricao() {
    return await this.driver.findElement(By.name('descricao'));
  }

  async getInteressado() {
    return await this.driver.findElement(By.name('interessado'));
  }

  async getContaId() {
    return await this.driver.findElement(By.name('conta_id'));
  }

  async getSituacao(situacao) {
    return await this.driver.findElement(By.css(`input[name="situacao"][value="${situacao}"]`));
  }

  async submit() {
    const button = await this.driver.findElement(By.css('button[type="submit"]'));
    await button.click();
  }

  async cancelar() {
    const btnCancelar = await this.driver.findElement(By.xpath("//a[contains(text(),'Cancelar')]"));
    await btnCancelar.click();
  }

  async getAlerta() {
    return await this.driver.findElement(By.css('.alert, .flash-message'));
  }
}
