// support/page_objects/MovimentacaoPage.js
import { By, until } from 'selenium-webdriver';

class MovimentacaoPage {
  constructor(driver, baseUrl) {
    this.driver = driver;
    this.url = `${baseUrl}/movimentacao`;

    // Seletores
    this.tipoSelect = By.name('tipo');
    this.dataMovimentacaoInput = By.name('data_movimentacao');
    this.dataPagamentoInput = By.name('data_pagamento');
    this.descricaoInput = By.name('descricao');
    this.interessadoInput = By.name('interessado');
    this.valorInput = By.name('valor');
    this.contaSelect = By.name('conta_id');
    this.situacaoPagoRadio = By.css('input[name="situacao"][value="pago"]');
    this.situacaoPendenteRadio = By.css('input[name="situacao"][value="pendente"]');
    this.submitButton = By.css('button[type="submit"]');
    this.cancelButton = By.css('a.btn-secondary');
  }

  async visitar() {
    await this.driver.get(this.url);
    await this.driver.wait(until.elementLocated(this.submitButton), 10000);
  }

  // *** MÉTODOS DE INTERAÇÃO ATÔMICOS E ROBUSTOS ***

  async preencherCampo(seletor, valor) {
    const elemento = await this.driver.findElement(seletor);
    await elemento.clear(); // Limpa antes de preencher
    if (valor !== null && valor !== undefined) {
      await elemento.sendKeys(valor.toString());
    }
  }

  async preencherData(seletor, dataString) {
    const elemento = await this.driver.findElement(seletor);
    await elemento.clear(); // Limpa antes de preencher
    if (dataString) {
      // Converte 'YYYY-MM-DD' para 'DD-MM-YYYY'
      const [ano, mes, dia] = dataString.split('-');
      const dataFormatada = `${dia}-${mes}-${ano}`;
      await elemento.sendKeys(dataFormatada);
    }
  }

  async selecionarOpcao(seletorSelect, textoOpcao) {
    if (!textoOpcao) return;
    const select = await this.driver.findElement(seletorSelect);
    const xpath = `.//option[normalize-space() = "${textoOpcao}"]`;
    await select.findElement(By.xpath(xpath)).click();
  }

  // Preenche o formulário completo com os dados fornecidos
  async preencherFormulario(dados) {
    if (dados.tipo !== undefined) await this.selecionarOpcao(this.tipoSelect, dados.tipo ? dados.tipo.charAt(0).toUpperCase() + dados.tipo.slice(1) : '');
    if (dados.dataMovimentacao !== undefined) await this.preencherData(this.dataMovimentacaoInput, dados.dataMovimentacao);
    if (dados.dataPagamento !== undefined) await this.preencherData(this.dataPagamentoInput, dados.dataPagamento);
    if (dados.descricao !== undefined) await this.preencherCampo(this.descricaoInput, dados.descricao);
    if (dados.interessado !== undefined) await this.preencherCampo(this.interessadoInput, dados.interessado);
    if (dados.valor !== undefined) await this.preencherCampo(this.valorInput, dados.valor);
    if (dados.conta !== undefined) await this.selecionarOpcao(this.contaSelect, dados.conta);
    if (dados.situacao === 'pago') await this.driver.findElement(this.situacaoPagoRadio).click();
    if (dados.situacao === 'pendente') await this.driver.findElement(this.situacaoPendenteRadio).click();
  }

  async submeter() {
    await this.driver.findElement(this.submitButton).click();
  }

  async findElementWithText(text) {
    const xpath = `//*[contains(text(),'${text}')]`;
    await this.driver.wait(until.elementLocated(By.xpath(xpath)), 5000);
    return this.driver.findElement(By.xpath(xpath));
  }
}

export default MovimentacaoPage;
