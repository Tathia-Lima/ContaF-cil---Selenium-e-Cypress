import { By, until } from 'selenium-webdriver';

class HomePage {
  constructor(driver, baseUrl) {
    this.driver = driver;
    this.baseUrl = baseUrl;
    this.url = `${baseUrl}/home`;

    // Seletores da página Home
    this.h1Title = By.css('main h1');
    this.h2Greeting = By.css('main h2');
    this.pExplanation = By.css('main p');
    this.h3SectionTitle = By.css('main h3');
    this.table = By.css('table.table');
    this.tableHeaders = By.css('table thead th');
    this.tableRows = By.css('table tbody tr');
    this.saldoTotalRow = By.css('tr.saldo-total');
    this.noAccountsMessage = By.css('table tbody tr td[colspan="2"]'); // Para a mensagem "Nenhuma conta cadastrada ainda."
  }

  async navigateToHome() {
    await this.driver.get(this.url);
    await this.driver.wait(until.urlContains('/home'), 10000);
  }

  async getPageTitle() {
    return await this.driver.getTitle();
  }

  async getH1Text() {
    return await this.driver.findElement(this.h1Title).getText();
  }

  async getH2Text() {
    return await this.driver.findElement(this.h2Greeting).getText();
  }

  async getPExplanationText() {
    return await this.driver.findElement(this.pExplanation).getText();
  }

  async getH3SectionTitleText() {
    return await this.driver.findElement(this.h3SectionTitle).getText();
  }

  async getTable() {
    return await this.driver.findElement(this.table);
  }

  async getTableHeaders() {
    return await this.driver.findElements(this.tableHeaders);
  }

  async getTableRows() {
    return await this.driver.findElements(this.tableRows);
  }

  async getSaldoTotalRow() {
    return await this.driver.findElement(this.saldoTotalRow);
  }

  async getNoAccountsMessage() {
    return await this.driver.findElement(this.noAccountsMessage);
  }

  async getLinkByAccountName(accountName) {
    // Retorna o link do nome da conta
    return await this.driver.findElement(By.xpath(`//table//tbody//tr//td[1]//a[normalize-space(text())='${accountName}']`));
  }

  async getDetailsButtonByAccountName(accountName) {
    // Retorna o botão Detalhes para uma conta específica
    return await this.driver.findElement(By.xpath(`//table//tbody//tr[td[1]//a[normalize-space(text())='${accountName}']]//td[5]//a[contains(@class, 'btn-primary') and normalize-space(text())='Detalhes']`));
  }

  async getAccountRow(accountName) {
    // Retorna a linha completa da tabela para uma conta específica
    return await this.driver.findElement(By.xpath(`//table//tbody//tr[td[1]//a[normalize-space(text())='${accountName}']]`));
  }

  async getSaldoTotalRow() {
    return await this.driver.findElement(this.saldoTotalRow);
  }

  // Métodos para obter células específicas de uma linha
  async getCellText(rowElement, columnIndex) {
    const cells = await rowElement.findElements(By.css('td'));
    return await cells[columnIndex].getText();
  }

  async getCellElement(rowElement, columnIndex) {
    const cells = await rowElement.findElements(By.css('td'));
    return cells[columnIndex];
  }
}

export default HomePage;
