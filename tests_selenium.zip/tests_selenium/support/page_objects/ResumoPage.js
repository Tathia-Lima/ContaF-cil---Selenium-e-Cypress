// support/page_objects/ResumoPage.js
import { By, until } from 'selenium-webdriver';

class ResumoPage {
  constructor(driver, baseUrl) {
    this.driver = driver;
    this.url = `${baseUrl}/resumo`;

    // Seletores
    this.mesSelect = By.id('mes');
    this.anoSelect = By.id('ano');
    this.tipoSelect = By.id('tipo');
    this.buscarButton = By.xpath('//button[contains(text(), "Buscar")]');
    this.tabela = By.css('table.table');
  }

  async visitar() {
    await this.driver.get(this.url);
    await this.driver.wait(until.urlContains('/resumo'), 10000);
  }

  // Método robusto para selecionar uma opção em um <select>
  async selecionarOpcao(seletorSelect, valor) {
    if (valor === null || valor === undefined) return;
    const select = await this.driver.findElement(seletorSelect);
    const xpath = `.//option[@value='${valor}']`;
    await select.findElement(By.xpath(xpath)).click();
  }

  async filtrarPor(mes, ano, tipo) {
    await this.selecionarOpcao(this.mesSelect, mes);
    await this.selecionarOpcao(this.anoSelect, ano);
    await this.selecionarOpcao(this.tipoSelect, tipo);
    await this.driver.findElement(this.buscarButton).click();
    // Espera a URL ser atualizada E a tabela estar presente
    await this.driver.wait(until.urlContains(`mes=${mes}`), 5000);
    await this.driver.wait(until.elementLocated(this.tabela), 5000);
  }

  async getFiltroValue(seletor) {
    const select = await this.driver.findElement(seletor);
    return await select.getAttribute('value');
  }

  async getLinhasTabela() {
    return this.driver.findElements(By.css('tbody tr'));
  }

  async findElementWithText(text) {
    const xpath = `//*[contains(text(),'${text}')]`;
    await this.driver.wait(until.elementLocated(By.xpath(xpath)), 5000);
    return this.driver.findElement(By.xpath(xpath));
  }

  async excluirMovimentacao(descricao, confirmar) {
    // Encontra a linha baseada na descrição
    const linha = await this.findElementWithText(descricao).then(el => el.findElement(By.xpath('./..')));
    // Clica no botão de exclusão dentro daquela linha
    await linha.findElement(By.css('button.btn-danger')).click();
    // Espera o alerta de confirmação do navegador
    const alert = await this.driver.wait(until.alertIsPresent(), 5000);
    // Aceita ou recusa o alerta
    if (confirmar) {
      await alert.accept();
    } else {
      await alert.dismiss();
    }
  }

  
}

export default ResumoPage;
