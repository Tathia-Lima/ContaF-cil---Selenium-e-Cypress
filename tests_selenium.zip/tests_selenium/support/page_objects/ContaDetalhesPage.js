import { By, until } from 'selenium-webdriver';

export default class ContaDetalhesPage {
  constructor(driver) {
    this.driver = driver;
    this.urlBase = 'http://localhost:5000/contas/detalhes/';

    // Locators (ajuste conforme seu HTML)
    this.title = By.css('h2'); // título da página detalhes
    this.contaNomeDisplay = By.xpath("//label[text()='Nome da Conta:']/following-sibling::div");
    this.tipoContaDisplay = By.xpath("//label[text()='Tipo de Conta:']/following-sibling::div");
    this.usuarioContaDisplay = By.xpath("//label[text()='Usuário da Conta:']/following-sibling::div");
    this.dataCriacaoDisplay = By.xpath("//label[text()='Data de Criação:']/following-sibling::div");
    this.saldoAtualDisplay = By.css('.saldo-info div'); // localizador para o valor do saldo

    // Locators para a tabela de movimentações
    this.movementTableRows = By.css('table.table tbody tr');

    // Locators para a paginação
    // Seleciona todos os links de página que não são "Anterior" ou "Próximo"
    this.paginationLinks = By.css('.pagination .page-item:not(.disabled) a.page-link');
    this.previousPageButton = By.xpath("//li[@class='page-item']//a[text()='Anterior']");
    this.nextPageButton = By.xpath("//li[@class='page-item']//a[text()='Próximo']");


    // Outros locators, botões, mensagens...
    // CORRIGIDO: Locator mais específico para o botão "Voltar para Contas"
    this.btnVoltar = By.xpath("//a[text()='Voltar para Contas']");
    this.btnEditarConta = By.css('a.btn-warning'); // Ajustado para a tag 'a'
    this.btnNovaMovimentacao = By.css('a.btn-success'); // Ajustado para a tag 'a'
  }

    async visit(contaId, page = 1) {
    await this.driver.get(`${this.urlBase}${contaId}?page=${page}`);
    // Adicione uma espera por um elemento chave para garantir que a página carregou
    await this.driver.wait(until.elementLocated(this.title), 10000); // Espera pelo título da página
  }

  // --------- Ações e utilitários genéricos ---------
  async getText(locator, message = 'Elemento não visível') {
    const el = await this.driver.wait(until.elementLocated(locator), 5000, message);
    return await el.getText();
  }

  async getColor(locator) {
    const el = await this.driver.wait(until.elementLocated(locator), 5000);
    return await el.getCssValue('color');
  }

  async click(locator, expectedUrlPart = null) {
    const el = await this.driver.wait(until.elementLocated(locator), 5000);
    await this.driver.wait(async () => {
      const isDisplayed = await el.isDisplayed();
      const isEnabled = await el.isEnabled();
      return isDisplayed && isEnabled;
    }, 5000);

    await el.click();
    if (expectedUrlPart) {
      await this.driver.wait(until.urlContains(expectedUrlPart), 5000);
    }
  }

  // --------- Métodos para detalhes da conta ---------
  getNomeConta() {
    return this.getText(this.contaNomeDisplay);
  }

  getTipoConta() {
    return this.getText(this.tipoContaDisplay);
  }

  getUsuarioConta() {
    return this.getText(this.usuarioContaDisplay);
  }

  getDataCriacao() {
    return this.getText(this.dataCriacaoDisplay);
  }

  getSaldoAtual() {
    // Retorna o WebElement para poder chamar getText() e getCssValue() depois
    return this.driver.findElement(this.saldoAtualDisplay);
  }

  getSaldoColor() {
    return this.getColor(this.saldoAtualDisplay);
  }

  // --------- Métodos para movimentações e paginação ---------

  async getMovementRows() {
    await this.driver.wait(until.elementLocated(this.movementTableRows), 5000);
    return this.driver.findElements(this.movementTableRows);
  }

  async getPaginationLinks() {
    await this.driver.wait(until.elementLocated(this.paginationLinks), 5000);
    // Filtra apenas os links que contêm números de página (ignora 'Anterior' e 'Próximo')
    const allLinks = await this.driver.findElements(this.paginationLinks);
    const numericLinks = [];
    for (let link of allLinks) {
        const text = await link.getText();
        if (!isNaN(parseInt(text)) && text.trim() !== '') { // Verifica se é um número válido
            numericLinks.push(link);
        }
    }
    return numericLinks;
  }

  async clickPage(pageNumber) {
    const pageLink = By.xpath(`//li[contains(@class, 'page-item')]//a[text()='${pageNumber}']`);
    await this.click(pageLink, `page=${pageNumber}`);
  }

  async getPreviousButton() {
    try {
        const button = await this.driver.wait(until.elementLocated(this.previousPageButton), 5000);
        // Verifica se o botão está realmente visível e habilitado (se a lista pai não tem 'disabled')
        const parentLi = await button.findElement(By.xpath('..')); // Parent li element
        const isDisabled = await parentLi.getAttribute('class');
        if (isDisabled.includes('disabled')) {
            return null; // Retorna null se estiver desabilitado, como esperado pelo teste
        }
        return button;
    } catch (error) {
        // Se o elemento não for encontrado após o wait, ele pode não existir (ex: apenas 1 página)
        if (error.name === 'TimeoutError' || error.name === 'NoSuchElementError') {
            return null;
        }
        throw error; // Re-lança outros erros
    }
  }

  async getNextButton() {
    try {
        const button = await this.driver.wait(until.elementLocated(this.nextPageButton), 5000);
        const parentLi = await button.findElement(By.xpath('..'));
        const isDisabled = await parentLi.getAttribute('class');
        if (isDisabled.includes('disabled')) {
            return null;
        }
        return button;
    } catch (error) {
        if (error.name === 'TimeoutError' || error.name === 'NoSuchElementError') {
            return null;
        }
        throw error;
    }
  }

  async isPaginationButtonDisabled(buttonElement) {
    if (!buttonElement) return true; // Se o elemento não foi encontrado, considere desabilitado
    const parentLi = await buttonElement.findElement(By.xpath('..'));
    const classAttribute = await parentLi.getAttribute('class');
    return classAttribute.includes('disabled');
  }

  // --------- Botões principais da página de detalhes (voltar, editar, nova movimentação) ---------

  // NOVO MÉTODO: Retorna o WebElement do botão "Voltar para Contas"
  async getVoltarParaContasButton() {
    return this.driver.wait(until.elementLocated(this.btnVoltar), 5000, 'Botão "Voltar para Contas" não encontrado.');
  }

  // O método de clique já usa o locator atualizado
  clickVoltarParaContas() {
    return this.click(this.btnVoltar, '/contas'); // '/contas' ou '/contas/listar'
  }

  clickEditarConta(contaId) { // Adicionado contaId se o URL precisar
    return this.click(this.btnEditarConta, `/contas/editar/${contaId}`);
  }

  clickNovaMovimentacao() {
    return this.click(this.btnNovaMovimentacao, '/movimentacao');
  }
}