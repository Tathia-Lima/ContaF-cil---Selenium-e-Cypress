// support/page_objects/CadastroPage.js
import { By, until } from 'selenium-webdriver';

class CadastroPage {
    constructor(driver, baseUrl) {
        this.driver = driver;
        this.baseUrl = baseUrl;
        this.url = `${baseUrl}/cadastro`;

        // Selectors existentes
        this.nameInput = By.name('nome');
        this.emailInput = By.name('email');
        this.passwordInput = By.name('senha');
        this.submitButton = By.css('button[type="submit"]');
        this.togglePasswordButton = By.id('togglePassword');
        this.alertMessage = By.css('.alert'); // Selector para mensagens de alerta/flash

        // **** NOVOS SELECTORS PARA ACESSIBILIDADE ****
        // Critérios de senha (IDs dos <li> dentro da <ul>)
        this.passwordLengthCriteria = By.id('length');
        this.passwordLetterCriteria = By.id('letter');
        this.passwordNumberCriteria = By.id('number');
        this.passwordSpecialCriteria = By.id('special');
        // Link "Já tem conta? Faça login"
        this.loginLink = By.xpath("//a[contains(text(), 'Já tem conta? Faça login')]");
        // Elemento <main>
        this.mainElement = By.css('main');
    }

    async visit() {
        await this.driver.get(this.url);
        // Espera por um elemento chave para garantir que a página carregou
        await this.driver.wait(until.elementLocated(this.submitButton), 10000, 'Página de cadastro não carregou.');
    }

    async fillName(name) {
        await this.driver.findElement(this.nameInput).sendKeys(name);
    }

    async fillEmail(email) {
        await this.driver.findElement(this.emailInput).sendKeys(email);
    }

    async fillPassword(password) {
        await this.driver.findElement(this.passwordInput).sendKeys(password);
    }

    async submit() {
        await this.driver.findElement(this.submitButton).click();
    }

    async register(name, email, password) {
        await this.fillName(name);
        await this.fillEmail(email);
        await this.fillPassword(password);
        await this.submit();
    }

    async getAlertMessageText() {
        try {
            const alertElement = await this.driver.wait(until.elementLocated(this.alertMessage), 5000, 'Elemento de mensagem de alerta não encontrado.');
            await this.driver.wait(until.elementIsVisible(alertElement), 2000, 'Elemento de mensagem de alerta não visível.');
            return await alertElement.getText();
        } catch (error) {
            console.warn(`Não foi possível obter o texto da mensagem de alerta: ${error.message}`);
            return '';
        }
    }

    // Métodos para obter elementos de input
    async getNameInput() { return await this.driver.findElement(this.nameInput); }
    async getEmailInput() { return await this.driver.findElement(this.emailInput); }
    async getPasswordInput() { return await this.driver.findElement(this.passwordInput); }
    async getSubmitButton() { return await this.driver.findElement(this.submitButton); }
    async getTogglePasswordButton() { return await this.driver.findElement(this.togglePasswordButton); }

    // **** NOVOS MÉTODOS PARA ACESSIBILIDADE (AGORA INCLUÍDOS) ****
    async getPasswordLengthCriteria() { return await this.driver.findElement(this.passwordLengthCriteria); }
    async getPasswordLetterCriteria() { return await this.driver.findElement(this.passwordLetterCriteria); }
    async getPasswordNumberCriteria() { return await this.driver.findElement(this.passwordNumberCriteria); }
    async getPasswordSpecialCriteria() { return await this.driver.findElement(this.passwordSpecialCriteria); }
    async getLoginLink() { return await this.driver.findElement(this.loginLink); }
    async getMainElements() { return await this.driver.findElements(this.mainElement); } // Retorna todos os elementos <main>
}

export default CadastroPage;
