// support/page_objects/ContaAdicionarPage.js
import { By, until } from 'selenium-webdriver';

class ContaAdicionarPage {
  constructor(driver, baseUrl) {
    this.driver = driver;
    this.baseUrl = baseUrl;
    this.url = `${baseUrl}/contas/adicionar`;

    // Seletores FUNCIONAIS
    this.pageTitle = By.css('h2');
    this.form = By.css('form');
    this.csrfTokenInput = By.name('csrf_token');
    this.nomeLabel = By.css('label[for="nome"]');
    this.nomeInput = By.id('nome');
    this.salvarButton = By.css('button[type="submit"]');
    this.cancelarLink = By.css('a.btn-secondary');
    this.flashMessage = By.css('.alert'); // Seletor genérico para qualquer alerta

    // Seletores de ACESSIBILIDADE
    this.mainElement = By.css('main'); // Para o teste 139
    this.navBrand = By.css('a.brand'); // Para o teste 145 (seletor da navbar)
    this.navHomeLink = By.css('a[href="/home"]'); // Para o teste 145 (seletor da navbar)
    this.navContasDropdown = By.css('button.dropdown-toggle'); // Para o teste 145 (seletor da navbar)
    this.navContasAdicionarLink = By.css('a[href="/contas/adicionar"]'); // Para o teste 145 (seletor da navbar)
    this.navContasListarLink = By.css('a[href="/contas"]'); // Para o teste 145 (seletor da navbar)
    this.navCriarMovimentacaoLink = By.css('a[href="/movimentacao"]'); // Para o teste 145 (seletor da navbar)
    this.navResumoMensalLink = By.css('a[href="/resumo"]'); // Para o teste 145 (seletor da navbar)
    this.navSairLink = By.css('a[href="/logout"]'); // Para o teste 145 (seletor da navbar)
  }

  async visit() {
    await this.driver.get(this.url);
    await this.driver.wait(until.urlContains('/contas/adicionar'), 10000);
    await this.driver.wait(until.elementLocated(this.salvarButton), 5000); // Espera o botão Salvar aparecer
  }

  // Métodos FUNCIONAIS
  async getPageTitleText() {
    const h2 = await this.driver.findElement(this.pageTitle);
    return await h2.getText();
  }

  async getFormMethod() {
    const form = await this.driver.findElement(this.form);
    return await form.getAttribute('method');
  }

  async getCsrfTokenInput() {
    await this.driver.wait(until.elementLocated(this.csrfTokenInput), 5000, 'Campo CSRF Token não localizado.');
    return await this.driver.findElement(this.csrfTokenInput);
  }

  async getNomeLabelText() {
    const label = await this.driver.findElement(this.nomeLabel);
    return await label.getText();
  }

  async getNomeInputName() {
    const input = await this.driver.findElement(this.nomeInput);
    return await input.getAttribute('name');
  }

  async typeNome(nome) {
    const input = await this.driver.findElement(this.nomeInput);
    await input.clear();
    await input.sendKeys(nome);
  }

  async getNomeInputValue() {
    const input = await this.driver.findElement(this.nomeInput);
    return await input.getAttribute('value');
  }

  async getSalvarButton() {
    return await this.driver.findElement(this.salvarButton);
  }

  async clickSalvar() {
    await this.driver.findElement(this.salvarButton).click();
  }

  async getCancelarLink() {
    return await this.driver.findElement(this.cancelarLink);
  }

  async clickCancelar() {
    await this.driver.findElement(this.cancelarLink).click();
    await this.driver.wait(until.urlContains('/home'), 10000);
  }

  async getFlashMessageText() {
    await this.driver.wait(until.elementLocated(this.flashMessage), 5000);
    const message = await this.driver.findElement(this.flashMessage);
    return await message.getText();
  }

  async isFlashMessageVisible() {
    const message = await this.driver.findElement(this.flashMessage);
    return await message.isDisplayed();
  }

  // Método para o teste de CSRF (ajustado para Selenium)
  async submitFormWithoutCsrf(nome) {
    await this.typeNome(nome);
    await this.driver.executeScript(`
      var csrfInput = document.querySelector('input[name="csrf_token"]');
      if (csrfInput) {
        csrfInput.remove();
      }
    `);
    await this.clickSalvar();
    await this.driver.wait(until.elementLocated(this.flashMessage), 5000);
    return await this.getFlashMessageText();
  }

  // Métodos de ACESSIBILIDADE (reintegrados)
  async getMainElements() {
    return await this.driver.findElements(this.mainElement);
  }

  async getNomeInput() {
    return await this.driver.findElement(this.nomeInput);
  }

  async getNavBrand() {
    return await this.driver.findElement(this.navBrand);
  }

  async getNavHomeLink() {
    return await this.driver.findElement(this.navHomeLink);
  }

  async getNavContasDropdown() {
    return await this.driver.findElement(this.navContasDropdown);
  }

  async getNavContasAdicionarLink() {
    return await this.driver.findElement(this.navContasAdicionarLink);
  }

  async getNavContasListarLink() {
    return await this.driver.findElement(this.navContasListarLink);
  }

  async getNavCriarMovimentacaoLink() {
    return await this.driver.findElement(this.navCriarMovimentacaoLink);
  }

  async getNavResumoMensalLink() {
    return await this.driver.findElement(this.navResumoMensalLink);
  }

  async getNavSairLink() {
    return await this.driver.findElement(this.navSairLink);
  }

  async getSubmitButton() { // Alias para getSalvarButton para consistência
    return await this.driver.findElement(this.salvarButton);
  }
}

export default ContaAdicionarPage;
