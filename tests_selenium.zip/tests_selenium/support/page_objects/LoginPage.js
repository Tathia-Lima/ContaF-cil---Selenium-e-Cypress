// support/page_objects/LoginPage.js

import { By, until } from 'selenium-webdriver';

class LoginPage {
    constructor(driver, baseUrl) {
        this.driver = driver;
        this.baseUrl = baseUrl;
        this.emailInput = By.name('email');
        this.passwordInput = By.name('senha');
        this.submitButton = By.css('button[type="submit"]');
        this.alertMessage = By.css('.alert'); // Seletor para mensagens flash
    }

    /**
     * Navega para a página de login.
     */
    async visit() {
        await this.driver.get(`${this.baseUrl}/login`);
        // Espera que o campo de email esteja visível para garantir que a página carregou
        await this.driver.wait(until.elementLocated(this.emailInput), 10000);
    }

    /**
     * Preenche o campo de email.
     * @param {string} email
     */
    async fillEmail(email) {
        const emailElement = await this.driver.findElement(this.emailInput);
        await emailElement.clear();
        await emailElement.sendKeys(email);
    }

    /**
     * Preenche o campo de senha.
     * @param {string} password
     */
    async fillPassword(password) {
        const passwordElement = await this.driver.findElement(this.passwordInput);
        await passwordElement.clear();
        await passwordElement.sendKeys(password);
    }

    /**
     * Clica no botão de submissão.
     */
    async submit() {
        await this.driver.findElement(this.submitButton).click();
    }

    /**
     * Realiza o processo completo de login.
     * @param {string} email
     * @param {string} password
     */
    async login(email, password) {
        await this.visit();
        await this.fillEmail(email);
        await this.fillPassword(password);
        await this.submit();
    }

    /**
     * Obtém o texto de uma mensagem de alerta flash.
     * @returns {Promise<string>} O texto da mensagem de alerta.
     */
    async getAlertMessageText() {
        try {
            const alertElement = await this.driver.wait(until.elementLocated(this.alertMessage), 5000);
            return await alertElement.getText();
        } catch (error) {
            // Se o elemento não for encontrado dentro do tempo limite, significa que não há alerta visível
            return '';
        }
    }

    /**
     * Obtém o elemento input de email.
     * @returns {Promise<WebElement>}
     */
    async getEmailInput() {
        return await this.driver.findElement(this.emailInput);
    }

    /**
     * Obtém o elemento input de senha.
     * @returns {Promise<WebElement>}
     */
    async getPasswordInput() {
        return await this.driver.findElement(this.passwordInput);
    }

    /**
     * Obtém o elemento do botão de submissão.
     * @returns {Promise<WebElement>}
     */
    async getSubmitButton() {
        return await this.driver.findElement(this.submitButton);
    }
}

export default LoginPage;
