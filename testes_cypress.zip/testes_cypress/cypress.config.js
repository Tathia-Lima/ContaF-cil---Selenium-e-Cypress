const { defineConfig } = require('cypress')

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost:5000',
    viewportWidth: 1280,
    viewportHeight: 720,
    defaultCommandTimeout: 5000,
    requestTimeout: 10000,
    responseTimeout: 10000,
    video: true,
    screenshotOnRunFailure: true,
    trashAssetsBeforeRuns: true,

    setupNodeEvents(on, config) {
      // Listener para imprimir mensagens no terminal (usado no cy.task('log', ...))
      on('task', {
        log(message) {
          console.log(message)
          return null
        },
      })

      return config
    },
  },
})
