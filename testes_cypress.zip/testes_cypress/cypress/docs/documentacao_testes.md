# Documentação dos Testes Cypress para a Aplicação ContaFacil

## Introdução

Este documento descreve os testes automatizados desenvolvidos com Cypress para a aplicação ContaFacil. Os testes foram criados para validar o funcionamento, aparência e segurança da aplicação, com foco especial na página de login e na página inicial (dashboard).

## Estrutura dos Testes

Os testes estão organizados em vários arquivos, cada um focando em um aspecto específico da aplicação:

1. **login.cy.js** - Testes para a página de login
2. **home.cy.js** - Testes para a página inicial (dashboard)
3. **visual.cy.js** - Testes para validação visual e de cores
4. **security.cy.js** - Testes para validação de segurança
5. **accessibility.cy.js** - Testes para validação de acessibilidade
6. **forms.cy.js** - Testes para validação de formulários
7. **navigation.cy.js** - Testes para validação de navegação

## Testes da Página de Login

### Verificação de Elementos e Textos
- Validação do título da página
- Verificação da presença do logo
- Verificação dos campos do formulário de login
- Verificação do link para cadastro

### Verificação de Cores e Estilos
- Validação da cor de fundo da página
- Validação da cor do título
- Validação das cores do botão de login
- Validação das cores dos campos de input
- Validação das cores dos labels e links

### Funcionalidade de Login
- Teste de login com campos vazios
- Teste de login com email inválido
- Teste de login com email inexistente
- Teste de login com senha incorreta
- Teste de login com credenciais válidas

### Validação de Formulário
- Validação do formato de email
- Validação do comprimento mínimo da senha

### Acessibilidade e Usabilidade
- Verificação do foco inicial no campo de email
- Navegação por teclado entre os campos
- Funcionalidade de mostrar/ocultar senha

### Segurança
- Limitação de tentativas de login após falhas consecutivas
- Verificação de armazenamento seguro de credenciais

### Responsividade
- Testes em diferentes tamanhos de tela (celular, tablet, desktop)

## Testes da Página Inicial (Dashboard)

### Verificação de Elementos e Textos
- Validação do título da página
- Verificação do nome do usuário logado
- Verificação do menu de navegação
- Verificação do resumo financeiro
- Verificação do botão de nova transação

### Verificação de Cores e Estilos
- Validação da cor de fundo da página
- Validação da cor do cabeçalho
- Validação das cores dos cards de resumo
- Validação das cores dos botões de ação

### Funcionalidade do Dashboard
- Verificação do saldo atual
- Verificação do total de receitas e despesas
- Verificação da lista de transações recentes
- Teste de filtro de transações por período

### Navegação no Dashboard
- Navegação para a página de contas
- Navegação para a página de categorias
- Navegação para a página de relatórios
- Abertura do modal de nova transação

### Responsividade
- Testes em diferentes tamanhos de tela
- Verificação do menu móvel em telas pequenas

### Interação com Dados
- Adição de nova receita
- Adição de nova despesa
- Edição de transação existente
- Exclusão de transação existente

### Filtros e Ordenação
- Filtro de transações por categoria
- Filtro de transações por conta
- Ordenação de transações por data
- Ordenação de transações por valor

### Gráficos e Visualizações
- Verificação do gráfico de despesas por categoria
- Verificação do gráfico de evolução do saldo
- Atualização dos gráficos ao mudar o período

### Segurança e Sessão
- Teste de logout
- Verificação de acesso não autorizado

## Testes Adicionais

### Validação Visual
- Validação das cores principais da aplicação
- Verificação da consistência visual entre páginas
- Testes de responsividade em diferentes dispositivos

### Validação de Segurança
- Testes contra SQL Injection
- Testes contra XSS (Cross-Site Scripting)
- Verificação de proteção de rotas

### Validação de Acessibilidade
- Verificação de labels associados aos campos
- Testes de navegação por teclado
- Verificação de contraste adequado
- Verificação de textos alternativos para imagens
- Verificação de mensagens de erro acessíveis

### Validação de Formulários
- Validação de campos vazios
- Validação de formato de email
- Validação de senhas diferentes no cadastro
- Validação de campos obrigatórios em transações

### Validação de Navegação
- Navegação entre páginas de login e cadastro
- Redirecionamento após login e logout
- Navegação dentro do dashboard
- Navegação em dispositivos móveis

## Como Executar os Testes

Para executar os testes, siga os passos abaixo:

1. Certifique-se de que a aplicação ContaFacil está em execução na porta 5000
2. Abra um terminal na pasta raiz do projeto
3. Execute o comando para rodar todos os testes:
   ```
   npx cypress run
   ```
4. Para executar um arquivo de teste específico:
   ```
   npx cypress run --spec "cypress/e2e/login.cy.js"
   ```
5. Para abrir o Cypress em modo interativo:
   ```
   npx cypress open
   ```

## Considerações Finais

Os testes foram desenvolvidos para cobrir os principais aspectos da aplicação ContaFacil, com foco especial na página de login e na página inicial. Alguns testes podem falhar se a aplicação não estiver configurada corretamente ou se não houver dados de teste adequados.

Para melhorar a confiabilidade dos testes, é recomendável:

1. Criar um banco de dados de teste com dados conhecidos
2. Implementar comandos personalizados do Cypress para tarefas comuns
3. Configurar variáveis de ambiente para diferentes ambientes de teste
4. Implementar hooks para limpar o estado entre os testes

Estes testes devem ser mantidos e atualizados conforme a aplicação evolui para garantir que novas funcionalidades não quebrem as existentes.

