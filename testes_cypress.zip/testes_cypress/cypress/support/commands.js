// Comandos personalizados do Cypress
// cypress/support/commands.js

// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************

// Comando para fazer login
Cypress.Commands.add('login', (email, senha) => {
  cy.visit('/login');
  cy.get('input[placeholder="Email"]').type(email);
  cy.get('input[placeholder="Senha"]').type(senha);
  cy.get('button').contains('Entrar').click();
});

// Comando para verificar mensagem de alerta
Cypress.Commands.add('checkAlert', (message) => {
  cy.get('.alert').should('be.visible').and('contain', message);
});

// Comando para adicionar nova transação
Cypress.Commands.add('addTransaction', (type, description, value, category, account, date) => {
  cy.get('button').contains('Nova Transação').click();
  cy.get('.modal').should('be.visible');
  
  // Selecionar tipo
  if (type === 'receita') {
    cy.get('input[name="tipo"][value="receita"]').check();
  } else if (type === 'despesa') {
    cy.get('input[name="tipo"][value="despesa"]').check();
  }
  
  // Preencher formulário
  cy.get('input[name="descricao"]').type(description);
  cy.get('input[name="valor"]').type(value);
  cy.get('select[name="categoria"]').select(category);
  cy.get('select[name="conta"]').select(account);
  cy.get('input[name="data"]').type(date);
  
  // Salvar
  cy.get('button').contains('Salvar').click();
});

// Comando para verificar cores
Cypress.Commands.add('checkColor', (selector, property, expectedColor) => {
  cy.get(selector).should('have.css', property, expectedColor);
});

// Comando para verificar responsividade
Cypress.Commands.add('checkResponsiveness', (selector) => {
  // Verificar em mobile
  cy.viewport('iphone-x');
  cy.get(selector).should('be.visible');
  
  // Verificar em tablet
  cy.viewport('ipad-2');
  cy.get(selector).should('be.visible');
  
  // Verificar em desktop
  cy.viewport(1920, 1080);
  cy.get(selector).should('be.visible');
});

