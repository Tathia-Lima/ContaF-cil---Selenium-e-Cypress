// cypress/support/e2e.js

import './commands'
import 'cypress-plugin-tab'
import 'cypress-axe';  // Importa comandos do axe-core
import 'cypress-real-events/support';
const moment = require('moment');

Cypress.on('uncaught:exception', (err, runnable) => {
  return false
})

Cypress.moment = moment;
const momentTimezone = require('moment-timezone');
momentTimezone.tz.setDefault('America/Sao_Paulo'); // Exemplo de fuso horário padrão
Cypress.momentTimezone = momentTimezone;

Cypress.Commands.add('checkContrast', (foregroundSelector, backgroundSelector) => {
  cy.get(foregroundSelector).then($foreground => {
    const foregroundColor = window.getComputedStyle($foreground[0]).color;
    cy.get(backgroundSelector).then($background => {
      const backgroundColor = window.getComputedStyle($background[0]).backgroundColor;
      cy.log(`Verificando contraste entre ${foregroundColor} e ${backgroundColor}`);
    });
  });
});

Cypress.Commands.add('injectAxeIfNotInjected', () => {
  cy.window({ log: false }).then((win) => {
    if (!win.axe) {
      cy.injectAxe(); // Injeta o axe-core na página
    }
  });
});