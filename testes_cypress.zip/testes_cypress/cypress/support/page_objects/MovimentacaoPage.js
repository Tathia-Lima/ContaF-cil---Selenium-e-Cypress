// cypress/support/page_objects/MovimentacaoPage.js

class MovimentacaoPage {
  static visitar() {
    cy.visit('/movimentacao');
  }

  static preencherDescricao(descricao) {
    cy.get('input[name="descricao"]').type(descricao);
  }

  static preencherValor(valor) {
    cy.get('input[name="valor"]').type(valor);
  }

  static selecionarTipo(tipo) {
    cy.get('select[name="tipo"]').select(tipo);
  }

  static preencherDataMovimentacao(data) {
    cy.get('input[name="data_movimentacao"]').type(data);
  }

  static preencherDataPagamento(data) {
    cy.get('input[name="data_pagamento"]').type(data);
  }

  static preencherInteressado(interessado) {
    cy.get('input[name="interessado"]').type(interessado);
  }

  static selecionarConta(conta) {
    cy.get('select[name="conta_id"]').select(conta);
  }

  static selecionarSituacao(situacao) {
    cy.get(`input[name="situacao"][value="${situacao}"]`).check();
  }

  static submeter() {
    cy.get('button[type="submit"]').click();
  }

  static validarMensagem(mensagem) {
    cy.contains(mensagem).should('be.visible');
  }

  static setupClockBasedOnServerDate() {
    return cy.get('body').then(($body) => {
      const serverDateInput = $body.find('#server-date');
      if (serverDateInput.length) {
        const serverDateString = serverDateInput.val();
        cy.log(`DEBUG: Valor lido do input #server-date: "${serverDateString}"`);

        if (serverDateString) {
          const serverDate = Cypress.moment.utc(serverDateString).toDate();
          
          if (isNaN(serverDate.getTime())) {
            cy.log(`DEBUG: Data do servidor inválida: "${serverDateString}". Não foi possível setar o clock.`);
          } else {
            // MODIFICAÇÃO AQUI: Captura o objeto clock e armazena-o em Cypress.env
            cy.clock(serverDate.getTime()).then((clock) => {
              Cypress.env('currentClock', clock); // Armazena o objeto clock
              cy.log(`DEBUG: Cypress clock set to server date: ${serverDateString}`);
            });
          }
        } else {
          cy.log('DEBUG: Input #server-date encontrado, mas valor está vazio. Clock não setado.');
        }
      } else {
        cy.log('DEBUG: Input #server-date NÃO encontrado no DOM. Clock não setado.');
      }
    });
  }

  static restoreClock() {
    cy.log('DEBUG: Tentando restaurar o clock...');
    // MODIFICAÇÃO AQUI: Recupera o objeto clock armazenado
    const currentClock = Cypress.env('currentClock');

    if (currentClock && typeof currentClock.restore === 'function') {
      currentClock.restore(); // Chama restore no objeto clock capturado
      cy.log('DEBUG: Clock restaurado.');
      Cypress.env('currentClock', null); // Limpa a referência após restaurar
    } else {
      cy.log('DEBUG: Nenhum clock ativo para restaurar ou objeto inválido. (Isso é esperado se o clock não foi setado no setup)');
    }
  }
}
export default MovimentacaoPage;
