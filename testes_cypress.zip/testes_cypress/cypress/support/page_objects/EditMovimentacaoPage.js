class EditMovimentacaoPage {
  visit(movimentacaoId) {
    cy.visit(`/movimentacao/editar/${movimentacaoId}`);
  }

  getTipo() {
    return cy.get('select[name="tipo"]');
  }

  getValor() {
    return cy.get('input[name="valor"]');
  }

  getDataMovimentacao() {
    return cy.get('input[name="data_movimentacao"]');
  }

  getDataPagamento() {
    return cy.get('input[name="data_pagamento"]');
  }

  getDescricao() {
    return cy.get('input[name="descricao"]');
  }

  getInteressado() {
    return cy.get('input[name="interessado"]');
  }

  getContaId() {
    return cy.get('select[name="conta_id"]');
  }

  getSituacao(situacao) {
    return cy.get(`input[name="situacao"][value="${situacao}"]`);
  }

  submit() {
    cy.get('button[type="submit"]').click();
  }

  cancelar() {
    cy.contains('Cancelar').click();
  }

  getAlerta() {
    return cy.get('.alert, .flash-message');
  }
}

export default new EditMovimentacaoPage();
