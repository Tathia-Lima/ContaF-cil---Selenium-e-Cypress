export function gerarSufixo(tamanho) {
  return Math.random().toString(36).substring(2, 2 + tamanho);
}