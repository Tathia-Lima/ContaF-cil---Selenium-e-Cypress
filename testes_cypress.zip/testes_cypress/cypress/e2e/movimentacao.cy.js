// cypress/e2e/movimentacao.cy.js
import MovimentacaoPage from '../support/page_objects/MovimentacaoPage';

describe('Criação de Movimentações - Testes Funcionais', () => {
  beforeEach(() => {
    cy.session('user-session', () => {
      cy.visit('/login');
      cy.get('input[name=email]').type('movimentacao@movimentacao.com');
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    MovimentacaoPage.visitar();

    MovimentacaoPage.setupClockBasedOnServerDate();
  });

  it('173 - Deve exibir todos os campos obrigatórios', () => {
    cy.get('form').within(() => {
      cy.get('select[name="tipo"]').should('exist');
      cy.get('input[name="data_movimentacao"]').should('exist');
      cy.get('input[name="data_pagamento"]').should('exist');
      cy.get('input[name="descricao"]').should('exist');
      cy.get('input[name="interessado"]').should('exist');
      cy.get('input[name="valor"]').should('exist');
      cy.get('select[name="conta_id"]').should('exist');
      cy.get('input[name="situacao"][value="pago"]').should('exist');
      cy.get('input[name="situacao"][value="pendente"]').should('exist');
    });
  });

  it('174 -Deve validar que o campo "Tipo da Movimentação" é obrigatório', () => {
    // Preenche tudo, exceto o campo tipo
    cy.get('select[name="tipo"]').select(''); // limpar seleção
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1); // ajusta de acordo com as contas
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Selecione o tipo de movimentação.').should('be.visible');
  });

  it('175 - Deve validar que o campo "Data da Movimentação" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').clear();
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Informe a data da movimentação.').should('be.visible');
  });

  it('176 - Deve validar que o campo "Data do Pagamento" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').clear();;
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Informe a data de pagamento.').should('be.visible');
  });

  it('177 - Deve validar que o campo "Descrição" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').clear();
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Descrição é obrigatória.').should('be.visible');
  });

  it('178 - Deve validar que o campo "Valor" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').clear();
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Informe um valor.').should('be.visible');
  });

  it('179 -Deve validar que o campo "Conta" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select('0');  // valor da opção "Selecione uma conta"
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Você precisa selecionar uma conta.').should('be.visible');
  });

  it('180 - Deve validar que o campo "Situação" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('despesa');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(2);
    cy.get('button[type="submit"]').click();
    cy.contains('Selecione a situação da movimentação.').should('be.visible');
  });

  it('181 - Deve validar valor não numérico', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-19');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente A');
    cy.get('input[name="valor"]').clear().type('abc'); // <-- AJUSTE AQUI: Passando uma string não numérica
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Valor inválido.');
  });

  it('182 - Deve criar receita com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente A');
    MovimentacaoPage.preencherValor(250.75);
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('183 - Deve manter valores preenchidos após erro de validação', () => {
    MovimentacaoPage.preencherDescricao('Teste erro');
    MovimentacaoPage.submeter();
    cy.get('input[name="descricao"]').should('have.value', 'Teste erro');
  });

  it('184 -Deve aceitar valor mínimo 0.01', () => {
    MovimentacaoPage.preencherDescricao('Teste valor limite mínimo');
    MovimentacaoPage.preencherValor(0.01);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('185 -Deve rejeitar valor menor que 0.01', () => {
    MovimentacaoPage.preencherDescricao('Teste valor abaixo do mínimo');
    MovimentacaoPage.preencherValor(0.009);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-21');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.selecionarSituacao('pago');
    cy.get('form').submit();
    cy.contains('O valor deve ser maior ou igual a 0.01.').should('exist');
  });

  it('186 - Deve impedir valor zero', () => {
  MovimentacaoPage.preencherDescricao('Teste valor abaixo do mínimo');
  MovimentacaoPage.preencherValor(0);
  MovimentacaoPage.selecionarConta('Conta 1');
  MovimentacaoPage.selecionarTipo('receita');
  MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
  MovimentacaoPage.preencherDataPagamento('2025-06-20');
  MovimentacaoPage.selecionarSituacao('pago');
  cy.get('form').submit();
  cy.contains('O valor deve ser maior ou igual a 0.01.').should('exist');
  });

  it('187 - Deve permitir descrição com caracteres especiais', () => {
    const descricao = '!%&@#()[]{} - Teste com tudo';
    MovimentacaoPage.preencherDescricao(descricao);
    MovimentacaoPage.preencherValor(50);
    MovimentacaoPage.preencherDataMovimentacao('2025-06-19');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('188 - Deve permitir campo "Interessado" opcional (vazio)', () => {
// Captura a data do servidor
  cy.get('#server-date').invoke('val').then((serverDate) => {
    // Preenche o formulário com a data dinâmica
    MovimentacaoPage.preencherDescricao('Sem interessado');
    MovimentacaoPage.preencherValor(300);
    MovimentacaoPage.preencherDataMovimentacao(serverDate);
    MovimentacaoPage.preencherDataPagamento(serverDate);
    MovimentacaoPage.selecionarConta('Conta 4');
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();

    cy.url().should('include', '/resumo');
    cy.contains('Despesa incluída com sucesso!').should('exist');
  });
});

  it('189 - Deve validar que data de pagamento não pode ser anterior à movimentação', () => {
    MovimentacaoPage.preencherDescricao('Data inconsistente');
    MovimentacaoPage.preencherValor(120);
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-19');
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento.');
  });

  it('190 - Não deve ter nenhuma opção de "Situação" selecionada por padrão', () => {
    cy.get('input[name="situacao"][value="pago"]').should('not.be.checked');
    cy.get('input[name="situacao"][value="pendente"]').should('not.be.checked');
  });

  it('191 - Deve manter "pendente" marcado ao submeter e falhar', () => {
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.get('input[name="situacao"][value="pendente"]').should('be.checked');
  });

  it('192 - Deve permitir descrição com até 30 caracteres', () => {
    const descricao30Chars = 'A'.repeat(30);
    const dataMovimentacao = '2025-06-20'; // Data da movimentação
    const dataPagamento = '2025-06-20';

    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao(dataMovimentacao);
    MovimentacaoPage.preencherDataPagamento(dataPagamento);
    MovimentacaoPage.preencherDescricao(descricao30Chars);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();

    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');

    // --- NOVO: Interagir com o filtro da página de resumo ---
    // Extrai o mês e o ano da data da movimentação
    const [ano, mes, dia] = dataMovimentacao.split('-');

    // Seleciona o mês e o ano corretos no filtro
    cy.get('select[name="mes"]').select(parseInt(mes).toString()); // Converte para int e depois para string
    cy.get('select[name="ano"]').select(ano);

    // Clica no botão "Buscar"
    cy.get('button[type="submit"]').contains('Buscar').click();

    // Verifica se a descrição inserida aparece na tabela filtrada
    cy.contains(descricao30Chars).should('exist');
  });

  it('193 - Não deve permitir descrição com 31 caracteres', () => {
    const descricao31Chars = 'A'.repeat(31);
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao(descricao31Chars);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Descrição deve ter no máximo 30 caracteres.');
    cy.url().should('include', '/movimentacao'); // Deve permanecer na página de formulário
  });

  it('194 - Deve permitir descrição com 29 caracteres', () => {
const descricao30Chars = 'A'.repeat(29);
    const dataMovimentacao = '2025-06-20'; // Data da movimentação
    const dataPagamento = '2025-06-20';

    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao(dataMovimentacao);
    MovimentacaoPage.preencherDataPagamento(dataPagamento);
    MovimentacaoPage.preencherDescricao(descricao30Chars);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();

    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');

    // --- NOVO: Interagir com o filtro da página de resumo ---
    // Extrai o mês e o ano da data da movimentação
    const [ano, mes, dia] = dataMovimentacao.split('-');

    // Seleciona o mês e o ano corretos no filtro
    cy.get('select[name="mes"]').select(parseInt(mes).toString()); // Converte para int e depois para string
    cy.get('select[name="ano"]').select(ano);

    // Clica no botão "Buscar"
    cy.get('button[type="submit"]').contains('Buscar').click();

    // Verifica se a descrição inserida aparece na tabela filtrada
    cy.contains(descricao30Chars).should('exist');
  });

  it('195 - Deve redirecionar para Home ao clicar em Cancelar', () => {
    cy.get('a.btn-secondary')
      .should('contain.text', 'Cancelar')
      .click();
    cy.url().should('include', '/home');
  });

  it('196 - Deve exibir erro ao criar movimentação sem conta cadastrada', () => {
    cy.session('user-sem-conta', () => {
      cy.visit('/login');
      cy.get('input[name=email]').type('semconta@teste.com');  // usuário sem conta
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    cy.visit('/movimentacao');
    // Preenche todos os campos, exceto conta (não há nenhuma disponível)
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-21');
    MovimentacaoPage.preencherDescricao('Teste sem conta');
    MovimentacaoPage.preencherInteressado('Cliente B');
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    // Valida a mensagem de erro esperada
    MovimentacaoPage.validarMensagem('Você precisa cadastrar uma conta antes de criar movimentações.');
  });

  it('197 - Deve validar que para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento', () => {
      MovimentacaoPage.preencherDescricao('Data inconsistente');
      MovimentacaoPage.preencherValor(120);
      MovimentacaoPage.preencherDataMovimentacao('2025-06-20'); // Data de movimentação posterior
      MovimentacaoPage.preencherDataPagamento('2025-06-19'); // Data de pagamento anterior
      MovimentacaoPage.selecionarConta('Conta 1');
      MovimentacaoPage.selecionarTipo('receita');
      MovimentacaoPage.selecionarSituacao('pago');
      MovimentacaoPage.submeter();
      MovimentacaoPage.validarMensagem('Para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento.');
  });

  it('198 - Deve validar que para movimentações pagas, a data de pagamento não pode ser no futuro', () => {

    const tomorrow = Cypress.moment().add(1, 'days').format('YYYY-MM-DD'); 
    const today = Cypress.moment().format('YYYY-MM-DD'); 

    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao(today);
    MovimentacaoPage.preencherDataPagamento(tomorrow); // Data de pagamento no futuro
    MovimentacaoPage.preencherDescricao('Pagamento futuro');
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago'); // Situação 'pago'
    MovimentacaoPage.submeter();

    cy.contains('A data de pagamento deve estar entre').should('be.visible');
    cy.url().should('include', '/movimentacao');
  });

  it('199 - Deve validar que para movimentações pendentes, a data de pagamento não pode ser no passado', () => {
    // 'yesterday' e 'today' agora serão calculados com base na data do servidor
    const yesterday = Cypress.moment().subtract(1, 'days').format('YYYY-MM-DD'); 
    const today = Cypress.moment().format('YYYY-MM-DD'); 
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.preencherDataMovimentacao(today);
    MovimentacaoPage.preencherDataPagamento(yesterday); // Data de pagamento no passado
    MovimentacaoPage.preencherDescricao('Pagamento pendente no passado');
    MovimentacaoPage.preencherValor(50);
    MovimentacaoPage.selecionarConta('Conta 2');
    MovimentacaoPage.selecionarSituacao('pendente'); // Situação 'pendente'
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Para movimentações pendentes, a data de pagamento não pode ser no passado.');
  });

  it('200 - Deve prevenir XSS no campo Descrição (VERSÃO FINAL E ROBUSTA)', () => {
    const xssPayload = '<img src=x onerror=alert(1)>';
    const escapedXssPayload = '&lt;img src=x onerror=alert(1)&gt;';

    // --- ETAPA 1: Preparação ---
    cy.visit('/clean-xss-payloads');
    cy.url().should('include', '/resumo');
    cy.contains('Payloads XSS de teste removidos do banco de dados!').should('be.visible');

    // --- ETAPA 2: Ação ---
    MovimentacaoPage.visitar();
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-07-02');
    MovimentacaoPage.preencherDataPagamento('2025-07-02');
    MovimentacaoPage.preencherDescricao(xssPayload);
    MovimentacaoPage.preencherValor(100.99); // Valor único para facilitar a busca
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();

    // --- ETAPA 3: Validação ---
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('be.visible');

    // Asserção 1: O HTML da página inteira não deve conter a tag <img> executável.
    cy.get('body').invoke('html').should('not.include', xssPayload);

    // Asserção 2 (CORRIGIDA E ROBUSTA): Encontrar a linha pelo valor e validar o HTML da célula de descrição.
    cy.contains('td', '100,99') // Encontra a linha pelo valor, que é único
      .parent('tr')             // Seleciona a linha pai (tr)
      .within(() => {
        // Valida que o HTML INTERNO da primeira célula contém o payload ESCAPADO
        cy.get('td').eq(0).should('have.html', escapedXssPayload);

        // Valida que o TEXTO VISÍVEL da primeira célula contém o payload NÃO escapado
        cy.get('td').eq(0).should('have.text', xssPayload);
      });

    // Asserção 3: A mensagem de sucesso não deve conter o payload.
    cy.get('.alert-success').should('not.contain', xssPayload);
  });

  it('201 - Deve redirecionar para login se tentar acessar movimentacao após logout', () => {
    // Assume que o beforeEach já logou o usuário e visitou /movimentacao
    cy.visit('/logout'); // Ou clique no botão de logout
    cy.url().should('include', '/login'); // Redirecionou para login

    cy.visit('/movimentacao'); // Tenta acessar a página de movimentação diretamente
    cy.url().should('include', '/login'); // Deve ser redirecionado de volta para login
    cy.contains('Você precisa estar logado para acessar esta página.').should('be.visible'); // Se houver uma mensagem
  });
});
