import LoginPage from '../support/page_objects/loginPage';

describe('ContaFácil - Home', () => {
  beforeEach(() => {
    // Usa cy.session para manter login entre testes
    cy.session('sessao-pagina-inicial', () => {
      LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/home');
  });

  const redColor = 'rgb(244, 67, 54)';   // Cor para negative-value (#f44336)
  const greenColor = 'rgb(76, 175, 80)'; // Cor para positive-value (#4caf50)
  const defaultTextColor = 'rgb(255, 255, 255)'; // Cor padrão do texto da tabela (body color: #ffffff)

  // Validações principais de textos e hierarquia (65 - 75)
  it('65 - Deve conter título da aba correto', () => {
    cy.title().should('eq', 'ContaFácil - Home');
  });

  it('66 - Deve conter um h1 com texto exato', () => {
    cy.get('main h1').should('have.text', 'ContaFácil - Página Inicial');
  });

  it('67 - Deve conter h2 com saudação contendo o nome do usuário', () => {
    cy.get('main h2').invoke('text').should('match', /^Olá, .+! Seja bem-vindo\(a\) ao ContaFácil\.$/);
  });

  it('68 - Deve conter parágrafo explicativo com texto esperado', () => {
    cy.get('main p').should('have.text', 'Aqui você pode gerenciar facilmente suas finanças e acompanhar o saldo das suas contas.');
  });

  it('69 - Deve conter h3 com o texto "Saldo das suas contas"', () => {
    cy.get('main h3').should('have.text', 'Saldo das suas contas');
  });

  // Validações da tabela de contas (70 - 80)
  it('70 - A tabela deve ter a classe "table" e atributo aria-label correto', () => {
    cy.get('table.table').should('have.attr', 'aria-label', 'Tabela de saldos das contas do usuário');
  });

  it('71 - A tabela deve conter cabeçalhos "Conta", "Despesas", "Receitas" e "Saldo"', () => {
    cy.get('table thead th').eq(0).should('have.text', 'Conta');
    cy.get('table thead th').eq(1).should('have.text', 'Receitas');
    cy.get('table thead th').eq(2).should('have.text', 'Despesas');
    cy.get('table thead th').eq(3).should('have.text', 'Saldo');
  });

  it('72 - Cada linha de conta deve conter link com tabindex=0 e nome da conta não vazio', () => {
    cy.get('table tbody tr').each(($tr) => {
      const isSaldoTotal = $tr.hasClass('saldo-total');

      if (!isSaldoTotal) {
        cy.wrap($tr).find('td').then(($tds) => {
          if ($tds.length === 2 && !$tds.eq(0).attr('colspan')) {
            cy.wrap($tds.eq(0)).find('a')
              .should('have.attr', 'tabindex', '0')
              .and('not.be.empty');
          }
        });
      }
    });
  });

  it('73 - Os saldos devem estar no formato PT-BR, ex: R$ 1.234,56', () => {
    const saldoRegex = /^R\$ \d{1,3}(\.\d{3})*,\d{2}$/;
    cy.get('table tbody tr').each(($tr) => {
      cy.wrap($tr).find('td').eq(1).invoke('text').then((text) => {
        if (!text.includes('Nenhuma conta cadastrada')) {
          expect(text.trim()).to.match(saldoRegex);
        }
      });
    });
  });

  it('74 - Deve mostrar mensagem "Nenhuma conta cadastrada ainda." caso não haja contas', () => {
    cy.get('table tbody tr').then(($rows) => {
      if ($rows.length === 1) {
        cy.get('table tbody tr td[colspan="2"]').should('have.text', 'Nenhuma conta cadastrada ainda.');
      }
    });
  });

  // Acessibilidade e atributos (75 - 79)
  it('75 - Links dos nomes das contas devem ter tabindex=0', () => {
    // Seleciona apenas os links que são nomes de conta (o primeiro link em cada linha)
    cy.get('table tbody tr td:first-child a').each(($a) => {
      cy.wrap($a).should('have.attr', 'tabindex', '0');
    });
  });

  it('76 - Deve existir exatamente um elemento main na página', () => {
    cy.get('main').should('have.length', 1);
  });

  it('77 - Deve garantir hierarquia correta de títulos (h1, depois h2, depois h3)', () => {
    cy.get('main').within(() => {
      cy.get('h1').should('exist');
      cy.get('h2').should('exist');
      cy.get('h3').should('exist');
    });
  });

  it('78 - A tabela deve ter os cabeçalhos com scope="col"', () => {
    cy.get('table thead th').each(($th) => {
      cy.wrap($th).should('have.attr', 'scope', 'col');
    });
  });

  it('79 - A linha de saldo total deve estar estilizada em negrito', () => {
    cy.get('table tbody tr.saldo-total').should('have.css', 'font-weight').and((fontWeight) => {
      expect(['700', 'bold']).to.include(fontWeight);
    });
  });
});

describe('Validar usuario sem conta cadastradas', () => {
  beforeEach(() => {
    cy.session('sessao-usuario-sem-conta', () => {
      LoginPage.login('saltototal@saldotota.com', 'teste_12');
    });
    cy.visit('/home');
  });

  it('80 - Deve exibir linha de saldo total somente se houver contas, senão mensagem adequada', () => {
    cy.get('table tbody').then($tbody => {
      if ($tbody.find('tr.saldo-total').length > 0) {
        cy.get('table tbody tr.saldo-total').within(() => {
          cy.get('td').eq(0).should('have.text', 'Saldo Total');
          cy.get('td').eq(1).invoke('text').should('match', /^R\$ \d{1,3}(\.\d{3})*,\d{2}$/);
        });
      } else {
        cy.contains('Nenhuma conta cadastrada ainda.').should('be.visible');
      }
    });
  });
});

describe('Validar total do saldo da conta', () => {
  beforeEach(() => {
    cy.session('sessao-usuario-com-conta', () => {
      LoginPage.login('teste1@teste1.com', '123456');
    });
    cy.visit('/home');
  });

  it('81 - Deve exibir múltiplas contas e saldo total correto', () => {
    cy.get('table tbody tr.saldo-total').as('linhaTotal');

    cy.get('@linhaTotal').should('exist');

    cy.get('@linhaTotal').find('td').eq(0).should('contain', 'Total');

    cy.get('@linhaTotal').find('td').eq(3).invoke('text').then((texto) => {
      const valor = parseFloat(texto.replace(/[R$\s]/g, '').replace('.', '').replace(',', '.'));
      expect(texto.trim()).to.match(/^R\$ -?\s?\d{1,3}(\.\d{3})*,\d{2}$/);

      if (valor >= 0) {
        cy.get('@linhaTotal').find('td').eq(3).should('have.class', 'positive-value');
      } else {
        cy.get('@linhaTotal').find('td').eq(3).should('have.class', 'negative-value');
      }
    });
  });

  it('82 - Deve validar a soma total das receitas', () => {
    let somaReceitas = 0;
    cy.get('table tbody tr').not('.saldo-total').each(($tr) => {
      cy.wrap($tr).find('td').eq(1).invoke('text').then((text) => {
        const valor = parseFloat(text.replace(/[R$\.\s]/g, '').replace(',', '.'));
        somaReceitas += valor;
      });
    }).then(() => {
      cy.get('table tbody tr.saldo-total td').eq(1).invoke('text').then((textTotal) => {
        const total = parseFloat(textTotal.replace(/[R$\.\s]/g, '').replace(',', '.'));
        expect(total).to.eq(somaReceitas);
      });
    });
  });

  it('83 - Deve validar a soma total das despesas', () => {
    let somaDespesas = 0;
    cy.get('table tbody tr').not('.saldo-total').each(($tr) => {
      cy.wrap($tr).find('td').eq(2).invoke('text').then((text) => {
        const valor = parseFloat(text.replace(/[R$\.\s-]/g, '').replace(',', '.'));
        somaDespesas += valor;
      });
    }).then(() => {
      cy.get('table tbody tr.saldo-total td').eq(2).invoke('text').then((textTotal) => {
        const total = parseFloat(textTotal.replace(/[R$\.\s-]/g, '').replace(',', '.'));
        expect(total).to.eq(somaDespesas);
      });
    });
  });

  it('84 - Deve validar que o saldo total é a diferença entre receitas e despesas', () => {
    let receitas = 0;
    let despesas = 0;
    cy.get('table tbody tr').not('.saldo-total').each(($tr) => {
      cy.wrap($tr).find('td').eq(1).invoke('text').then((text) => {
        receitas += parseFloat(text.replace(/[R$\.\s]/g, '').replace(',', '.'));
      });
      cy.wrap($tr).find('td').eq(2).invoke('text').then((text) => {
        despesas += parseFloat(text.replace(/[R$\.\s-]/g, '').replace(',', '.'));
      });
    }).then(() => {
      const saldoEsperado = receitas - despesas;
      cy.get('table tbody tr.saldo-total td').eq(3).invoke('text').then((textSaldo) => {
        const saldoTotal = parseFloat(textSaldo.replace(/[R$\.\s-]/g, '').replace(',', '.'));
        if (textSaldo.includes('-')) {
          expect(-saldoTotal).to.eq(saldoEsperado);
        } else {
          expect(saldoTotal).to.eq(saldoEsperado);
        }
      });
    });
  });

 it('220 - Deve redirecionar para a página de detalhes da conta ao clicar no link', () => {
    // Verifica se pelo menos uma conta está listada
    cy.get('table tbody tr td a').first().should('be.visible').then(($link) => {
      const href = $link.attr('href');
      // Remove o atributo target="_blank" para que o Cypress siga o link na mesma aba
      cy.wrap($link).invoke('removeAttr', 'target');
      // Clica no link e valida se a URL mudou corretamente
      cy.wrap($link).click();
      cy.url().should('include', href);
      // Validação extra: a página de detalhes deve conter algum identificador, como título
      cy.contains('Detalhes da Conta').should('be.visible');
    });
  });

  it('221 - Despesa de conta específica deve ser exibida em vermelho', () => {
    // Usando a conta "testes detalhe conta" que tem despesa de R$ - 500,00
    cy.contains('table tbody tr td:first-child a', 'testes detalhe conta').parents('tr').within(() => {
      cy.get('td').eq(2) // Coluna de Despesas
        .should('contain', 'R$ -') // Verifica se o texto indica uma despesa
        .should('have.class', 'negative-value') // Valida que a classe está no HTML
        .should('have.css', 'color', 'rgb(255, 36, 0)'); // Valida a cor renderizada na UI
    });
  });

  it('222 - Saldo negativo de conta específica deve ser exibido em vermelho', () => {
    // Usando a conta "testes detalhe conta" que tem saldo de R$ -200,00
    cy.contains('table tbody tr td:first-child a', 'testes detalhe conta').parents('tr').within(() => {
      cy.get('td').eq(3) // Coluna de Saldo
        .should('contain', 'R$ -') // Verifica se o saldo é negativo
        .should('have.class', 'negative-value') // Valida que a classe está no HTML
        .should('have.css', 'color', 'rgb(255, 36, 0)'); // Valida a cor renderizada na UI
    });
  });

  it('223 - Saldo positivo de conta específica deve ser exibido em verde', () => {
    // Usando a conta "Conta Listar 2" ou "teste add" ou "Teste editar" ou "Validar Link"
    // que pela imagem tem saldo R$ 0,00 (que é exibido em verde)
    cy.contains('table tbody tr td:first-child a', 'Conta Listar 2').parents('tr').within(() => {
      cy.get('td').eq(3) // Coluna de Saldo
        .should('not.contain', 'R$ -') // Verifica se o saldo é positivo (ou zero)
        .should('have.class', 'positive-value') // Valida que a classe está no HTML
        .should('have.css', 'color', 'rgb(0, 255, 0)'); // Valida a cor renderizada na UI
    });
  });

  it('224 - Despesas totais devem ser exibidas em vermelho se houver valor', () => {
    cy.get('tr.saldo-total').within(() => {
      cy.get('td').eq(2).then(($td) => { // Coluna de Despesas Total
        const text = $td.text();
        // Ajuste a regex para remover o "R$ -" e o ponto de milhar antes de converter
        const value = parseFloat(text.replace('R$ - ', '').replace(/\./g, '').replace(',', '.'));
        if (value > 0) { // Se houver despesas totais
          cy.wrap($td).should('have.class', 'negative-value').should('have.css', 'color', 'rgb(255, 36, 0)');
        } else { // Se não houver despesas totais (valor 0)
          cy.wrap($td).should('not.have.class', 'negative-value').should('have.css', 'color', 'rgb(255, 255, 255)');
        }
      });
    });
  });

  it('225 - Saldo total negativo deve ser exibido em vermelho', () => {
    cy.get('tr.saldo-total').within(() => {
      cy.get('td').eq(3).then(($td) => { // Coluna de Saldo Total
        const text = $td.text();
        if (text.includes('-')) { // Se o saldo total for negativo
          cy.wrap($td).should('have.class', 'negative-value').should('have.css', 'color', 'rgb(255, 36, 0)');
        } else { // Se o saldo total for positivo ou zero
          cy.wrap($td).should('not.have.class', 'negative-value').should('have.css', 'color', 'rgb(0, 255, 0)');
        }
      });
    });
  });

  it('226 - Saldo total positivo deve ser exibido em verde', () => {
    // Este teste só passará se o saldo total for realmente positivo.
    // Pela imagem, o saldo total é negativo (R$ -200,00), então este teste pode falhar
    // a menos que os dados de teste sejam alterados para um cenário de saldo total positivo.
    cy.get('tr.saldo-total').within(() => {
      cy.get('td').eq(3).then(($td) => { // Coluna de Saldo Total
        const text = $td.text();
        if (!text.includes('-')) { // Se o saldo total for positivo (não contém '-')
          cy.wrap($td).should('have.class', 'positive-value').should('have.css', 'color', 'rgb(0, 255, 0)');
        } else { // Se o saldo total for negativo
          cy.wrap($td).should('not.have.class', 'positive-value').should('have.css', 'color', 'rgb(255, 36, 0)');
        }
      });
    });
  });
});