// cypress/e2e/movimentacao_editar.cy.js

import EditMovimentacaoPage from '../support/page_objects/EditMovimentacaoPage';
import LoginPage from '../support/page_objects/loginPage';

const USER_EMAIL = 'editarMovimentacao@movimentacao.com';
const USER_PASSWORD = 'login_10';

// Acessa a conta clicando no botão Detalhes com base no nome fixo
const acessarContaPorNome = (nomeConta) => {
  cy.visit('/home');
  cy.contains('td', nomeConta)
    .parent('tr')
    .find('a.btn-primary')
    .invoke('removeAttr', 'target')
    .click();
  cy.url().should('include', '/contas/detalhes/');
  cy.contains('Detalhes da Conta').should('be.visible');
};

describe('Testes Funcionais, de Validação e Segurança - Página Editar Movimentação', () => {
  beforeEach(() => {
    cy.clearCookies();
    cy.clearLocalStorage();
    cy.visit('/logout');
    LoginPage.login(USER_EMAIL, USER_PASSWORD);
    cy.visit('/home');
  });

  it('298 - Validar os dados previamente preenchidos no formulário Editar Movimentação', () => {
    acessarContaPorNome('Conta 1');

    cy.get('table tbody tr').first().find('a.btn-warning').click();
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    EditMovimentacaoPage.getTipo().invoke('val').should('not.be.empty');
    EditMovimentacaoPage.getValor().invoke('val').should('not.be.empty');
    EditMovimentacaoPage.getDescricao().invoke('val').should('not.be.empty');
    EditMovimentacaoPage.getDataMovimentacao().invoke('val').should('not.be.empty');
    EditMovimentacaoPage.getDataPagamento().invoke('val').should('not.be.empty');
    EditMovimentacaoPage.getInteressado().invoke('val').should('not.be.empty');
    EditMovimentacaoPage.getContaId().invoke('val').should('not.be.empty');
    cy.get('input[name="situacao"]:checked').should('exist');
  });

  it('299 - Deve editar todos os campos com valores válidos e salvar com sucesso', () => {
    const sufixo = Cypress._.random(10, 99);

    function parseLocalizedFloat(str) {
      str = str.replace('R$', '').trim();
      const hasComma = str.includes(',');
      const hasDot = str.includes('.');
      if (hasComma && hasDot) {
        str = str.replace(/\./g, '');
        str = str.replace(',', '.');
      } else if (hasComma) {
        str = str.replace(',', '.');
      }
      return parseFloat(str);
    }

    acessarContaPorNome('Conta 2');

    cy.get('table tbody tr').first().find('a.btn-warning').click();
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    EditMovimentacaoPage.getValor().invoke('val').then((valorAtual) => {
      const valorNumerico = parseLocalizedFloat(valorAtual);
      const novoValorNumerico = valorNumerico + 10;
      const novoValorParaInput = novoValorNumerico.toFixed(2);

      const valorFormatadoParaTabela = novoValorNumerico.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });

      const valorSemSimbolo = novoValorNumerico.toLocaleString('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });

      EditMovimentacaoPage.getTipo().select('despesa');
      EditMovimentacaoPage.getValor().clear().type(novoValorParaInput);
      EditMovimentacaoPage.getDataMovimentacao().clear().type('2024-06-01');
      EditMovimentacaoPage.getDataPagamento().clear().type('2024-06-02');
      EditMovimentacaoPage.getDescricao().clear().type(`Despesa editada ${sufixo}`);
      EditMovimentacaoPage.getInteressado().clear().type(`Fornecedor X ${sufixo}`);
      EditMovimentacaoPage.getContaId().select('Conta 2');
      EditMovimentacaoPage.getSituacao('pago').check();
      EditMovimentacaoPage.submit();

      cy.url({ timeout: 10000 }).should('include', '/contas/detalhes/');
      cy.contains('Movimentação atualizada com sucesso').should('exist');
      cy.get('div.alert.alert-success').should('exist');

      // Log do texto da tabela para debug
      cy.get('table').invoke('text').then(text => {
        cy.log('Conteúdo da tabela: ' + text);
      });

      // Validação do valor na tabela, tentando com símbolo e sem símbolo
      cy.get('table').should('contain', `Despesa editada ${sufixo}`).then($table => {
        if (!$table.text().includes(valorFormatadoParaTabela)) {
          cy.log('Valor formatado com símbolo não encontrado, tentando sem símbolo');
          cy.get('table').should('contain', valorSemSimbolo);
        }
      });

      // Validação numérica precisa na linha da despesa editada, usando td.negative-value
      cy.get('table')
        .contains(`Despesa editada ${sufixo}`)
        .parent('tr')
        .within(() => {
          cy.get('td.negative-value')
            .invoke('text')
            .then(textValor => {
              const numeroFormatado = textValor.replace(/[R$\s\.]/g, '').replace(',', '.');
              const numero = parseFloat(numeroFormatado);
              expect(numero).to.eq(novoValorNumerico);
            });
        });

    });
  });


  it('300 - Deve validar campos obrigatórios e exibir erros', () => {
    acessarContaPorNome('Conta 1');
    cy.get('table tbody tr').first().find('a.btn-warning').click();
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    EditMovimentacaoPage.getValor().clear();
    EditMovimentacaoPage.getDescricao().clear();
    EditMovimentacaoPage.submit();

    cy.contains('Informe um valor.').should('be.visible');
    cy.contains('Descrição é obrigatória.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/'); // Permanece na página de edição
  });

  it('301 - Deve impedir seleção de conta inexistente ou inválida (manipulada via devtools)', () => {
    acessarContaPorNome('Conta 1');
    cy.get('table tbody tr').first().find('a.btn-warning').click();
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    EditMovimentacaoPage.getContaId().invoke('val', '9999'); // manipulando forçadamente
    EditMovimentacaoPage.submit();

    cy.contains('Você precisa selecionar uma conta.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/'); // Permanece na página de edição
  });

it('302 - Deve manter dados preenchidos após erro de validação', () => {
  acessarContaPorNome('Conta 1');

  cy.get('table tbody tr').first().find('a.btn-warning').click();
  cy.url().should('include', '/movimentacao/editar/');
  cy.contains('Editar Movimentação').should('be.visible');

  // Limpa o campo descrição para causar erro de validação
  EditMovimentacaoPage.getDescricao().clear();

  // Submete o formulário
  EditMovimentacaoPage.submit();

  // Verifica a mensagem de erro correta (sem o prefixo do label)
  cy.contains('Descrição é obrigatória.').should('be.visible');

  // Verifica se os outros campos mantiveram seus valores
  EditMovimentacaoPage.getValor().invoke('val').should('not.be.empty');
  EditMovimentacaoPage.getTipo().invoke('val').should('not.be.empty');
  cy.get('input[name="situacao"]:checked').should('exist');
  EditMovimentacaoPage.getInteressado().invoke('val').should('not.be.empty');
  EditMovimentacaoPage.getDataMovimentacao().invoke('val').should('not.be.empty');
  EditMovimentacaoPage.getDataPagamento().invoke('val').should('not.be.empty');
  EditMovimentacaoPage.getContaId().invoke('val').should('not.eq', '0');

  // Verifica que o campo descrição está vazio
  EditMovimentacaoPage.getDescricao().invoke('val').should('eq', '');

  // Permanece na página de edição
  cy.url().should('include', '/movimentacao/editar/');
});


  it('303 - Deve redirecionar corretamente ao clicar em Cancelar', () => {
    acessarContaPorNome('Conta 3'); // entra na conta 3

    // Clica no botão "Editar" da primeira movimentação e espera a página carregar
    cy.get('table tbody tr').first().find('a.btn-warning').click();

    // Espera a URL de edição
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Clica no botão cancelar
    EditMovimentacaoPage.cancelar();

    // Agora espera que a URL volte para detalhes da conta 3
    cy.url().should('include', '/contas/detalhes/203');
    cy.contains('Detalhes da Conta').should('be.visible');
  });


it('304 - Deve validar data inválida e exibir mensagem de erro', () => {
  acessarContaPorNome('Conta 3');

  cy.url().should('include', '/contas/detalhes/');
  cy.contains('Detalhes da Conta').should('be.visible');

  cy.get('table tbody tr').first().find('a.btn-warning').click();

  cy.url().should('include', '/movimentacao/editar/');
  cy.contains('Editar Movimentação').should('be.visible');

  // Preencher campos obrigatórios com valores válidos
  EditMovimentacaoPage.getTipo().select('receita');
  EditMovimentacaoPage.getValor().clear().type('100.00');
  EditMovimentacaoPage.getDescricao().clear().type('Teste descrição');
  EditMovimentacaoPage.getDataPagamento().clear().type('2025-06-25');
  EditMovimentacaoPage.getSituacao('pago').check();

  // Forçar valor inválido no campo data_movimentacao
  EditMovimentacaoPage.getDataMovimentacao()
    .invoke('val', '15/00/0000') // valor inválido (formato inválido)
    .trigger('input'); // dispara evento para atualizar o campo

  // Enviar o formulário
  EditMovimentacaoPage.submit();

  // Verifica se a mensagem de erro aparece (ajuste o texto conforme sua validação)
  cy.contains('Informe a data da movimentação.').should('be.visible');

  // Deve permanecer na página de edição
  cy.url().should('include', '/movimentacao/editar/');
});



  it('305 - Acessibilidade: todos os campos devem ser acessíveis via tabulação', () => {
    acessarContaPorNome('Conta 3');

    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Detalhes da Conta').should('be.visible');

    cy.get('table tbody tr').first().find('a.btn-warning').click();

    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');
      // Testar elementos da navbar que são visíveis por padrão
    cy.get('nav.navbar a:not(.dropdown-content a), nav.navbar button').each(($el) => {
      cy.wrap($el).should('be.visible'); // Deve estar visível
      cy.wrap($el).and(($el2) => {
        const tagName = $el2[0].tagName.toLowerCase();
        const hasHref = $el2[0].hasAttribute('href');
        const isDisabled = $el2[0].hasAttribute('disabled');
        const tabIndex = $el2[0].tabIndex;
        // Elementos interativos padrão (a, button) são focáveis por padrão, a menos que desabilitados ou tabindex=-1
          if (['a', 'button'].includes(tagName)) {
            expect(isDisabled, `Elemento ${tagName} não deve estar desabilitado`).to.be.false;
            expect(tabIndex, `Elemento ${tagName} não deve ter tabindex=-1`).to.not.equal(-1);
          } else {
            // Para outros elementos, verificar se tem tabindex >= 0
            expect(tabIndex, `Elemento ${tagName} deve ter tabindex >= 0`).to.be.gte(0);
          }
      });
    });
      // Testar elementos do dropdown APÓS abri-lo
    cy.get('button.dropbtn').click(); // Clica no botão "Contas" para abrir o dropdown
    cy.get('.dropdown-content a').each(($el) => {
    cy.wrap($el).should('be.visible'); // Agora devem estar visíveis
    cy.wrap($el).and(($el2) => {
       const tagName = $el2[0].tagName.toLowerCase();
       const hasHref = $el2[0].hasAttribute('href');
       const isDisabled = $el2[0].hasAttribute('disabled');
       const tabIndex = $el2[0].tabIndex;
       expect(isDisabled, `Elemento ${tagName} no dropdown não deve estar desabilitado`).to.be.false;
       expect(tabIndex, `Elemento ${tagName} no dropdown não deve ter tabindex=-1`).to.not.equal(-1);
     });
    });
      // Campos do formulário: inputs, selects, buttons
      // Excluímos inputs do tipo 'hidden' da verificação de visibilidade e focabilidade
    cy.get('form input:not([type="hidden"]), form select, form button').each(($el) => {
      cy.wrap($el).should('be.visible'); // Deve estar visível
      cy.wrap($el).and(($el2) => {
      const tagName = $el2[0].tagName.toLowerCase();
      const type = $el2[0].type;
      const isDisabled = $el2[0].hasAttribute('disabled');
      const tabIndex = $el2[0].tabIndex;
        expect(isDisabled, `Campo ${tagName} (type: ${type}) não deve estar desabilitado`).to.be.false;
        expect(tabIndex, `Campo ${tagName} (type: ${type}) não deve ter tabindex=-1`).to.not.equal(-1);
      });
    });
      // Links de ação (Cancelar)
    cy.get('a.btn-secondary').should('be.visible');
    cy.get('a.btn-secondary').and(($el) => {
      expect($el[0].hasAttribute('disabled'), 'Botão Cancelar não deve estar desabilitado').to.be.false;
      expect($el[0].tabIndex, 'Botão Cancelar não deve ter tabindex=-1').to.not.equal(-1);
    });
  });

  // --- Testes de Consistência de Dados (IDs 306-312) ---
it('306 - Deve comparar os dados da movimentação com os do formulário de edição', () => {
  acessarContaPorNome('Conta 1');

  // Captura os dados da primeira movimentação
  cy.get('table tbody tr').first().then(($row) => {
    const td = $row.find('td');
    const rawData = {
      data: td.eq(0).text().trim(),
      descricao: td.eq(1).text().trim(),
      tipo: td.eq(2).text().trim().toLowerCase(),
      valor: td.eq(3).text().trim(),
      situacao: td.eq(4).text().trim().toLowerCase(),
    };

    // Clica no botão de editar
    cy.wrap($row).find('a.btn-warning').click();

    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Validação do campo data_movimentacao
    const formattedData = rawData.data.split('/').reverse().join('-');
    EditMovimentacaoPage.getDataMovimentacao().should('have.value', formattedData);

    // Validação da descrição
    EditMovimentacaoPage.getDescricao().should('have.value', rawData.descricao);

    // Validação do tipo
    EditMovimentacaoPage.getTipo().should('have.value', rawData.tipo);

    // Validação do valor
    const valorFloat = parseFloat(rawData.valor.replace('R$', '').replace(/\./g, '').replace(',', '.'));
    EditMovimentacaoPage.getValor().invoke('val').then((val) => {
      const valParsed = parseFloat(val.replace(',', '.'));
      expect(valParsed).to.eq(valorFloat);
    });

    // Validação da situação (radio button)
    cy.get(`input[name="situacao"][value="${rawData.situacao}"]`).should('be.checked');
  });
});

  it('307 - Deve alternar a situação da movimentação e validar mudanças na tela de detalhes', () => {
    acessarContaPorNome('Conta 3');

    cy.get('table tbody tr').should('be.visible').and('have.length.at.least', 1);

    let situacaoAntes;

    // 1. Captura a situação inicial e clica no botão de editar
    cy.get('table tbody tr').first().within(() => {
      cy.get('td').eq(4).invoke('text').then((text) => {
        situacaoAntes = text.trim().toLowerCase();
        cy.log(`Situação antes da edição: "${situacaoAntes}"`);
      });
      cy.get('a.btn-warning').click();
    });

    // 2. Aguarda a tela de edição carregar
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // 3. Define os valores atualizados dinamicamente
    cy.then(() => {
      const hoje = new Date();
      const ano = hoje.getFullYear();
      const mes = String(hoje.getMonth() + 1).padStart(2, '0');
      const dia = String(hoje.getDate()).padStart(2, '0');
      const dataInput = `${ano}-${mes}-${dia}`; // YYYY-MM-DD para input[type="date"]

      // Alterna situação e atualiza data de pagamento
      if (situacaoAntes === 'pago') {
        EditMovimentacaoPage.getSituacao('pendente').check({ force: true });
      } else if (situacaoAntes === 'pendente') {
        EditMovimentacaoPage.getSituacao('pago').check({ force: true });
      } else {
        throw new Error(`Situação inesperada: ${situacaoAntes}`);
      }

      EditMovimentacaoPage.getDataPagamento().clear().type(dataInput);
      cy.log(`Data de pagamento inserida: ${dataInput}`);
    });

    // 4. Submete o formulário
    EditMovimentacaoPage.submit();

    // 5. Valida redirecionamento e mensagem de sucesso
    cy.url().then(currentUrl => {
      if (!currentUrl.includes('/contas/detalhes/')) {
        cy.get('.alert.alert-danger, .text-danger').each(($el) => {
          cy.log(`Erro visível no formulário: ${$el.text()}`);
        });
        throw new Error(`Esperava redirecionar para /contas/detalhes/, mas permaneceu em ${currentUrl}`);
      }

      cy.contains('Movimentação atualizada com sucesso!').should('be.visible');
    });

    // 6. Valida que a situação foi alterada na tabela
    cy.get('table tbody tr').should('be.visible').and('have.length.at.least', 1);
    cy.get('table tbody tr').first().within(() => {
      cy.get('td').eq(4).invoke('text').then(situacaoDepois => {
        const situacaoDepoisTrim = situacaoDepois.trim().toLowerCase();

        if (situacaoAntes === 'pago') {
          expect(situacaoDepoisTrim).to.equal('pendente');
        } else if (situacaoAntes === 'pendente') {
          expect(situacaoDepoisTrim).to.equal('pago');
        }

        cy.log(`Situação validada na tabela: ${situacaoDepoisTrim}`);
      });
    });
  });


  it('308 - Deve alterar movimentação de PENDENTE para PAGO e validar mudanças', () => {
    const initialStatus = 'pendente';
    const targetStatus = 'pago';

    acessarContaPorNome('Conta 3');

    // Garante que a tabela tem pelo menos uma linha visível
    cy.get('table tbody tr').should('be.visible').and('have.length.at.least', 1);

    // Encontra a primeira movimentação com o status inicial na tabela
    cy.get('table tbody tr')
      .filter(`:contains("${initialStatus.charAt(0).toUpperCase() + initialStatus.slice(1)}")`)
      .first()
      .within(() => {
        cy.get('a.btn-warning').click(); // Clica no botão de editar
      });

    // Aguarda a tela de edição carregar
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Prepara as datas (hoje)
    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10); // Formato YYYY-MM-DD para input type="date"
    const dia = String(hoje.getDate()).padStart(2, '0');
    const mes = String(hoje.getMonth() + 1).padStart(2, '0');
    const ano = hoje.getFullYear();
    const hojeFormatadoDDMMYYYY = `${dia}/${mes}/${ano}`; // Formato DD/MM/AAAA para validação na tabela

    // Define a nova situação e trata a data de pagamento
    EditMovimentacaoPage.getSituacao(targetStatus).check({ force: true });

    if (targetStatus === 'pendente') {
      EditMovimentacaoPage.getDataPagamento().clear(); // Para 'pendente', a data de pagamento deve ser limpa
      cy.log(`Alternando para: ${targetStatus.toUpperCase()}. Data de pagamento limpa.`);
    } else if (targetStatus === 'pago') {
      EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO); // Para 'pago', preenche com a data de hoje
      cy.log(`Alternando para: ${targetStatus.toUpperCase()}. Data de pagamento preenchida com: ${hojeISO}`);
    } else {
      throw new Error(`Situação de destino inesperada: ${targetStatus}`);
    }

    // Submete o formulário
    EditMovimentacaoPage.submit();

    // Valida redirecionamento e mensagem de sucesso
    cy.url().then(currentUrl => {
      if (currentUrl.includes('/contas/detalhes/')) {
        cy.contains('Movimentação atualizada com sucesso!').should('be.visible');
        cy.log('Redirecionamento para /contas/detalhes/ bem-sucedido.');
      } else {
        cy.log(`Redirecionamento falhou. URL atual: ${currentUrl}`);
        // Logar mensagens de erro no formulário se houver
        cy.get('.alert.alert-danger, .text-danger').each(($el) => {
          cy.log(`Erro visível no formulário: ${$el.text()}`);
        });
        throw new Error(`Esperava redirecionar para /contas/detalhes/, mas permaneceu em ${currentUrl}. Verifique os logs acima para erros do formulário.`);
      }
    });

    // Valida que a situação e a data foram alteradas na tabela de detalhes
    cy.get('table tbody tr')
      .filter(`:contains("${targetStatus.charAt(0).toUpperCase() + targetStatus.slice(1)}")`)
      .first()
      .within(() => {
        // Valida a Situação (coluna 4, índice 3)
        cy.get('td').eq(4).invoke('text').then(situacaoDepois => {
          expect(situacaoDepois.trim().toLowerCase()).to.equal(targetStatus);
          cy.log(`Situação validada na tabela: ${situacaoDepois.trim().toLowerCase()} (esperado: ${targetStatus})`);
        });
      });
  });

  it('309 - Deve exibir erro se "Tipo" estiver vazio', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    EditMovimentacaoPage.getDescricao().clear();
    EditMovimentacaoPage.getValor().clear().type('100,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    cy.contains('Descrição é obrigatória.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('310 - Deve exibir erro ao submeter com Valor inválido (zero)', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    EditMovimentacaoPage.getValor().clear().type('0,00');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Valor Zero');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    cy.contains('O valor deve ser maior ou igual a 0.01.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('311 - Deve exibir erro ao submeter movimentação PAGA com Data de Pagamento futura', () => {
    acessarContaPorNome('Conta 2');

    cy.get('table tbody tr').first().within(() => {
      cy.get('a.btn-warning').click();
    });

    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    const hoje = new Date();
    const dataHojeStr = hoje.toISOString().split('T')[0]; // yyyy-mm-dd

    const dataFutura = new Date(hoje);
    dataFutura.setDate(dataFutura.getDate() + 1);
    const dataFuturaStr = dataFutura.toISOString().split('T')[0];

    // Lógica igual à do backend Python: hoje - 3650 dias
    const dataMinima = new Date();
    dataMinima.setDate(dataMinima.getDate() - 3650);

    const dataMinimaStr = dataMinima.toLocaleDateString('pt-BR'); // DD/MM/YYYY
    const dataMaximaStr = hoje.toLocaleDateString('pt-BR');        // DD/MM/YYYY

    const mensagemEsperada = `A data de pagamento deve estar entre ${dataMinimaStr} e ${dataMaximaStr}.`;

    EditMovimentacaoPage.getDataMovimentacao().clear().type(dataHojeStr);
    EditMovimentacaoPage.getSituacao('pago').check({ force: true });
    EditMovimentacaoPage.getDataPagamento().clear().type(dataFuturaStr);
    EditMovimentacaoPage.getDescricao().clear().type('Teste Data Futura');
    EditMovimentacaoPage.getValor().clear().type('50.00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.submit();

    cy.contains(mensagemEsperada).should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });
  // --- Novos testes focados em validação de erro (a partir do 312) ---

  it('312 - Deve exibir erro se "Tipo" estiver vazio', () => {
    acessarContaPorNome('Conta 2');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Tenta selecionar a opção vazia (se existir, ou apenas limpa se for um input)
    // No caso de SelectField, selecionar '' envia um valor vazio ou nulo se houver a opção.
    EditMovimentacaoPage.getTipo().select('');

    // Preenche os outros campos com valores válidos para isolar o erro
    EditMovimentacaoPage.getDescricao().clear().type('Teste Tipo Vazio');
    EditMovimentacaoPage.getValor().clear().type('100,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO); // Certifica que data_movimentacao está preenchida

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro
    cy.contains('Selecione o tipo de movimentação.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('313 - Deve exibir erro se "Data de movimentação" for futura', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Preenche a data de movimentação com uma data futura (amanhã)
    const amanha = new Date();
    amanha.setDate(amanha.getDate() + 1);
    const amanhaISO = amanha.toISOString().slice(0, 10);

    EditMovimentacaoPage.getDataMovimentacao().clear().type(amanhaISO);

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Data Futura Mov');
    EditMovimentacaoPage.getValor().clear().type('50,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro. A mensagem de erro esperada deve ser do formato
    // 'A data da movimentação deve estar entre DD/MM/YYYY e DD/MM/YYYY.'
    // Para validar isso de forma robusta, podemos procurar por uma parte da string
    // ou por um padrão. Vou usar 'A data da movimentação deve estar entre'
    cy.contains('A data da movimentação deve estar entre').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('314 - Deve exibir erro se "Data de movimentação" for muito no passado', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Preenche a data de movimentação com uma data muito no passado (ex: 2000-01-01)
    EditMovimentacaoPage.getDataMovimentacao().clear().type('2000-01-01');

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Data Passada Mov');
    EditMovimentacaoPage.getValor().clear().type('50,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro
    cy.contains('A data da movimentação deve estar entre').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('315 - Deve exibir erro se "Data de pagamento" for anterior à Data de Movimentação para PENDENTE', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Preenche a data de movimentação (ex: hoje)
    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO);

    // Preenche a data de pagamento com uma data anterior à data de movimentação (ex: ontem)
    const ontem = new Date();
    ontem.setDate(ontem.getDate() - 1);
    const ontemISO = ontem.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(ontemISO);

    // Define a situação como "pendente" (para ativar essa validação)
    EditMovimentacaoPage.getSituacao('pendente').check({force: true});

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Data Pag. < Data Mov.');
    EditMovimentacaoPage.getValor().clear().type('75,00');
    EditMovimentacaoPage.getContaId().select('203');

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro
    cy.contains('Para movimentações pendentes, a data de pagamento não pode ser no passado.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('316 - Deve exibir erro se "Descrição" exceder 30 caracteres', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Preenche a descrição com mais de 30 caracteres
    EditMovimentacaoPage.getDescricao().clear().type('Esta é uma descrição muito, muito longa que excede o limite de 30 caracteres.');

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getValor().clear().type('100,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro
    cy.contains('Descrição deve ter no máximo 30 caracteres.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('317 - Deve exibir erro se "Valor" estiver vazio', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Limpa o campo Valor
    EditMovimentacaoPage.getValor().clear();

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Valor Vazio');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro
    cy.contains('Informe um valor.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('318 - Deve exibir erro se "Valor" for inválido (texto)', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Preenche o campo Valor com texto inválido
    EditMovimentacaoPage.getValor().clear().type('Valor inválido');
    
    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Valor Texto');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro (a mensagem exata pode variar dependendo do WTForms e do navegador)
    // Uma mensagem comum é "Valor inválido." ou "Não é um número válido."
    cy.contains('Valor inválido.').should('be.visible'); // Ou 'Deve ser um número válido'
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('319 - Deve exibir erro se "Data de movimentação" estiver vazia', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Limpa o campo Data de movimentação
    EditMovimentacaoPage.getDataMovimentacao().clear();

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Data Mov Vazia');
    EditMovimentacaoPage.getValor().clear().type('100,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro
    cy.contains('Informe a data da movimentação.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('320 - Deve exibir erro se "Conta" não for selecionada', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Seleciona a opção com valor 0 (geralmente "Selecione uma conta")
    EditMovimentacaoPage.getContaId().select('0');

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Conta Vazia');
    EditMovimentacaoPage.getValor().clear().type('100,00');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida a mensagem de erro
    cy.contains('Você precisa selecionar uma conta.').should('be.visible');
    cy.url().should('include', '/movimentacao/editar/');
  });

  it('321 - Deve permitir limpar o campo "Interessado" (não obrigatório)', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    // Limpa o campo Interessado
    EditMovimentacaoPage.getInteressado().clear();

    // Preenche os outros campos com valores válidos (para garantir que a submissão aconteça)
    EditMovimentacaoPage.getTipo().select('despesa');
    EditMovimentacaoPage.getDescricao().clear().type('Teste Interessado Limpo');
    EditMovimentacaoPage.getValor().clear().type('10,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida que a atualização foi um sucesso (redirecionou)
    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Movimentação atualizada com sucesso!').should('be.visible');

    // Opcional: Validar que o campo Interessado está de fato vazio na tabela de detalhes,
    // se essa coluna for visível e o teste se aplicar.
    // cy.get('table tbody tr').filter(':contains("Teste Interessado Limpo")').first().within(() => {
    //   cy.get('td').eq(<indice_coluna_interessado>).should('have.text', '');
    // });
  });

  it('322 - Deve permitir preencher o campo "Interessado" (não obrigatório)', () => {
    acessarContaPorNome('Conta 3');
    cy.get('table tbody tr').first().within(() => { cy.get('a.btn-warning').click(); });
    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible');

    const interessado = 'Novo Interessado Teste';
    EditMovimentacaoPage.getInteressado().clear().type(interessado);

    // Preenche os outros campos com valores válidos
    EditMovimentacaoPage.getTipo().select('receita'); // Altera tipo para garantir mudança
    EditMovimentacaoPage.getDescricao().clear().type('Teste Interessado Preenchido');
    EditMovimentacaoPage.getValor().clear().type('200,00');
    EditMovimentacaoPage.getContaId().select('203');
    EditMovimentacaoPage.getSituacao('pago').check({force: true});

    const hoje = new Date();
    const hojeISO = hoje.toISOString().slice(0, 10);
    EditMovimentacaoPage.getDataPagamento().clear().type(hojeISO);
    EditMovimentacaoPage.getDataMovimentacao().clear().type(hojeISO);

    EditMovimentacaoPage.submit();

    // Valida que a atualização foi um sucesso (redirecionou)
    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Movimentação atualizada com sucesso!').should('be.visible');

    // Opcional: Validar que o campo Interessado está de fato preenchido na tabela de detalhes,
    // se essa coluna for visível e o teste se aplicar.
    // cy.get('table tbody tr').filter(':contains("Teste Interessado Preenchido")').first().within(() => {
    //   cy.get('td').eq(<indice_coluna_interessado>).should('have.text', interessado);
    // });
  });
});