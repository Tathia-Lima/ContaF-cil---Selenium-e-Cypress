import LoginPage from '../support/page_objects/loginPage';
import { gerarSufixo } from '../support/utils';

describe('ContaFácil - Página Adicionar Conta', () => {
  beforeEach(() => {
    // Usa cy.session para manter login entre testes
    cy.session('sessao-pagina-inicial', () => {
      LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/contas/adicionar');
  });

  it('124 - Deve conter título da aba correto', () => {
    cy.title().should('eq', 'ContaFácil - Adicionar Conta');
  });

  it('125 - Deve conter o título visível "Adicionar Conta"', () => {
    cy.get('h2').should('have.text', 'Adicionar Conta').and('be.visible');
  });

  it('126 - Deve conter um formulário com method POST', () => {
    cy.get('form').should('have.attr', 'method', 'post');
  });

  it('127 - Deve conter o campo oculto de CSRF Token', () => {
    cy.get('input[name="csrf_token"]').should('exist').and('have.attr', 'type', 'hidden');
  });

  it('128 - Deve conter campo de nome com label correto', () => {
    cy.get('label[for="nome"]').should('have.text', 'Nome');
    cy.get('input#nome').should('have.attr', 'name', 'nome');
  });

  it('129 - Deve permitir digitar no campo "nome"', () => {
    cy.get('input#nome').type('Conta Corrente').should('have.value', 'Conta Corrente');
  });

  it('130 - Botão "Salvar" deve ser do tipo submit e visível', () => {
    cy.get('button[type="submit"]').should('contain', 'Salvar').and('be.visible');
  });

  it('131 - Deve redirecionar para a Home ao clicar em "Cancelar"', () => {
    cy.get('a.btn-secondary')
      .should('have.attr', 'href')
      .and('include', '/home');
  });
//Teste de
// Este teste simula o envio do formulário com o token CSRF inválido (removido).
// O objetivo é garantir que a aplicação bloqueie o envio e retorne um erro 400 (Bad Request),
// como esperado em uma falha de segurança por ausência do token CSRF.
  it('132 - Deve retornar erro 400 se o CSRF token estiver ausente', () => {
    cy.intercept('POST', '/contas/adicionar').as('postAdicionarConta'); // intercepta a requisição POST
    cy.get('input#nome').type('Conta CSRF inválido');
    cy.get('input[name="csrf_token"]').invoke('val', ''); // zera o token
    cy.get('form').submit(); // envia o formulário manualmente
    cy.wait('@postAdicionarConta').its('response.statusCode').should('eq', 400); // valida status 400
  });

  it('133 - Deve ter estrutura semântica HTML correta (form, label, input)', () => {
    cy.get('form').within(() => {
      cy.get('label').should('have.length.at.least', 1);
      cy.get('input').should('have.length.at.least', 2); // nome + csrf
    });
  });

  it('134 - Deve adicionar conta com exatamente 19 caracteres', () => {
    const nomeBase = 'Conta com 16 cha'; // 16 + 3 = 19
    const nome19 = nomeBase + gerarSufixo(3);
    expect(nome19.length).to.eq(19);
    cy.get('input[name="nome"]').type(nome19);
    cy.get('button[type="submit"]').click();
    cy.contains('Conta adicionada com sucesso!').should('be.visible');
  });

  it('135 - Deve adicionar conta com exatamente 20 caracteres', () => {
    const base = 'Conta com ';
    const sufixo = gerarSufixo(20 - base.length); // Completa para 20 caracteres
    const nome20 = base + sufixo;
    expect(nome20.length).to.eq(20); // Garantia no teste
    cy.get('input[name="nome"]').clear().type(nome20);
    cy.get('button[type="submit"]').click();
    cy.contains('Conta adicionada com sucesso!').should('be.visible');
  });

it('136 - Deve exibir erro ao tentar adicionar conta com 21 caracteres', () => {
  // Define a base do nome da conta
  const base = 'Conta Teste'; // 11 caracteres

  // Gera sufixo para completar exatamente 21 caracteres
  const caracteresRestantes = 21 - base.length;
  const sufixo = 'X'.repeat(caracteresRestantes); // Gera letras "X" para completar
  const nomeInvalido = base + sufixo;

  // Garantia: nome gerado deve ter exatamente 21 caracteres
  expect(nomeInvalido.length).to.eq(21);

  // Preenche o campo e tenta submeter
  cy.visit('/contas/adicionar');
  cy.get('input[name="nome"]').clear().type(nomeInvalido);
  cy.get('button[type="submit"]').click();

  // Verifica se a mensagem de erro aparece
  cy.contains('O nome da conta deve ter no máximo 20 caracteres.').should('be.visible');
});

  it('137 - Deve exibir erro ao tentar salvar conta com nome vazio', () => {
    cy.get('button[type="submit"]').click(); // Envia o formulário
    cy.contains('O nome da conta é obrigatório.').should('be.visible');
  });

   it('138 - Não deve cadastrar nome de conta repetida', () => {
    const nome = 'Teste Nome Duplicado';
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    cy.contains('Já existe uma conta com esse nome.').should('be.visible');
  });
});

 
