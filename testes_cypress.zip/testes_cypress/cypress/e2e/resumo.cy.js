// cypress/e2e/resumo.cy.js
import LoginPage from '../support/page_objects/loginPage';
import MovimentacaoPage from '../support/page_objects/MovimentacaoPage';

describe('Página Resumo Mensal - Testes Funcionais', () => {
  beforeEach(() => {
    cy.session('sessao-resumo-funcional', () => {
      LoginPage.login('resumo.mensal@resumo.mensal', 'login_10');
      cy.url().should('include', '/home');
    });
    cy.visit('/resumo');
  });

  // ... todos os testes de 222 a 226 permanecem iguais ...
  it('222 - Deve carregar filtros com mês, ano e tipo corretos', () => {
    const now = new Date();
    const currentMonth = (now.getMonth() + 1).toString();
    const currentYear = now.getFullYear().toString();
    cy.get('#mes').should('have.value', currentMonth);
    cy.get('#ano').should('have.value', currentYear);
    cy.get('#tipo').should('have.value', 'todos');
  });

  it('223 - Deve exibir mensagem de dados ausentes em conta sem movimentação', () => {
    cy.get('table.table').should('exist');
    cy.get('body').then($body => {
      if ($body.find('tbody tr td').length === 1 && $body.find('tbody tr td').text().includes('Nenhuma movimentação encontrada')) {
        cy.get('tbody tr td').first().should('contain', 'Nenhuma movimentação encontrada');
      }
    });
  });

  it('224 - Deve validar a estrutura de uma linha da tabela de resumo', () => {
    cy.get('table thead tr').within(() => {
      cy.get('th').should('have.length', 7);
      cy.get('th').eq(0).should('contain.text', 'Descrição');
      cy.get('th').eq(1).should('contain.text', 'Data Movimentação');
      cy.get('th').eq(2).should('contain.text', 'Data Pagamento');
      cy.get('th').eq(3).should('contain.text', 'Conta');
      cy.get('th').eq(4).should('contain.text', 'Valor');
      cy.get('th').eq(5).should('contain.text', 'Situação');
      cy.get('th').eq(6).should('contain.text', 'Ações');
    });
  });

  it('225 - Deve permitir alterar mês e ano e manter resultado coerente', () => {
    const anoAlvo = (new Date().getFullYear() - 1).toString();
    cy.get('#mes').select('1'); // Janeiro
    cy.get('#ano').select(anoAlvo);
    cy.get('button[type="submit"]').click();
    cy.url().should('include', 'mes=1').and('include', `ano=${anoAlvo}`);
  });

  it('226 - Deve exibir mensagem apropriada para filtros sem resultados', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2026'); // Supondo que não há dados
    cy.get('#tipo').select('todos');
    cy.get('button[type="submit"]').click();
    cy.contains('Nenhuma movimentação encontrada para este período.').should('be.visible');
  });
});

describe.only('Validar resumos mensal', () => {
  beforeEach(() => {
    cy.session('sessao-resumo-validacao', () => {
      LoginPage.login('resumo.movimento@resumo.com', 'login_10');
      cy.url().should('include', '/home');
    });
    cy.visit('/resumo');
  });

  it('227 - Deve filtrar corretamente por tipo "Receitas"', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('receita');
    // --- CORREÇÃO AQUI ---
    cy.contains('button', 'Buscar').click(); // Seleciona o botão pelo seu texto
    // --- FIM DA CORREÇÃO ---
    cy.url().should('include', 'tipo=receita');
    cy.get('tbody tr').each($tr => {
      cy.wrap($tr).find('td:nth-child(5)').should('have.class', 'positive-value');
    });
  });

  it('228 - Deve filtrar corretamente por tipo "Despesas"', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('despesa');
    cy.contains('button', 'Buscar').click(); // CORREÇÃO AQUI
    cy.url().should('include', 'tipo=despesa');
    cy.get('tbody tr').each($tr => {
        cy.wrap($tr).find('td:nth-child(5)').should('have.class', 'negative-value');
    });
  });

  it('229 - Deve manter filtros selecionados na URL após busca', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('despesa');
    cy.contains('button', 'Buscar').click(); // CORREÇÃO AQUI
    cy.url().should('include', 'mes=1').and('include', 'ano=2025').and('include', 'tipo=despesa');
  });

  it('230 - Deve exibir mensagem apropriada para filtros sem resultados', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2020');
    cy.get('#tipo').select('receita');
    cy.contains('button', 'Buscar').click(); // CORREÇÃO AQUI
    cy.contains('Nenhuma movimentação encontrada para este período.').should('be.visible');
  });

  it('231 - Deve filtrar por mês 01/2025 e tipo receita e validar movimentações', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('receita');
    cy.contains('button', 'Buscar').click(); // CORREÇÃO AQUI
    cy.get('tbody tr').each(($tr) => {
      cy.wrap($tr).within(() => {
        cy.get('td').eq(1).invoke('text').should('match', /^2025-01-\d{2}$/);
        cy.get('td').eq(4).should('have.class', 'positive-value');
        cy.get('td').eq(5).should('contain.text', 'Pago');
      });
    });
  });

  it('232 - Deve filtrar por mês 02/2025 e tipo despesa e validar movimentações', () => {
    cy.get('#mes').select('2');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('despesa');
    cy.contains('button', 'Buscar').click(); // CORREÇÃO AQUI
    cy.get('tbody tr').each(($tr) => {
      cy.wrap($tr).within(() => {
        cy.get('td').eq(1).invoke('text').should('match', /^2025-02-\d{2}$/);
        cy.get('td').eq(4).should('have.class', 'negative-value');
        cy.get('td').eq(5).should('contain.text', 'Pendente');
      });
    });
  });

  it('233 - Deve carregar o resumo de Março de 2025 (Receitas) diretamente via URL', () => {
    cy.visit('/resumo?mes=3&ano=2025&tipo=receita');
    cy.get('#mes').should('have.value', '3');
    cy.get('#ano').should('have.value', '2025');
    cy.get('#tipo').should('have.value', 'receita');
    cy.contains('td', 'Venda H').should('be.visible');
    cy.contains('td', 'Venda C').should('be.visible');
    // --- CORREÇÃO AQUI: Mudando a expectativa de 8 para 9 ---
    cy.get('table tbody tr').should('have.length', 9); // Agora espera 9 linhas
    // --- FIM DA CORREÇÃO ---
    cy.contains('td', 'Compra Z').should('not.exist');
  });

  it('234 - Deve exibir todas as 7 movimentações de Janeiro de 2025 (Receita e Despesa)', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('todos');
    cy.get('.btn-primary').contains('Buscar').click();
    cy.url().should('include', 'mes=1').and('include', 'ano=2025').and('include', 'tipo=todos');
    const movimentacoesEsperadas = ['Compra D', 'Venda F', 'Venda A'];
    cy.get('tbody tr').should('have.length.at.least', movimentacoesEsperadas.length);
    movimentacoesEsperadas.forEach(desc => {
      cy.contains('td', desc).should('be.visible');
    });
  });

  it('235 - Deve exibir apenas as despesas de Janeiro de 2025 (1 movimentações)', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('despesa');
    cy.contains('button', 'Buscar').click();
    cy.get('tbody tr').should('have.length', 1);
    cy.contains('td', 'Compra D').should('be.visible');
  });
});

describe('Exclusão de Movimentação', () => {
  const USER_EMAIL = 'resumo.excluir@resumoexcluir.com';
  const USER_PASSWORD = 'login_10';
  let dynamicMovDescription; // Declara a variável no escopo do describe

  beforeEach(() => {
    // 1. Usa cy.session para o LOGIN
    cy.session(`sessao-exclusao`, () => {
      LoginPage.login(USER_EMAIL, USER_PASSWORD);
      cy.url().should('include', '/home');
    });

    const today = Cypress.moment().format('YYYY-MM-DD'); 
    // 2. CRIA os dados de teste ANTES de cada `it()`
    
    // *** CORREÇÃO: Usa crases (``) para criar a string dinâmica ***
    dynamicMovDescription = `Movimento para Excluir ${Cypress._.uniqueId()}`;
    
    MovimentacaoPage.visitar();
    
    // Preenche o formulário usando os métodos do Page Object
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.preencherDataMovimentacao(today);
    MovimentacaoPage.preencherDataPagamento(today);
    
    // *** CORREÇÃO: Passa a variável com o valor já resolvido ***
    MovimentacaoPage.preencherDescricao(dynamicMovDescription); 
    
    MovimentacaoPage.preencherInteressado('Cliente A');
    MovimentacaoPage.preencherValor(250.75);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    
    cy.url().should('include', '/resumo');
    cy.contains('Despesa incluída com sucesso!').should('exist');
    
    // 3. Visita a página de resumo para o teste começar no lugar certo
    cy.visit('/resumo');
  });

  it('236 - Deve cancelar exclusão se usuário negar confirmação', () => {
    cy.contains('td', dynamicMovDescription).should('be.visible');
    cy.on('window:confirm', () => false); // Nega a confirmação
    cy.contains('td', dynamicMovDescription).parent('tr').find('button.btn-danger').click();
    cy.contains('td', dynamicMovDescription).should('be.visible'); // Movimentação ainda existe
  });

  it('237 - Deve excluir uma movimentação com sucesso', () => {
    cy.contains('td', dynamicMovDescription).should('be.visible');
    cy.on('window:confirm', () => true); // Aceita a confirmação
    cy.contains('td', dynamicMovDescription).parent('tr').find('button.btn-danger').click();
    cy.contains('Movimentação excluída com sucesso!').should('be.visible');
    cy.contains('td', dynamicMovDescription).should('not.exist'); // Movimentação foi excluída
  });
});
