describe('Cadastro de Usuário - Testes Funcionais', () => {

  beforeEach(() => {
    cy.visit('/cadastro');
  });

  // --- 94 a 96: Validação campos obrigatórios ---

  it('97 - Não deve permitir cadastro apenas com email', () => {
    cy.get('input[name="email"]').type('saltototal@saldotota.com');
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  it('98 - Não deve permitir cadastro apenas com senha', () => {
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  it('99 - Não deve permitir cadastro apenas com nome', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  // --- 97 a 102: Validação formato e existência do email ---

  it('100 - Não deve aceitar email inválido (sem @)', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('input[name="email"]').type('emailinvalido.com');
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/email inválido/i).should('exist');
  });

  it('101 - Não deve aceitar email inválido (sem domínio)', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('input[name="email"]').type('email@');
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/email inválido/i).should('exist');
  });

  it('102 - Não deve aceitar email já existente', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('input[name="email"]').type('saltototal@saldotota.com'); // Email previamente cadastrado no DB de teste
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/Endereço de email já utilizado./i).should('exist');
  });

  it('103 - Deve aceitar email válido e novo', () => {
    const novoEmail = `novoemail${Date.now()}@exemplo.com`;
    cy.get('input[name="nome"]').type('Novo Usuário');
    cy.get('input[name="email"]').type(novoEmail);
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  // --- 101 a 107: Validação da senha ---

  it('104 - Não deve aceitar senha com menos de 8 caracteres', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Ab1!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve ter entre 8 e 10 caracteres/i).should('exist');
  });

  it('105 - Não deve aceitar senha com mais de 10 caracteres', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Ab1!Ab1!Ab1!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve ter entre 8 e 10 caracteres/i).should('exist');
  });

  it('106 - Não deve aceitar senha sem letra', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('12345678!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve conter pelo menos uma letra/i).should('exist');
  });

  it('107 - Não deve aceitar senha sem número', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Senha!!!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve conter pelo menos um número/i).should('exist');
  });

  it('108 - Não deve aceitar senha sem caractere especial', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Senha1234');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve conter pelo menos um caractere especial/i).should('exist');
  });

  it('109 - Não deve aceitar senha com espaço em branco', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Senha 123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha não pode conter espaços/i).should('exist');
  });

  it('110 - Deve aceitar senha válida conforme critérios', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc1230!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  // --- 108 a 111: Validação do nome ---
  it('111 - Não deve aceitar nome com caracteres numéricos', () => {
    cy.get('input[name="nome"]').type('João123');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Nome deve conter apenas letras./i).should('exist');
  });

  it('112 - Não deve aceitar nome com caracteres especiais', () => {
    cy.get('input[name="nome"]').type('João@#!');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Nome deve conter apenas letras/i).should('exist');
  });

  it('113 - Deve aceitar nome com espaços e acentos', () => {
    cy.get('input[name="nome"]').type('João da Silva');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  it('114 - Nome muito longo (mais de 50 caracteres) deve apresentar erro', () => {
    const longName = 'A'.repeat(51);
    cy.get('input[name="nome"]').type(longName);
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Máximo de 50 caracteres no nome/i).should('exist');
  });

  // --- 115 a 117: Botão mostrar/ocultar senha ---
  it('115 - Botão mostrar senha altera input para texto e atualiza aria-label', () => {
    cy.get('input[name="senha"]').should('have.attr', 'type', 'password');
    cy.get('#togglePassword').click();
    cy.get('input[name="senha"]').should('have.attr', 'type', 'text');
    cy.get('#togglePassword').should('have.attr', 'aria-label', 'Ocultar senha');
  });

  it('116 - Botão ocultar senha altera input para password e atualiza aria-label', () => {
    cy.get('#togglePassword').click(); // mostrar
    cy.get('#togglePassword').click(); // ocultar
    cy.get('input[name="senha"]').should('have.attr', 'type', 'password');
    cy.get('#togglePassword').should('have.attr', 'aria-label', 'Mostrar senha');
  });

  it('117 - Botão mostrar/ocultar senha não submete o formulário', () => {
    cy.get('#togglePassword').click();
    cy.url().should('include', '/cadastro');
  });

  // --- 121 a 125: Submissão do formulário e UX ---
  it('118 - Formulário com dados válidos realiza cadastro com sucesso', () => {
    cy.get('input[name="nome"]').type('Usuário Completo');
    cy.get('input[name="email"]').type(`usuario${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc1234!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  it('119 - Navegação entre campos via tecla Tab funciona corretamente', () => {
    cy.get('input[name="nome"]').focus().tab();
    cy.focused().should('have.attr', 'name', 'email');
    cy.focused().tab();
    cy.focused().should('have.attr', 'name', 'senha');
    cy.focused().tab();
    cy.focused().should('have.id', 'togglePassword');
  });

  it('120 - Submissão via tecla Enter dispara o envio do formulário', () => {
    cy.get('input[name="nome"]').type('Usuário');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc1234!@#{enter}');
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  it('121 - Senha com 7 caracteres deve apresentar erro', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!'); // 7 caracteres
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve ter entre 8 e 10 caracteres/i).should('exist');
  });

  it('122- Senha com 8 caracteres deve cadastrar com sucesso', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@'); // 8 caracteres
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login/i).should('exist');
  });

  it('123- Senha com 9 caracteres deve cadastrar com sucesso', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#'); // 9 caracteres
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login/i).should('exist');
  });
});
