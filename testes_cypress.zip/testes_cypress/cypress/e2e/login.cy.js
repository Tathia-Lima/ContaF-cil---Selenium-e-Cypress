// Testes para a página de login da aplicação ContaFacil
// Arquivo: login.cy.js

describe('Página de Login', () => {
  beforeEach(() => {
    // Visita a página de login antes de cada teste
    cy.visit('/login');
  });

  // Testes de elementos e textos
  describe('Verificação de elementos e textos', () => {
    it('36 - deve exibir o título da página corretamente', () => {
      cy.title().should('eq', 'ContaFácil - Login');
    });

    it('37 - deve exibir o logo da aplicação', () => {
      cy.get('.brand').should('contain', 'ContaFácil');
      cy.get('.fas.fa-coins').should('be.visible');
    });

    it('38 - deve exibir o formulário de login com campos corretos', () => {
      cy.get('label').first().should('contain', 'Email');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('label').eq(1).should('contain', 'Senha');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });

    it('39 - deve exibir o link para cadastro de novo usuário', () => {
      cy.get('a').contains('Novo usuário').should('be.visible');
    });
  });

  // Testes de cores e estilos
  describe('Verificação de cores e estilos', () => {
    it('40 - deve ter o fundo da página na cor correta', () => {
      cy.get('body').should('have.css', 'background-color', 'rgb(26, 26, 26)');
    });

    it('41 - deve ter o título de login na cor dourada', () => {
      cy.get('h2').should('have.css', 'color', 'rgb(255, 215, 0)');
    });

    it('42 - deve ter o botão de login com a cor de fundo correta', () => {
      cy.get('button').contains('Entrar')
        .should('have.css', 'background-color', 'rgb(255, 215, 0)');
    });

    it('43 - deve ter os campos de input com o estilo correto', () => {
      cy.get('input[placeholder="Email"]')
        .should('have.css', 'background-color', 'rgb(51, 51, 51)')
        .should('have.css', 'border-color', 'rgb(68, 68, 68)');
    });

    it('44 - deve ter os labels com a cor correta', () => {
      cy.get('label').first()
        .should('have.css', 'color', 'rgb(255, 215, 0)');
    });

    it('45 - deve ter os links com a cor correta', () => {
      cy.get('a').first()
        .should('have.css', 'color', 'rgb(255, 215, 0)');
    });
  });

  // Testes de funcionalidade de login
 describe('Funcionalidade de login', () => {
  it('46 - deve exibir mensagem de erro ao tentar login com campos vazios', () => {
    cy.visit('/login');
    // Intercepta o alerta do navegador e verifica seu conteúdo
    cy.on('window:alert', (txt) => {
      expect(txt).to.equal('Preencha todos os campos');
    });
    // Clica no botão "Entrar" sem preencher os campos
    cy.get('button').contains('Entrar').click();
  });


  it('47 - deve exibir mensagem nativa do navegador para email inválido', () => {
    cy.visit('/login');
    // Preenche o campo de email com valor inválido
    cy.get('input[placeholder="Email"]').type('emailinvalido');
    cy.get('input[placeholder="Senha"]').type('senha123');
    // Clica no botão "Entrar"
    cy.get('button').contains('Entrar').click();
    // Verifica a mensagem nativa do navegador
    cy.get('input[placeholder="Email"]').then(($input) => {
      const validationMessage = $input[0].validationMessage;
      expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });
  });

    it('48 - deve exibir mensagem de erro ao tentar login com email inexistente', () => {
      cy.visit('/login');
      // Preenche email e senha inválidos
      cy.get('input[placeholder="Email"]').type('email_inexistente@teste.com');
      cy.get('input[placeholder="Senha"]').type('senha_errada');
      // Clica no botão "Entrar"
      cy.get('button').contains('Entrar').click();
      // Verifica se a mensagem de erro aparece dentro da área de login
      cy.get('.alert') // ou outro seletor apropriado para a mensagem de erro
      cy.contains('Email ou senha inválidos.')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    });

    it('49 - deve exibir mensagem de erro ao tentar login com senha incorreta', () => {
      // Assumindo que existe um usuário com este email no sistema
      cy.get('input[placeholder="Email"]').type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').type('senha_incorreta');
      cy.get('button').contains('Entrar').click();
      // Verifica se a mensagem de erro aparece dentro da área de login
      cy.get('.alert') // ou outro seletor apropriado para a mensagem de erro
      cy.contains('Email ou senha inválidos.')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    });

  it('50 - deve realizar login com sucesso usando credenciais válidas', () => {
    cy.visit('/login'); // Garante que começa na página de login

    // Preenche credenciais válidas
    cy.get('input[placeholder="Email"]').type('LoginPage@LoginPage.com'); 
    cy.get('input[placeholder="Senha"]').type('login_10');
    cy.get('button').contains('Entrar').click();
    // Verifica se foi redirecionado para a página inicial
    cy.url().should('include', '/home');
    // Verifica se a mensagem esperada está visível na Home
    cy.get('h1').should('contain.text', 'ContaFácil - Página Inicial');
    });
  });

  // Testes de validação de formulário
  describe('Validação de formulário', () => {
  it('51 - deve validar o formato do email', () => {
    cy.get('input[placeholder="Email"]').type('email_invalido');
    cy.get('input[placeholder="Senha"]').type('senha123');
    cy.get('button').contains('Entrar').click();
    // Verifica a mensagem nativa do navegador
    cy.get('input[placeholder="Email"]').then(($input) => {
    const validationMessage = $input[0].validationMessage;
    expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });
  });
});

// Testes de segurança
describe('Segurança', () => {
  beforeEach(() => {
    cy.visit('/login'); // Visita a página antes de cada teste
  });
  it('52 - deve bloquear na 6ª tentativa consecutiva após 5 tentativas falhas', () => {
    // Executa as 5 primeiras tentativas (i = 0 a 4)
    for (let i = 0; i < 5; i++) {
      cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').clear().type('senha_incorreta' + i);
      cy.get('button').contains('Entrar').click();
      cy.wait(500);
      // Nas primeiras 5 tentativas espera a mensagem padrão de erro
      cy.get('.alert')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    }
    // 6ª tentativa - deve exibir a mensagem de bloqueio
    cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
    cy.get('input[placeholder="Senha"]').clear().type('senha_incorreta6');
    cy.get('button').contains('Entrar').click();
    // Espera a mensagem de bloqueio na 6ª tentativa
    cy.get('.alert')
      .should('be.visible')
      .and('contain', 'Muitas tentativas. Tente novamente mais tarde.');
  });

  it('53 - não deve bloquear após 4 tentativas consecutivas', () => {
    // Executa 4 tentativas (i = 0 a 3)
    for (let i = 0; i < 4; i++) {
      cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').clear().type('senha_incorreta' + i);
      cy.get('button').contains('Entrar').click();
      cy.wait(500);

      // Espera a mensagem padrão de senha inválida em todas essas tentativas
      cy.get('.alert')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    }
  });

  it('54 - não deve armazenar senha em texto simples no localStorage ou sessionStorage', () => {
    cy.get('input[placeholder="Email"]').type('usuario@teste.com');
    cy.get('input[placeholder="Senha"]').type('senha123');
    cy.get('button').contains('Entrar').click();
    // Verifica se a senha não está armazenada em texto simples
    cy.window().then((win) => {
      const localStorageItems = Object.keys(win.localStorage).map(key => win.localStorage.getItem(key));
      const sessionStorageItems = Object.keys(win.sessionStorage).map(key => win.sessionStorage.getItem(key));
      expect(localStorageItems.includes('senha123')).to.be.false;
      expect(sessionStorageItems.includes('senha123')).to.be.false;
    });
  });

  it('55 - bloqueia o usuário após várias tentativas de login erradas, 7 tentativas', () => {
    for (let i = 0; i < 6; i++) {
      cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').clear().type('senha_errada');
      cy.get('button').contains('Entrar').click();
      cy.wait(500);
    }
    cy.get('.alert').should(($el) => {
      const text = $el.text().toLowerCase();
      expect(
        text.includes('bloqueado') || text.includes('tente novamente mais tarde')
      ).to.be.true;
    });
  });

   //Teste simples de injeção SQL no login
  it('56 - não permite login com payload de injeção SQL', () => {
    cy.visit('/login');
    // Digita um payload inválido no campo email
    cy.get('input[placeholder="Email"]').type(`' OR '1'='1`);
    // Tenta submeter o formulário
    cy.get('button[type="submit"]').click();
    // Verifica a mensagem de validação nativa do navegador
    cy.get('input[placeholder="Email"]').then(($input) => {
      const validationMessage = $input[0].validationMessage;
      expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });
    // Opcional: pode verificar que URL não mudou, indicando que não houve login
    cy.url().should('include', '/login');
  });

  // Teste simples de XSS refletido no campo email
  it('57 - não executa script malicioso no campo email (XSS refletido)', () => {
    cy.visit('/login');
    const xssPayload = `<script>alert("XSS")</script>`;
    cy.get('#email').type(xssPayload);
    cy.get('#senha').type('qualquer');
    cy.get('button[type="submit"]').click();

    cy.on('window:alert', () => {
      throw new Error('XSS Vulnerabilidade detectada!');
    });
  });

  //Teste de logout invalida sessão e impede acesso à página protegida
  it('58 - impede acesso após logout', () => {
    cy.visit('/login');
    cy.get('#email').type('usuario@teste.com');
    cy.get('#senha').type('senha_correta');
    cy.get('button[type="submit"]').click();

    cy.visit('/logout');

    cy.visit('/home');
    cy.url().should('include', '/login');
  });

  //A rota não está correta para o /admin
  //Teste básico de autorização - impede acesso a páginas restritas
  //it.only('59 - não permite usuário comum acessar página admin', () => {
  //  cy.visit('/login');
  //  cy.get('#email').type('usuario@teste.com');
  //  cy.get('#senha').type('senha_correta');
  //  cy.get('button[type="submit"]').click();
  //  cy.visit('/admin');
  //  cy.contains(/Você precisa estar logado para acessar esta página./i).should('exist');
  //});

  //Teste básico de CSRF (exemplo simplificado)
  it('60 - não permite submissão de formulário sem token CSRF válido', () => {
    cy.request({
      method: 'POST',
      url: '/movimentacao',
      failOnStatusCode: false,
      form: true,
      body: {
        campo1: 'valor',
        campo2: 'valor'
      }
    }).then((response) => {
      expect(response.status).to.be.oneOf([400]);
      // Aqui validamos que a resposta contém as palavras 'CSRF' ou 'token'
      expect(response.body).to.satisfy(body => /csrf|token/i.test(body));
    });
  });

  it('61 - Deve retornar erro 400 quando o token CSRF não for enviado', () => {
    cy.request({
      method: 'POST',
      url: '/movimentacao',  // rota protegida
      failOnStatusCode: false, // para não falhar automaticamente no erro HTTP
      form: true,
      body: {
        // dados do formulário, mas sem o campo csrf_token
        campo1: 'valor1',
        campo2: 'valor2'
      }
    }).then((response) => {
      // Loga o status e o corpo no console do navegador
    console.log('Status:', response.status);
    console.log('Body:', response.body);
    // Também mostra no painel do Cypress (parte visual da execução do teste)
    cy.log('Status: ' + response.status);
    cy.log('Body: ' + response.body);
    // Validação real
    expect(response.status).to.eq(400);
    expect(response.body.toLowerCase()).to.include('csrf');
    })
  })
}); 
  // Testes de responsividade
  describe('Responsividade', () => {
    it('62 - deve exibir corretamente em tela de celular', () => {
      cy.viewport('iphone-x');
      cy.get('form').should('be.visible');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });

    it('63 - deve exibir corretamente em tela de tablet', () => {
      cy.viewport('ipad-2');
      cy.get('form').should('be.visible');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });

    it('64 - deve exibir corretamente em tela de desktop', () => {
      cy.viewport(1920, 1080);
      cy.get('form').should('be.visible');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });
  });
});

