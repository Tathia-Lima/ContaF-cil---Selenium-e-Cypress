// cypress/e2e/movimentacao.cy.js
import MovimentacaoPage from '../support/page_objects/MovimentacaoPage';

describe('Criação de Movimentações - Testes Funcionais', () => {
  beforeEach(() => {
    cy.session('user-session', () => {
      cy.visit('/login');
      cy.get('input[name=email]').type('resumo.movimento@resumo.com');
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    MovimentacaoPage.visitar();
    MovimentacaoPage.setupClockBasedOnServerDate();
  });

  it('Deve criar receita paga com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-04-16');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente A');
    MovimentacaoPage.preencherValor(650,65);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('Deve criar receita pendente com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-05-10');
    MovimentacaoPage.preencherDataPagamento('2025-07-01');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente B');
    MovimentacaoPage.preencherValor(350.75);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('Deve criar Despesa paga com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-05-23');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente C');
    MovimentacaoPage.preencherValor(750.00);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  }); 

  it('Deve criar Despesa Pendente com sucesso', () => {
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.preencherDataMovimentacao('2025-07-01');
    MovimentacaoPage.preencherDataPagamento('2025-07-01');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente D');
    MovimentacaoPage.preencherValor(200);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Despesa incluída com sucesso!').should('exist');
  }); 

  it('Deve criar receita paga com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-03-13');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente A');
    MovimentacaoPage.preencherValor(250.75);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('Deve criar receita pendente com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-05-10');
    MovimentacaoPage.preencherDataPagamento('2025-07-01');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente B');
    MovimentacaoPage.preencherValor(550.75);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

   it('Deve criar Despesa paga com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente C');
    MovimentacaoPage.preencherValor(350);
    MovimentacaoPage.selecionarConta('Conta 2');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  }); 

  it('last - Deve criar Despesa Pendente com sucesso', () => {
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-07-01');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente D');
    MovimentacaoPage.preencherValor(900);
    MovimentacaoPage.selecionarConta('Conta 2');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  }); 

    it('Deve criar receita paga com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente A');
    MovimentacaoPage.preencherValor(2100);
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('Deve criar receita pendente com sucesso', () => {
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-07-01');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente B');
    MovimentacaoPage.preencherValor(2550.75);
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

   it('Deve criar Despesa paga com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente C');
    MovimentacaoPage.preencherValor(3550);
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  }); 

  it('last - Deve criar Despesa Pendente com sucesso', () => {
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-07-01');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente D');
    MovimentacaoPage.preencherValor(700);
    MovimentacaoPage.selecionarConta('Conta 2');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  }); 

});
