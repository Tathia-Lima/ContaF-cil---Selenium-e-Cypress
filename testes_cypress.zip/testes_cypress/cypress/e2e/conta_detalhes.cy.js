import LoginPage from '../support/page_objects/loginPage';

describe('Página Conta Detalhes - Testes Funcionais e Segurança', () => {
  beforeEach(() => {
    cy.login('conta_detalhes@conta.com', 'login_10'); 
    cy.visit('/home'); 
    });

  it('252 - Saldo atual é exibido com formato correto e cor verde se positivo', () => {
    cy.contains('td', 'Conta 1')              // encontra a linha com nome da conta
          .parent('tr')                           // sobe para a linha completa
          .find('a.btn-primary')                  // localiza o botão Detalhes
          .invoke('removeAttr', 'target')         // remove o target="_blank"
          .click();                               // clica
      cy.url().should('include', '/contas/detalhes/');

      cy.get('.saldo-info div').should('be.visible').and(($div) => {
          expect($div.text().trim()).to.match(/^R\$ \d{1,3}(\.\d{3})*,\d{2}$/);
          expect($div.css('color')).to.match(/rgb\(0,\s?255,\s?0\)/);
      });
  });


  it('253 - Saldo atual exibe cor vermelha se saldo negativo', () => {
    cy.contains('td', 'Conta 4')
          .parent('tr')
          .find('a.btn-primary')
          .invoke('removeAttr', 'target')
          .click();
      cy.url().should('include', '/contas/detalhes/')

    cy.get('.saldo-info div').should('be.visible').and(($div) => {
      expect($div.css('color')).to.match(/rgb\(255,\s?(36|0),\s?0\)/);
    });
  });

  it('254 - Campos básicos da conta estão visíveis e corretos', () => {
    cy.contains('td', 'Conta 1')
          .parent('tr')
          .find('a.btn-primary')
          .invoke('removeAttr', 'target')
          .click();
      cy.url().should('include', '/contas/detalhes/')

    cy.contains('Nome da Conta:').next().should('not.be.empty');
    cy.contains('Tipo de Conta:').next().should('contain.text', 'Conta Corrente');
    cy.contains('Usuário da Conta:').next().should('not.be.empty');
    cy.contains('Data de Criação:').next().should('not.be.empty');
  });

  it('255 - Validar valor Receitas com retorno da API', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().then((url) => {
      const contaId = url.split('/').pop();

      cy.request(`/api/contas/${contaId}/totais`).then((response) => {
        expect(response.status).to.eq(200);
        const totalReceitasApi = response.body.total_receitas;

        cy.contains('Total de Receitas')
          .parent()
          .find('div')
          .invoke('text')
          .then((textoReceitas) => {
            const valorExibido = textoReceitas.replace(/[^\d,]/g, '').replace(',', '.');
            const valorExibidoNum = parseFloat(valorExibido);
            expect(valorExibidoNum).to.be.closeTo(totalReceitasApi, 0.01);
          });
      });
    });
  });

it('256 - Validar valor Despesas com retorno da API', () => {
  cy.contains('td', 'Conta 1')
    .parent('tr')
    .find('a.btn-primary')
    .invoke('removeAttr', 'target')
    .click();

  cy.url().then((url) => {
    const contaId = url.split('/').pop();

    cy.request(`/api/contas/${contaId}/totais`).then((response) => {
      expect(response.status).to.eq(200);
      const totalDespesasApi = response.body.total_despesas;

      cy.contains('Total de Despesas')
        .parent()
        .find('div')
        .invoke('text')
        .then((textoDespesas) => {
          const valorExibido = textoDespesas.replace(/[^\d,]/g, '').replace(',', '.');
          const valorExibidoNum = parseFloat(valorExibido);
          expect(valorExibidoNum).to.be.closeTo(totalDespesasApi, 0.01);
        });
    });
  });
});

it('257 - Validar Total de Movimentações com retorno da API', () => {
  cy.contains('td', 'Conta 2')
    .parent('tr')
    .find('a.btn-primary')
    .invoke('removeAttr', 'target')
    .click();

  cy.url().then((url) => {
    const contaId = url.split('/').pop();

    cy.request(`/api/contas/${contaId}/totais`).then((response) => {
      expect(response.status).to.eq(200);
      const totalMovimentacoesApi = response.body.total_movimentacoes;
      // Log para debug no Cypress e console do navegador
      cy.log(`Total de Movimentações da API: ${totalMovimentacoesApi}`);
      console.log('Total de Movimentações da API:', totalMovimentacoesApi);

      cy.contains('Total de Movimentações')
        .parent()
        .find('div')
        .invoke('text')
        .then((textoTotalMovs) => {
          const valorExibido = parseInt(textoTotalMovs.replace(/[^\d]/g, ''), 10);
          expect(valorExibido).to.eq(totalMovimentacoesApi);
        });
    });
  });
});

  it('258 - Validar Saldo Atual com base nos valores da API', () => {
    cy.contains('td', 'Conta 2')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().then((url) => {
      const contaId = url.split('/').pop();

      cy.request(`/api/contas/${contaId}/totais`).then((response) => {
        expect(response.status).to.eq(200);
        const { total_receitas, total_despesas } = response.body;
        const saldoCalculado = total_receitas - total_despesas;

        cy.contains('Saldo Atual')
          .parent()
          .find('div')
          .invoke('text')
          .then((textoSaldo) => {
            const valorExibido = textoSaldo.replace(/[^\d,-]/g, '').replace(',', '.');
            const valorExibidoNum = parseFloat(valorExibido);
            expect(valorExibidoNum).to.be.closeTo(saldoCalculado, 0.01);
          });
      });
    });
  });

  it('259 - Total de Receitas tem a cor verde', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/').then((url) => {
      const contaId = url.split('/').pop();
      cy.log('ID extraído da URL:', contaId);

      cy.request({
        url: `/api/contas/${contaId}/totais`,
        failOnStatusCode: false
      }).then((response) => {
        expect(response.status, 'Status da API').to.eq(200);

        cy.contains('Total de Receitas')
          .parent()
          .find('div.positive-value') 
          .should('have.css', 'color')
          .and('match', /rgb\(0,\s?255,\s?0\)/) // Verifica a cor verde
      });
    });
  });

  it('260 - Total de Despesas em vermelho', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/').then((url) => {
      const contaId = url.split('/').pop();

      // Agora faz a verificação da cor na página carregada
      cy.contains('Total de Despesas')
        .parent()
        .find('div.negative-value') // Continua buscando o div com a classe negative-value
        .should('have.css', 'color')
        .and('match', /rgb\(255,\s?(36|0),\s?0\)/); // Regex para #ff2400 ou #ff0000
    });
  });

  it('261 - Saldo Total em vermelho', () => {
    cy.contains('td', 'Conta 4')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/').then((url) => {
      const contaId = url.split('/').pop();

      // Agora faz a verificação da cor na página carregada
      cy.contains('Saldo Atual')
        .parent()
        .find('div.negative-value') // Continua buscando o div com a classe negative-value
        .should('have.css', 'color')
        .and('match', /rgb\(255,\s?(36|0),\s?0\)/); // Regex para #ff2400 ou #ff0000
    });
  });

  it('262 - Valida a quantidade de movimentações por página (máx. 10) e o total de páginas', () => {
    cy.contains('td', 'Conta 1')
    .parent('tr')
    .find('a.btn-primary')
    .invoke('removeAttr', 'target')
    .click();

    cy.url().should('include', '/contas/detalhes/').then((url) => {
    const contaId = url.split('/').pop();

    // Captura o total de páginas
    cy.get('.pagination .page-item:not(.disabled) a.page-link')
      .filter((index, el) => !isNaN(parseInt(Cypress.$(el).text())))
      .then(($pages) => {
        const totalPaginas = $pages.length;

        // Função recursiva para validar cada página
    const validarPagina = (paginaAtual) => {
    cy.get('.pagination .page-item').contains(paginaAtual.toString()).click();
    cy.url().should('include', `page=${paginaAtual}`);

    cy.get('table tbody tr').then(($rows) => {
      const qtdeMovs = $rows.length;
        if (paginaAtual < totalPaginas) {
                // Todas as páginas exceto a última devem ter exatamente 10
          expect(qtdeMovs).to.eq(10);
          } else {
                  // A última página pode ter até 10
          expect(qtdeMovs).to.be.at.most(10);
          }

          if (paginaAtual < totalPaginas) {
            validarPagina(paginaAtual + 1);
          }
        });
      };

        // Começa na página 1
        validarPagina(1);

          // Valida o número de páginas exibido
        expect(totalPaginas).to.be.gte(1);
      });
    });
  }); 

  it('263 - Valida a ordem decrescente das movimentações por data em todas as páginas', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/');

    // Função para verificar se as datas estão em ordem decrescente
    const checkDateOrder = () => {
      cy.get('table tbody tr td:first-child').then(($tds) => {
        const datas = [...$tds].map(td => new Date(td.innerText.trim()).getTime());

        for (let i = 0; i < datas.length - 1; i++) {
          expect(datas[i]).to.be.at.least(datas[i + 1]); // datas[i] >= datas[i+1]
        }
      });
    };

    // Captura total de páginas e itera nelas
    cy.get('.pagination .page-item:not(.disabled) a.page-link')
      .filter((index, el) => !isNaN(parseInt(Cypress.$(el).text())))
      .then(($pages) => {
        const totalPages = $pages.length;

        const validarPagina = (paginaAtual) => {
          cy.get('.pagination .page-item').contains(paginaAtual.toString()).click();
          cy.url().should('include', `page=${paginaAtual}`);
          checkDateOrder();

          if (paginaAtual < totalPages) {
            validarPagina(paginaAtual + 1);
          }
        };

        // Começa na página 1
        validarPagina(1);
      });
  });

  it('264 - Valida os botões de paginação (Anterior / Próximo / Números)', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/');

    // Na primeira página
    cy.url().should('not.include', 'page=');

    // Botão "Anterior" deve estar desabilitado
    cy.contains('.pagination .page-item', 'Anterior').should('have.class', 'disabled');
    cy.contains('.pagination a.page-link', 'Anterior').should('have.class', 'disabled-link');

    // Botão "Próximo" deve estar habilitado (se houver mais de uma página)
    cy.get('.pagination').then(($pagination) => {
      if ($pagination.find('a.page-link').filter((_, el) => el.textContent === 'Próximo').length > 0) {
        cy.contains('.pagination a.page-link', 'Próximo')
          .should('not.have.class', 'disabled-link')
          .click();

        cy.url().should('include', 'page=2');

        // Agora na página 2: botão "Anterior" deve estar habilitado
        cy.contains('.pagination .page-item', 'Anterior').should('not.have.class', 'disabled');
        cy.contains('.pagination a.page-link', 'Anterior').should('not.have.class', 'disabled-link');

        // Página 2 deve estar com classe "active"
        cy.contains('.pagination .page-item', '2').should('have.class', 'active');

        // Verifica se há uma página 3
        cy.get('.pagination').then(($pag) => {
          if ($pag.text().includes('3')) {
            // Se houver página 3, botão "Próximo" deve estar habilitado
            cy.contains('.pagination a.page-link', 'Próximo')
              .should('not.have.class', 'disabled-link')
              .click();

            cy.url().should('include', 'page=3');

            // Agora o botão "Próximo" deve estar desabilitado
            cy.contains('.pagination a.page-link', 'Próximo')
              .should('have.class', 'disabled-link');
          } else {
            // Se não houver página 3, botão "Próximo" já deve estar desabilitado
            cy.contains('.pagination a.page-link', 'Próximo')
              .should('have.class', 'disabled-link');
          }
        });
      } else {
        // Não há botão "Próximo", significa que só há uma página
        cy.log('Apenas uma página de resultados — sem paginação avançada');
      }
    });
  });
  
  it('265 - Situação tem cor verde para pago e amarelo para pendente', () => {
    cy.contains('td', 'Conta 3')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/');

    cy.get('table tbody tr').each(($row) => {
      cy.wrap($row).find('td').eq(4).within(() => {
        cy.get('span').invoke('text').then((texto) => {
          const situacao = texto.trim().toLowerCase();
            if (situacao === 'pago') {
              cy.get('span').should('have.css', 'color', 'rgb(0, 255, 0)');
            } else if (situacao === 'pendente') {
              cy.get('span').should('have.css', 'color', 'rgb(255, 152, 0)');
            } 
          });
      });
    });
  });

  it('266 - Botão Editar está presente em cada movimentação com link correto', () => {
    cy.contains('td', 'Conta 2')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/');

    // Aqui continua o teste na página de detalhes da conta clicada
    cy.get('table tbody tr').each(($row) => {
      cy.wrap($row)
        .find('td').eq(5)
        .find('a.btn-warning')
        .should('have.attr', 'href')
        .and('match', /\/movimentacao\/editar\//);
    });
  });

  it('267 - Exibe mensagem quando não há movimentações', () => {
    cy.contains('td', 'Conta 5')
          .parent('tr')
          .find('a.btn-primary')
          .invoke('removeAttr', 'target')         // remove o target="_blank"
          .click();
      cy.url().should('include', '/contas/detalhes/');
    cy.contains('Nenhuma movimentação encontrada para esta conta.').should('be.visible');
  });

  it('268 - Validar botão "Voltar para Contas"', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();
    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Detalhes da Conta').should('be.visible');

    cy.get('a.btn-secondary')
      .contains('Voltar para Contas')
      .should('have.attr', 'href')
      .and('match', /\/contas(\/listar)?$/);
    cy.get('a.btn-secondary').contains('Voltar para Contas').click();

    cy.url().should('include', '/contas');
    cy.contains('Contas Cadastradas').should('be.visible');
  });

  it('269 - Validar botão "Editar Conta"', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();
    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Detalhes da Conta').should('be.visible');

    cy.get('a.btn-warning')
      .contains('Editar Conta')
      .should('have.attr', 'href')
      .and('match', /\/contas\/editar\/\d+/);
    cy.get('a.btn-warning').contains('Editar Conta').click();

    cy.url().should('include', '/contas/editar/');
    cy.contains('Editar Conta').should('be.visible');
  });

  it('270 - Validar botão "Editar Movimentação"', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Detalhes da Conta').should('be.visible');

    // Botão 'Editar' para a movimentação
    cy.get('a.btn-warning')
      .contains('Editar')  // só "Editar" mesmo, pois o texto do botão é "Editar"
      .should('have.attr', 'href')
      .and('match', /\/movimentacao\/editar\/\d+/);

    // Clica no botão 'Editar'
    cy.get('a.btn-warning').contains('Editar').click();

    cy.url().should('include', '/movimentacao/editar/');
    cy.contains('Editar Movimentação').should('be.visible'); // texto da página de edição de movimentação
  });

  it('271 - Validar botão "Nova Movimentação"', () => {
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();
    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Detalhes da Conta').should('be.visible');

    cy.get('a.btn-success')
        .contains('Nova Movimentação')
        .should('have.attr', 'href')
        .and('eq', '/movimentacao');
    cy.get('a.btn-success').contains('Nova Movimentação').click();

    cy.url().should('include', '/movimentacao');
    cy.contains('Criar Movimentação').should('be.visible');
  });

  it('272 - Redireciona com mensagem se conta não pertence ao usuário', () => {
    cy.contains('td', 'Conta 1')              // encontra a linha com nome da conta
          .parent('tr')                           // sobe para a linha completa
          .find('a.btn-primary')                  // localiza o botão Detalhes
          .invoke('removeAttr', 'target')         // remove o target="_blank"
          .click();                               // clica
      cy.url().should('include', '/contas/detalhes/');

    cy.visit('/contas/detalhes/9999'); // Conta não existente ou não pertencente
    cy.contains('Conta não encontrada ou não pertence a você.').should('be.visible');
  });

  // TESTES DE SEGURANÇA
  it('273 - Acesso bloqueado para usuários não autenticados', () => {
    cy.contains('td', 'Conta 1')              // encontra a linha com nome da conta
          .parent('tr')                           // sobe para a linha completa
          .find('a.btn-primary')                  // localiza o botão Detalhes
          .invoke('removeAttr', 'target')         // remove o target="_blank"
          .click();                               // clica
    cy.url().should('include', '/contas/detalhes/');

    cy.clearCookies();
    cy.clearLocalStorage();

    cy.visit('/contas/detalhes/1');
    cy.url().should('include', '/login');
    cy.contains('Você precisa estar logado para acessar esta página.').should('be.visible');
  });

  it('274 - Usuário não pode acessar conta de outro usuário', () => {
    cy.login('conta_detalhes@conta.com', 'login_10')
    cy.visit('/contas/detalhes/5'); // Conta pertence a usuario1
    cy.contains('Conta não encontrada ou não pertence a você.').should('be.visible');
  });

  it('275 - Formulários possuem token CSRF', () => {
    cy.contains('td', 'Conta 1')              // encontra a linha com nome da conta
          .parent('tr')                           // sobe para a linha completa
          .find('a.btn-primary')                  // localiza o botão Detalhes
          .invoke('removeAttr', 'target')         // remove o target="_blank"
          .click();                               // clica
      cy.url().should('include', '/contas/detalhes/');

    cy.visit('/contas/detalhes/1');
    cy.get('form input[name="csrf_token"]').should('exist');
  });

  it('276 - Campos estão escapados e sem vulnerabilidade XSS', () => {
    // Clica no botão detalhes da Conta 4 na listagem, que abre a página correta para o usuário logado
    cy.contains('td', 'Conta 4')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Detalhes da Conta').should('be.visible');

    // Verifica se o conteúdo da seção não contém código malicioso <script>
    cy.get('.conta-info-grid').should('be.visible')
      .and(($el) => {
        expect($el.html()).not.to.include('<script>');
      });
  });
});
