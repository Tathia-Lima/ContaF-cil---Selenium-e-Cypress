import LoginPage from '../support/page_objects/loginPage';
import { gerarSufixo } from '../support/utils';

describe('Validação de Acessibilidade', () => {
  // 01 - Verifica se os labels estão associados corretamente aos inputs
  it('01 - Deve ter labels associados aos campos de formulário', () => {
    cy.visit('/login');
    cy.get('label[for="email"]').should('contain', 'Email');
    cy.get('#email').should('be.visible').and('have.attr', 'id', 'email');

    cy.get('label[for="senha"]').should('contain', 'Senha');
    cy.get('#senha').should('be.visible').and('have.attr', 'id', 'senha');
  });

  // 02 - Verifica a navegação por teclado via TAB
  it('02 - Deve permitir navegação por teclado', () => {
    cy.visit('/login');

    cy.get('#email').focus();
    cy.focused().should('have.id', 'email');

    cy.focused().tab();
    cy.focused().should('have.id', 'senha');

    cy.focused().tab();
    cy.focused().should('have.id', 'togglePassword');

    cy.focused().tab();
    cy.focused().should('contain.text', 'Entrar');
  });

  // 03 - Verifica contraste de cores básico para leitura confortável
  it('03 - Deve ter contraste adequado para leitura', () => {
    cy.visit('/login');
    cy.get('h2').should('have.css', 'color').and((color) => {
      expect(color).to.be.oneOf(['rgb(0, 0, 0)', 'rgb(255, 215, 0)', 'rgb(255, 235, 59)']);
    });
    cy.get('body').should('have.css', 'background-color').and((bg) => {
      expect(bg).to.be.oneOf(['rgb(255, 255, 255)', 'rgb(26, 26, 26)']);
    });
    cy.get('button').contains('Entrar').should('have.css', 'color');
    cy.get('button').contains('Entrar').should('have.css', 'background-color');
  });

  // 04 - Verifica se botão de mostrar/ocultar senha tem aria-label para acessibilidade
  it('04 - Botão toggle senha deve ter aria-label para screen readers', () => {
    cy.visit('/login');
    cy.get('#togglePassword')
      .should('have.attr', 'aria-label')
      .and('match', /mostrar|ocultar senha/i);
  });

  // 05 - Verifica se o formulário possui role="form" para melhor semântica
  it('05 - Formulário deve ter role="form"', () => {
    cy.visit('/login');
    cy.get('form').should('have.attr', 'role', 'form');
  });

  // 06 - Verifica que campos obrigatórios possuem atributo required
  it('06 - Campos obrigatórios devem ter atributo required', () => {
    cy.visit('/login');
    cy.get('#email').should('have.attr', 'required');
    cy.get('#senha').should('have.attr', 'required');
  });

  // 07 - Verifica se mensagens de erro estão associadas via aria-describedby
  it('07 - Mensagens de erro devem ser associadas via aria-describedby', () => {
    cy.visit('/login');
    cy.get('#email').should('have.attr', 'aria-describedby');
    cy.get('#senha').should('have.attr', 'aria-describedby');
  });

  // 08 - Verifica se os ícones têm textos alternativos ou aria-hidden
  it('08 - Ícones devem ter texto alternativo ou aria-hidden para acessibilidade', () => {
    cy.visit('/login');
    cy.get('button#togglePassword').then(($btn) => {
    const hasAriaLabel = $btn.attr('aria-label') !== undefined;
    const hasAriaHidden = $btn.attr('aria-hidden') !== undefined;

    expect(hasAriaLabel || hasAriaHidden).to.be.true;
    });
  });

  // 09 - Verifica se a página possui título (title) e cabeçalho (h2) claros
  it('09 - Deve possuir título da página e cabeçalho claros', () => {
    cy.visit('/login');
    cy.title().should('contain', 'ContaFácil - Login');
    cy.get('h2').should('contain.text', 'Login');
  });

  // 10 - Verifica se mensagens de erro são visíveis e compreensíveis 
  // o Cypress não consegue capturar mensagens de validação nativa diretamente, 
  // porque elas não são elementos reais no DOM. As mesmas soluções se aplicam:
  //Capturar validationMessage via JavaScript, com limitação de idioma;

  it('10 - Deve exibir mensagem de campo obrigatório ao tentar logar sem preencher o email', () => {
    cy.visit('/login');
    // Tenta clicar em "Entrar" sem preencher nada
    cy.get('button').contains('Entrar').click();
    // Acessa o input de email e valida a mensagem nativa
    cy.get('input[name="email"]') // ou outro seletor específico
      .then(($input) => {
        // Verifica a mensagem nativa do navegador
        const validationMessage = $input[0].validationMessage;
        expect(validationMessage).to.eq('Preencha este campo.');
      });
  });

  //Verificar foco visível nos elementos interativos
  // Garantir que o usuário visualiza onde está o foco durante a navegação por
  it('11 - Elementos interativos devem exibir foco visível', () => {
    cy.visit('/login');
    cy.get('#email').focus().should('have.css', 'outline-style').and('not.eq', 'none');
    cy.get('#senha').focus().should('have.css', 'outline-style').and('not.eq', 'none');
    cy.get('#togglePassword').focus().should('have.css', 'outline-style').and('not.eq', 'none');
    cy.get('button[type="submit"]').focus().should('have.css', 'outline-style').and('not.eq', 'none');
  });

 // 12 - Deve ativar o botão mostrar/ocultar senha com a tecla Enter
  it('12 - Deve ativar o botão mostrar/ocultar senha via teclado (Enter)', () => {
    cy.visit('/login');
    cy.get('#togglePassword').focus().type('{enter}');
    cy.get('#senha').should('have.attr', 'type').and('match', /(text|password)/);
  });

  // 13 - Deve ativar o botão mostrar/ocultar senha com a tecla Espaço
  it('13 - Deve ativar o botão mostrar/ocultar senha via teclado (Espaço)', () => {
    cy.visit('/login');
    cy.get('#togglePassword').focus().type(' ');
    cy.get('#senha').should('have.attr', 'type').and('match', /(text|password)/);
  });

  // 14 - Deve ativar o botão Entrar com a tecla Enter
  it('14 - Deve ativar o botão Entrar via teclado (Enter)', () => {
    cy.visit('/login');
    cy.get('#email').type('LoginPage@LoginPage.com');
    cy.get('#senha').type('login_10');
    cy.get('button[type="submit"]').focus().type('{enter}');
    cy.url().should('not.include', '/login');
  });

  // 15 - Deve ativar o botão Cadastrar novo usuário com a tecla Enter
  it('15 - Deve ativar o link Novo usuário via teclado (Enter) e validar título Cadastro de Usuário', () => {
    cy.visit('/login');
    // Foca no link e valida que ele está focável
    cy.contains('Novo usuário').focus().should('have.focus');
    // Clica para garantir navegação
    cy.contains('Novo usuário').click();
    // Valida URL e título da página de cadastro
    cy.url().should('include', '/cadastro');
    cy.get('h1').should('contain.text', 'Cadastro de Usuário');
  });

  it('16 - deve alternar para o campo de senha ao pressionar Tab', () => {
    cy.visit('/login');
    cy.get('input[placeholder="Email"]').focus().tab();
    cy.get('input[placeholder="Senha"]').should('have.focus');
  });

  it('17 - deve mostrar/ocultar a senha ao clicar no ícone de olho', () => {
    cy.visit('/login');
    cy.get('input[placeholder="Senha"]').type('senha123');
    cy.get('input[placeholder="Senha"]').should('have.attr', 'type', 'password');
    // Clica no botão de mostrar senha (ícone de olho)
    cy.get('#togglePassword').click();;
    cy.get('input[placeholder="Senha"]').should('have.attr', 'type', 'text');
    // Clica novamente para ocultar
    cy.get('#togglePassword').click();;
    cy.get('input[placeholder="Senha"]').should('have.attr', 'type', 'password');
  });
});  

describe('Acessibilidade - Página Home', () => {

  beforeEach(() => {
    // Usa cy.session para manter login entre testes
    cy.session('user-session', () => {
    LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/home');
  });

  it('18 - Deve conter cabeçalho com texto acessível', () => {
    cy.get('h2').should('contain.text', 'Olá, LoginPage! Seja bem-vindo(a) ao ContaFácil');
  });

  it('19 - Deve conter uma tabela com títulos claros e identificáveis', () => {
    cy.get('table').should('exist');
    cy.get('table thead th').eq(0).should('contain.text', 'Conta');
    cy.get('table thead th').eq(1).should('contain.text', 'Receitas');
    cy.get('table thead th').eq(2).should('contain.text', 'Despesas');
    cy.get('table thead th').eq(3).should('contain.text', 'Saldo');
  });

  it('20 - Deve permitir navegação por teclado com foco visível', () => {
    cy.get('body').tab();
    cy.focused().should('be.visible');
  });

  it('21 - Deve passar nas verificações automáticas do axe-core', () => {
    cy.injectAxe();
    cy.checkA11y(); 
  });

  it('22 - Todos os elementos interativos devem ser acessíveis por teclado', () => {
    cy.get('button, a, input, select, textarea')
      .each(($el) => {
        cy.wrap($el).focus().should('have.focus');
      });
  });

  it('23 - Elementos devem possuir contraste adequado', () => {
    cy.injectAxe();
    cy.checkA11y(null, {
    runOnly: ['color-contrast'],
    });
  });

  it('24 - Botões devem conter texto ou aria-label', () => {
    cy.get('button').each(($btn) => {
      cy.wrap($btn).should(($el) => {
        const hasText = $el.text().trim().length > 0;
        const hasAria = $el.attr('aria-label') !== undefined;
        expect(hasText || hasAria).to.be.true;
      });
    });
  });

  it('25 - Links devem ser descritivos (sem textos como "clique aqui")', () => {
    cy.get('a').each(($a) => {
      cy.wrap($a).invoke('text').should('match', /[^\s]+/);
      cy.wrap($a).should('not.contain.text', 'clique aqui');
    });
  });

  it('26 - Página deve possuir uma linguagem definida no HTML', () => {
    cy.document().its('documentElement.lang').should('match', /^[a-z]{2}(-[A-Z]{2})?$/);
  });

  it('27 - Página não requer foco inicial automático, teste ignorado', () => {
    cy.log('Foco inicial não é necessário nesta página porque o usuário deve decidir a ação.');
  });

  it('28 - Nenhum elemento deve estar com tabindex="-1" indevidamente', () => {
    cy.get('body').then(($body) => {
      if ($body.find('[tabindex="-1"]').length > 0) {
        // Pode-se fazer lógica para verificar se está em contexto aceitável, ex: aria-live
        cy.get('[tabindex="-1"]').each($el => {
          cy.wrap($el).should('have.attr', 'aria-live'); // Exemplo de uso aceitável
        });
      } else {
        cy.log('Nenhum tabindex="-1" encontrado. Teste aprovado.');
      }
    });
  });
});

describe('Acessibilidade - Página Home', () => {

  beforeEach(() => {
    // Usa cy.session para manter login entre testes
    cy.session('user-session', () => {
      LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/home');
  });

  it('29 - Deve clicar no menu ContaFácil e abrir home', () => {
    cy.get('a.brand').click();
    cy.url().should('include', '/home');
  });

  it('30 - Deve abrir a página home pelo menu', () => {
    cy.get('a').contains('Home').click();
    cy.url().should('include', '/home');
  });

  it('31 - Deve abrir página Contas > Adicionar', () => {
    cy.get('.dropdown .dropbtn').contains('Contas').click();
    cy.get('.dropdown-content a').contains('Adicionar').click();
    cy.url().should('include', '/contas/adicionar');
  });

  // Continue para os demais links, ex:
  it('32 - Deve abrir página Contas > Listar', () => {
    cy.visit('/home');
    cy.get('.dropdown .dropbtn').contains('Contas').click();
    cy.get('.dropdown-content a').contains('Listar').click();
    // Ajuste a URL esperada conforme sua aplicação
    cy.url().should('include', '/contas'); // ou '/contas/listar' se for o correto
    // Valide o título da página, para garantir que a lista foi carregada
    cy.get('h2').should('contain.text', 'Contas Cadastradas');
  });

  it('33 - Deve abrir página Criar Movimentação', () => {
    cy.get('a').contains('Criar Movimentação').click();
    cy.url().should('include', '/movimentacao');
  });

  it('34 - Deve abrir página Resumo Mensal', () => {
    cy.get('a').contains('Resumo Mensal').click();
    cy.url().should('include', '/resumo');
  });

  it('35 - Deve clicar em sair e ir para login', () => {
    cy.get('a').contains('Sair').click();
    cy.url().should('include', '/login');
  });
});

// Testes para a página de login da aplicação ContaFacil
// Arquivo: login.cy.js

describe('Página de Login', () => {
  beforeEach(() => {
    // Visita a página de login antes de cada teste
    cy.visit('/login');
  });

  // Testes de elementos e textos
  describe('Verificação de elementos e textos', () => {
    it('36 - deve exibir o título da página corretamente', () => {
      cy.title().should('eq', 'ContaFácil - Login');
    });

    it('37 - deve exibir o logo da aplicação', () => {
      cy.get('.brand').should('contain', 'ContaFácil');
      cy.get('.fas.fa-coins').should('be.visible');
    });

    it('38 - deve exibir o formulário de login com campos corretos', () => {
      cy.get('label').first().should('contain', 'Email');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('label').eq(1).should('contain', 'Senha');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });

    it('39 - deve exibir o link para cadastro de novo usuário', () => {
      cy.get('a').contains('Novo usuário').should('be.visible');
    });
  });

  // Testes de cores e estilos
  describe('Verificação de cores e estilos', () => {
    it('40 - deve ter o fundo da página na cor correta', () => {
      cy.get('body').should('have.css', 'background-color', 'rgb(26, 26, 26)');
    });

    it('41 - deve ter o título de login na cor dourada', () => {
      cy.get('h2').should('have.css', 'color', 'rgb(255, 215, 0)');
    });

    it('42 - deve ter o botão de login com a cor de fundo correta', () => {
      cy.get('button').contains('Entrar')
        .should('have.css', 'background-color', 'rgb(0, 123, 255)');
    });

    it('43 - deve ter os campos de input com o estilo correto', () => {
      cy.get('input[placeholder="Email"]')
        .should('have.css', 'background-color', 'rgb(51, 51, 51)')
        .should('have.css', 'border-color', 'rgb(68, 68, 68)');
    });

    it('44 - deve ter os labels com a cor correta', () => {
      cy.get('label').first()
        .should('have.css', 'color', 'rgb(255, 215, 0)');
    });

    it('45 - deve ter os links com a cor correta', () => {
      cy.get('a').first()
        .should('have.css', 'color', 'rgb(255, 215, 0)');
    });
  });

  // Testes de funcionalidade de login
 describe('funcionalidade de login', () => {
  it('46 - deve exibir mensagem de erro ao tentar login com campos vazios', () => {
    it('deve exibir alerta ao tentar login com campos vazios', () => {
    // Visita a página de login
    cy.visit('/login');
    // Intercepta o alerta do navegador e verifica seu conteúdo
    cy.on('window:alert', (txt) => {
      expect(txt).to.equal('Preencha todos os campos');
    });
    // Clica no botão "Entrar" sem preencher os campos
    cy.get('button').contains('Entrar').click();
    });
  });

  it('47 - deve exibir mensagem nativa do navegador para email inválido', () => {
    cy.visit('/login');
    // Preenche o campo de email com valor inválido
    cy.get('input[placeholder="Email"]').type('emailinvalido');
    cy.get('input[placeholder="Senha"]').type('senha123');
    // Clica no botão "Entrar"
    cy.get('button').contains('Entrar').click();
    // Verifica a mensagem nativa do navegador
    cy.get('input[placeholder="Email"]').then(($input) => {
      const validationMessage = $input[0].validationMessage;
      expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });
  });

    it('48 - deve exibir mensagem de erro ao tentar login com email inexistente', () => {
      cy.visit('/login');
      // Preenche email e senha inválidos
      cy.get('input[placeholder="Email"]').type('email_inexistente@teste.com');
      cy.get('input[placeholder="Senha"]').type('senha_errada');
      // Clica no botão "Entrar"
      cy.get('button').contains('Entrar').click();
      // Verifica se a mensagem de erro aparece dentro da área de login
      cy.get('.alert') // ou outro seletor apropriado para a mensagem de erro
      cy.contains('Email ou senha inválidos.')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    });

    it('49 - deve exibir mensagem de erro ao tentar login com senha incorreta', () => {
      // Assumindo que existe um usuário com este email no sistema
      cy.get('input[placeholder="Email"]').type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').type('senha_incorreta');
      cy.get('button').contains('Entrar').click();
      // Verifica se a mensagem de erro aparece dentro da área de login
      cy.get('.alert') // ou outro seletor apropriado para a mensagem de erro
      cy.contains('Email ou senha inválidos.')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    });

  it('50 - deve realizar login com sucesso usando credenciais válidas', () => {
    cy.visit('/login'); // Garante que começa na página de login

    // Preenche credenciais válidas
    cy.get('input[placeholder="Email"]').type('LoginPage@LoginPage.com'); 
    cy.get('input[placeholder="Senha"]').type('login_10');
    cy.get('button').contains('Entrar').click();
    // Verifica se foi redirecionado para a página inicial
    cy.url().should('include', '/home');
    // Verifica se a mensagem esperada está visível na Home
    cy.get('h1').should('contain.text', 'ContaFácil - Página Inicial');
    });
  });

  // Testes de validação de formulário
  describe('Validação de formulário', () => {
  it('51 - deve validar o formato do email', () => {
    cy.get('input[placeholder="Email"]').type('email_invalido');
    cy.get('input[placeholder="Senha"]').type('senha123');
    cy.get('button').contains('Entrar').click();
    // Verifica a mensagem nativa do navegador
    cy.get('input[placeholder="Email"]').then(($input) => {
    const validationMessage = $input[0].validationMessage;
    expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });
  });
});

// Testes de segurança
describe('Segurança', () => {
  beforeEach(() => {
    cy.visit('/login'); // Visita a página antes de cada teste
  });
  it('52 - deve bloquear na 6ª tentativa consecutiva após 5 tentativas falhas', () => {
    // Executa as 5 primeiras tentativas (i = 0 a 4)
    for (let i = 0; i < 5; i++) {
      cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').clear().type('senha_incorreta' + i);
      cy.get('button').contains('Entrar').click();
      cy.wait(500);
      // Nas primeiras 5 tentativas espera a mensagem padrão de erro
      cy.get('.alert')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    }
    // 6ª tentativa - deve exibir a mensagem de bloqueio
    cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
    cy.get('input[placeholder="Senha"]').clear().type('senha_incorreta6');
    cy.get('button').contains('Entrar').click();
    // Espera a mensagem de bloqueio na 6ª tentativa
    cy.get('.alert')
      .should('be.visible')
      .and('contain', 'Muitas tentativas. Tente novamente mais tarde.');
  });

  it('53 - não deve bloquear após 4 tentativas consecutivas', () => {
    // Executa 4 tentativas (i = 0 a 3)
    for (let i = 0; i < 4; i++) {
      cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').clear().type('senha_incorreta' + i);
      cy.get('button').contains('Entrar').click();
      cy.wait(500);

      // Espera a mensagem padrão de senha inválida em todas essas tentativas
      cy.get('.alert')
        .should('be.visible')
        .and('contain', 'Email ou senha inválidos.');
    }
  });

  it('54 - não deve armazenar senha em texto simples no localStorage ou sessionStorage', () => {
    cy.get('input[placeholder="Email"]').type('usuario@teste.com');
    cy.get('input[placeholder="Senha"]').type('senha123');
    cy.get('button').contains('Entrar').click();
    // Verifica se a senha não está armazenada em texto simples
    cy.window().then((win) => {
      const localStorageItems = Object.keys(win.localStorage).map(key => win.localStorage.getItem(key));
      const sessionStorageItems = Object.keys(win.sessionStorage).map(key => win.sessionStorage.getItem(key));
      expect(localStorageItems.includes('senha123')).to.be.false;
      expect(sessionStorageItems.includes('senha123')).to.be.false;
    });
  });

  it('55 - bloqueia o usuário após várias tentativas de login erradas, 7 tentativas', () => {
    for (let i = 0; i < 6; i++) {
      cy.get('input[placeholder="Email"]').clear().type('usuario@teste.com');
      cy.get('input[placeholder="Senha"]').clear().type('senha_errada');
      cy.get('button').contains('Entrar').click();
      cy.wait(500);
    }
    cy.get('.alert').should(($el) => {
      const text = $el.text().toLowerCase();
      expect(
        text.includes('bloqueado') || text.includes('tente novamente mais tarde')
      ).to.be.true;
    });
  });

   //Teste simples de injeção SQL no login
  it('56 - não permite login com payload de injeção SQL', () => {
    cy.visit('/login');
    // Digita um payload inválido no campo email
    cy.get('input[placeholder="Email"]').type(`' OR '1'='1`);
    // Tenta submeter o formulário
    cy.get('button[type="submit"]').click();
    // Verifica a mensagem de validação nativa do navegador
    cy.get('input[placeholder="Email"]').then(($input) => {
      const validationMessage = $input[0].validationMessage;
      expect(validationMessage).to.include('Inclua um "@" no endereço de e-mail');
    });
    // Opcional: pode verificar que URL não mudou, indicando que não houve login
    cy.url().should('include', '/login');
  });

  // Teste simples de XSS refletido no campo email
  it('57 - não executa script malicioso no campo email (XSS refletido)', () => {
    cy.visit('/login');
    const xssPayload = `<script>alert("XSS")</script>`;
    cy.get('#email').type(xssPayload);
    cy.get('#senha').type('qualquer');
    cy.get('button[type="submit"]').click();

    cy.on('window:alert', () => {
      throw new Error('XSS Vulnerabilidade detectada!');
    });
  });

  //Teste de logout invalida sessão e impede acesso à página protegida
  it('58 - impede acesso após logout', () => {
    cy.visit('/login');
    cy.get('#email').type('usuario@teste.com');
    cy.get('#senha').type('senha_correta');
    cy.get('button[type="submit"]').click();

    cy.visit('/logout');

    cy.visit('/home');
    cy.url().should('include', '/login');
  });

  //Teste básico de autorização - impede acesso a páginas restritas
  it('59 - não permite usuário comum acessar página admin', () => {
    cy.visit('/login');
    cy.get('#email').type('usuario@teste.com');
    cy.get('#senha').type('senha_correta');
    cy.get('button[type="submit"]').click();
    cy.visit('/admin');
    cy.contains(/Você precisa estar logado para acessar esta página./i).should('exist');
  });

  //Teste básico de CSRF (exemplo simplificado)
  it('60 - não permite submissão de formulário sem token CSRF válido', () => {
    cy.request({
      method: 'POST',
      url: '/movimentacao',
      failOnStatusCode: false,
      form: true,
      body: {
        campo1: 'valor',
        campo2: 'valor'
      }
    }).then((response) => {
      expect(response.status).to.be.oneOf([400]);
      // Aqui validamos que a resposta contém as palavras 'CSRF' ou 'token'
      expect(response.body).to.satisfy(body => /csrf|token/i.test(body));
    });
  });

  it('61 - Deve retornar erro 400 quando o token CSRF não for enviado', () => {
    cy.request({
      method: 'POST',
      url: '/movimentacao',  // rota protegida
      failOnStatusCode: false, // para não falhar automaticamente no erro HTTP
      form: true,
      body: {
        // dados do formulário, mas sem o campo csrf_token
        campo1: 'valor1',
        campo2: 'valor2'
      }
    }).then((response) => {
      // Loga o status e o corpo no console do navegador
    console.log('Status:', response.status);
    console.log('Body:', response.body);
    // Também mostra no painel do Cypress (parte visual da execução do teste)
    cy.log('Status: ' + response.status);
    cy.log('Body: ' + response.body);
    // Validação real
    expect(response.status).to.eq(400);
    expect(response.body.toLowerCase()).to.include('csrf');
    })
  })
}); 
  // Testes de responsividade
  describe('Responsividade', () => {
    it('62 - deve exibir corretamente em tela de celular', () => {
      cy.viewport('iphone-x');
      cy.get('form').should('be.visible');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });

    it('63 - deve exibir corretamente em tela de tablet', () => {
      cy.viewport('ipad-2');
      cy.get('form').should('be.visible');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });

    it('64 - deve exibir corretamente em tela de desktop', () => {
      cy.viewport(1920, 1080);
      cy.get('form').should('be.visible');
      cy.get('input[placeholder="Email"]').should('be.visible');
      cy.get('input[placeholder="Senha"]').should('be.visible');
      cy.get('button').contains('Entrar').should('be.visible');
    });
  });
});

describe('ContaFácil - Home', () => {
  beforeEach(() => {
    // Usa cy.session para manter login entre testes
    cy.session('sessao-pagina-inicial', () => {
      LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/home');
  });

  // Validações principais de textos e hierarquia (65 - 75)
  it('65 - Deve conter título da aba correto', () => {
    cy.title().should('eq', 'ContaFácil - Home');
  });

  it('66 - Deve conter um h1 com texto exato', () => {
    cy.get('main h1').should('have.text', 'ContaFácil - Página Inicial');
  });

  it('67 - Deve conter h2 com saudação contendo o nome do usuário', () => {
    cy.get('main h2').invoke('text').should('match', /^Olá, .+! Seja bem-vindo\(a\) ao ContaFácil\.$/);
  });

  it('68 - Deve conter parágrafo explicativo com texto esperado', () => {
    cy.get('main p').should('have.text', 'Aqui você pode gerenciar facilmente suas finanças e acompanhar o saldo das suas contas.');
  });

  it('69 - Deve conter h3 com o texto "Saldo das suas contas"', () => {
    cy.get('main h3').should('have.text', 'Saldo das suas contas');
  });

  // Validações da tabela de contas (70 - 80)
  it('70 - A tabela deve ter a classe "table" e atributo aria-label correto', () => {
    cy.get('table.table').should('have.attr', 'aria-label', 'Tabela de saldos das contas do usuário');
  });

  it('71 - A tabela deve conter cabeçalhos "Conta", "Despesas", "Receitas" e "Saldo"', () => {
    cy.get('table thead th').eq(0).should('have.text', 'Conta');
    cy.get('table thead th').eq(1).should('have.text', 'Receitas');
    cy.get('table thead th').eq(2).should('have.text', 'Despesas');
    cy.get('table thead th').eq(3).should('have.text', 'Saldo');
  });

  it('72 - Cada linha de conta deve conter link com tabindex=0 e nome da conta não vazio', () => {
    cy.get('table tbody tr').each(($tr) => {
      const isSaldoTotal = $tr.hasClass('saldo-total');

      if (!isSaldoTotal) {
        cy.wrap($tr).find('td').then(($tds) => {
          if ($tds.length === 2 && !$tds.eq(0).attr('colspan')) {
            cy.wrap($tds.eq(0)).find('a')
              .should('have.attr', 'tabindex', '0')
              .and('not.be.empty');
          }
        });
      }
    });
  });

  it('73 - Os saldos devem estar no formato PT-BR, ex: R$ 1.234,56', () => {
    const saldoRegex = /^R\$ \d{1,3}(\.\d{3})*,\d{2}$/;
    cy.get('table tbody tr').each(($tr) => {
      cy.wrap($tr).find('td').eq(1).invoke('text').then((text) => {
        if (!text.includes('Nenhuma conta cadastrada')) {
          expect(text.trim()).to.match(saldoRegex);
        }
      });
    });
  });

  it('74 - Deve mostrar mensagem "Nenhuma conta cadastrada ainda." caso não haja contas', () => {
    cy.get('table tbody tr').then(($rows) => {
      if ($rows.length === 1) {
        cy.get('table tbody tr td[colspan="2"]').should('have.text', 'Nenhuma conta cadastrada ainda.');
      }
    });
  });

  // Acessibilidade e atributos (75 - 79)
  it('75 - Links das contas devem estar acessíveis via teclado (tabindex=0)', () => {
    cy.get('table tbody tr td a').each(($a) => {
      cy.wrap($a).should('have.attr', 'tabindex', '0');
    });
  });

  it('76 - Deve existir exatamente um elemento main na página', () => {
    cy.get('main').should('have.length', 1);
  });

  it('77 - Deve garantir hierarquia correta de títulos (h1, depois h2, depois h3)', () => {
    cy.get('main').within(() => {
      cy.get('h1').should('exist');
      cy.get('h2').should('exist');
      cy.get('h3').should('exist');
    });
  });

  it('78 - A tabela deve ter os cabeçalhos com scope="col"', () => {
    cy.get('table thead th').each(($th) => {
      cy.wrap($th).should('have.attr', 'scope', 'col');
    });
  });

  it('79 - A linha de saldo total deve estar estilizada em negrito', () => {
    cy.get('table tbody tr.saldo-total').should('have.css', 'font-weight').and((fontWeight) => {
      expect(['700', 'bold']).to.include(fontWeight);
    });
  });
});

describe('Validar usuario sem conta cadastradas', () => {
  beforeEach(() => {
    cy.session('sessao-usuario-sem-conta', () => {
      LoginPage.login('saltototal@saldotota.com', 'teste_12');
    });
    cy.visit('/home');
  });

  it('80 - Deve exibir linha de saldo total somente se houver contas, senão mensagem adequada', () => {
    cy.get('table tbody').then($tbody => {
      if ($tbody.find('tr.saldo-total').length > 0) {
        cy.get('table tbody tr.saldo-total').within(() => {
          cy.get('td').eq(0).should('have.text', 'Saldo Total');
          cy.get('td').eq(1).invoke('text').should('match', /^R\$ \d{1,3}(\.\d{3})*,\d{2}$/);
        });
      } else {
        cy.contains('Nenhuma conta cadastrada ainda.').should('be.visible');
      }
    });
  });
});

describe('Validar total do saldo da conta', () => {
  beforeEach(() => {
    cy.session('sessao-usuario-com-conta', () => {
      LoginPage.login('teste1@teste1.com', '123456');
    });
    cy.visit('/home');
  });

  it('81 - Deve exibir múltiplas contas e saldo total correto', () => {
    let soma = 0;

    cy.get('table tbody tr').each(($row) => {
      if (!$row.hasClass('saldo-total') && !$row.text().includes('Nenhuma conta cadastrada')) {
        cy.wrap($row).find('td').eq(3).invoke('text').then((text) => {
          const valor = parseFloat(text.replace(/[R$\s]/g, '').replace('.', '').replace(',', '.'));
          soma += valor;
        });
      }
    });

    cy.wait(200).then(() => {
      cy.get('table tbody tr.saldo-total td').eq(3).invoke('text').then((textTotal) => {
        const total = parseFloat(textTotal.replace(/[R$\s]/g, '').replace('.', '').replace(',', '.'));
        expect(total).to.eq(soma);
      });
    });
  });

  it('82 - Deve validar a soma total das receitas', () => {
    let somaReceitas = 0;
    cy.get('table tbody tr').not('.saldo-total').each(($tr) => {
      cy.wrap($tr).find('td').eq(1).invoke('text').then((text) => {
        const valor = parseFloat(text.replace(/[R$\.\s]/g, '').replace(',', '.'));
        somaReceitas += valor;
      });
    }).then(() => {
      cy.get('table tbody tr.saldo-total td').eq(1).invoke('text').then((textTotal) => {
        const total = parseFloat(textTotal.replace(/[R$\.\s]/g, '').replace(',', '.'));
        expect(total).to.eq(somaReceitas);
      });
    });
  });

  it('83 - Deve validar a soma total das despesas', () => {
    let somaDespesas = 0;
    cy.get('table tbody tr').not('.saldo-total').each(($tr) => {
      cy.wrap($tr).find('td').eq(2).invoke('text').then((text) => {
        const valor = parseFloat(text.replace(/[R$\.\s-]/g, '').replace(',', '.'));
        somaDespesas += valor;
      });
    }).then(() => {
      cy.get('table tbody tr.saldo-total td').eq(2).invoke('text').then((textTotal) => {
        const total = parseFloat(textTotal.replace(/[R$\.\s-]/g, '').replace(',', '.'));
        expect(total).to.eq(somaDespesas);
      });
    });
  });

  it('94 - Deve validar que o saldo total é a diferença entre receitas e despesas', () => {
    let receitas = 0;
    let despesas = 0;
    cy.get('table tbody tr').not('.saldo-total').each(($tr) => {
      cy.wrap($tr).find('td').eq(1).invoke('text').then((text) => {
        receitas += parseFloat(text.replace(/[R$\.\s]/g, '').replace(',', '.'));
      });
      cy.wrap($tr).find('td').eq(2).invoke('text').then((text) => {
        despesas += parseFloat(text.replace(/[R$\.\s-]/g, '').replace(',', '.'));
      });
    }).then(() => {
      const saldoEsperado = receitas - despesas;
      cy.get('table tbody tr.saldo-total td').eq(3).invoke('text').then((textSaldo) => {
        const saldoTotal = parseFloat(textSaldo.replace(/[R$\.\s-]/g, '').replace(',', '.'));
        if (textSaldo.includes('-')) {
          expect(-saldoTotal).to.eq(saldoEsperado);
        } else {
          expect(saldoTotal).to.eq(saldoEsperado);
        }
      });
    });
  });
});

describe('Acessibilidade - Tela de Cadastro de Usuário', () => {
  beforeEach(() => {
    cy.visit('/cadastro'); // Ajuste a rota conforme necessário
    cy.injectAxe(); // Injeta a biblioteca de acessibilidade axe-core
  });

  it('82 - Deve passar nos testes básicos de acessibilidade do Axe', () => {
    cy.checkA11y(null, null, (violations) => {
      if (violations.length) {
        console.log(`${violations.length} violações de acessibilidade encontradas:`);

        violations.forEach(({ id, impact, description, nodes }) => {
          console.log(`ID: ${id}`);
          console.log(`Impacto: ${impact}`);
          console.log(`Descrição: ${description}`);
          console.log(`Número de elementos afetados: ${nodes.length}`);

          nodes.forEach(({ html, target }) => {
            console.log(`Elemento afetado: ${html}`);
            console.log(`Caminho do alvo: ${target.join(' > ')}`);
          });

          console.log('---');
        });
      }
      // Faz a asserção dentro do callback, sem usar then()
      expect(violations.length, 'Sem violações de acessibilidade básicas').to.equal(0);
    });
  });  

  //83 - Valida a navegação usando apenas o teclado (Tab).
  it('83 - Deve ser possível navegar pelo formulário usando apenas o teclado', () => {
    cy.visit('/cadastro');
    // Foco inicial no input nome
    cy.get('#nome').focus().should('have.attr', 'id', 'nome');
    // Tab para email
    cy.focused().tab();
    cy.focused().should('have.attr', 'id', 'email');
    // Tab para senha
    cy.focused().tab();
    cy.focused().should('have.attr', 'id', 'senha');
    // Tab para o botão togglePassword (tipo button)
    cy.focused().tab();
    cy.focused().should('have.attr', 'id', 'togglePassword');
    cy.focused().should('have.attr', 'type', 'button');
    // Tab para o botão submit
    cy.focused().tab();
    cy.focused().should('have.attr', 'type', 'submit');
  });

   it('84 - Todos os campos devem possuir rótulos (label) corretamente associados', () => {
    cy.get('label[for="nome"]').should('exist');
    cy.get('input#nome').should('exist');

    cy.get('label[for="email"]').should('exist');
    cy.get('input#email').should('exist');

    cy.get('label[for="senha"]').should('exist');
    cy.get('input#senha').should('exist');
  });

  it('85 - Botão de mostrar senha deve ter rótulo acessível', () => {
    cy.get('#togglePassword')
      .should('have.attr', 'aria-label')
      .and('match', /mostrar|ocultar/i); // Deve conter a palavra mostrar ou ocultar
  });

   it('86 - Mensagens de critérios da senha devem ser visíveis e informativas', () => {
    cy.get('#senha').type('A');
    cy.get('#length').should('be.visible');
    cy.get('#letter').should('contain.text', 'letra');
    cy.get('#number').should('contain.text', 'número');
    cy.get('#special').should('contain.text', 'caractere especial');
  });

  it('87 - Mensagem de feedback deve ser lida por leitores de tela (role="alert")', () => {
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  it('88 - Link "Já tem conta? Faça login" deve ser acessível', () => {
    cy.contains('Já tem conta? Faça login')
      .should('have.attr', 'href')
      .and('include', 'login');
  });

  it('89 - Deve manter contraste suficiente entre texto e fundo', () => {
    cy.get('button[type="submit"]')
      .should('have.css', 'color')
      .and((color) => {
        expect(color).to.not.equal('rgba(0, 0, 0, 0)'); // Não deve ser transparente
      });
  });

  it('90 - Deve haver apenas um elemento <main> na página', () => {
    cy.get('main').should('have.length', 1);
  });
  
    // 91 - Deve haver indicação visual clara do foco nos elementos focáveis
  it('91 - Deve haver indicação visual clara do foco nos elementos focáveis', () => {
    cy.get('input, button, a').each(($el) => {
      cy.wrap($el)
        .focus()
        .should('have.css', 'outline-color')
        .and('not.equal', 'rgba(0, 0, 0, 0)') // ou 'transparent'
        .and('match', /rgb|#|hsl/); // assegura que tem cor
    });
  });

  // 92 - Botão mostrar/ocultar senha deve atualizar aria-label conforme estado
  it('92 - Botão mostrar/ocultar senha atualiza aria-label conforme estado', () => {
    cy.get('#togglePassword')
    .as('toggle')
    .should('have.attr', 'aria-label', 'Mostrar senha');
    cy.get('#togglePassword').click();
    cy.get('@toggle').should('have.attr', 'aria-label', 'Ocultar senha');
  });

  // 93 - Todos os links devem ter texto descritivo e visível
  it('93 - Todos os links possuem texto descritivo e visível', () => {
    cy.get('a[href]').each(($link) => {
      cy.wrap($link)
        .invoke('text')
        .should('not.be.empty')
        .and('not.match', /^\s*$/);
      cy.wrap($link).should('be.visible');
    });
  });
});

describe('Cadastro de Usuário - Testes Funcionais', () => {

  beforeEach(() => {
    cy.visit('/cadastro');
  });

  // --- 94 a 96: Validação campos obrigatórios ---

  it('94 - Não deve permitir cadastro apenas com email', () => {
    cy.get('input[name="email"]').type('saltototal@saldotota.com');
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  it('95 - Não deve permitir cadastro apenas com senha', () => {
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  it('96 - Não deve permitir cadastro apenas com nome', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  // --- 97 a 102: Validação formato e existência do email ---

  it('97 - Não deve aceitar email inválido (sem @)', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('input[name="email"]').type('emailinvalido.com');
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/email inválido/i).should('exist');
  });

  it('98 - Não deve aceitar email inválido (sem domínio)', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('input[name="email"]').type('email@');
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/email inválido/i).should('exist');
  });

  it('99 - Não deve aceitar email já existente', () => {
    cy.get('input[name="nome"]').type('Teste Usuário');
    cy.get('input[name="email"]').type('saltototal@saldotota.com'); // Email previamente cadastrado no DB de teste
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/Endereço de email já utilizado./i).should('exist');
  });

  it('100 - Deve aceitar email válido e novo', () => {
    const novoEmail = `novoemail${Date.now()}@exemplo.com`;
    cy.get('input[name="nome"]').type('Novo Usuário');
    cy.get('input[name="email"]').type(novoEmail);
    cy.get('input[name="senha"]').type('Senha123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  // --- 101 a 107: Validação da senha ---

  it('101 - Não deve aceitar senha com menos de 8 caracteres', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Ab1!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve ter entre 8 e 10 caracteres/i).should('exist');
  });

  it('102 - Não deve aceitar senha com mais de 10 caracteres', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Ab1!Ab1!Ab1!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve ter entre 8 e 10 caracteres/i).should('exist');
  });

  it('103 - Não deve aceitar senha sem letra', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('12345678!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve conter pelo menos uma letra/i).should('exist');
  });

  it('104 - Não deve aceitar senha sem número', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Senha!!!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve conter pelo menos um número/i).should('exist');
  });

  it('105 - Não deve aceitar senha sem caractere especial', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Senha1234');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve conter pelo menos um caractere especial/i).should('exist');
  });

  it('106 - Não deve aceitar senha com espaço em branco', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Senha 123!');
    cy.get('button[type="submit"]').click();
    cy.contains(/senha não pode conter espaços/i).should('exist');
  });

  it('107 - Deve aceitar senha válida conforme critérios', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc1230!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  // --- 108 a 111: Validação do nome ---
  it('108 - Não deve aceitar nome com caracteres numéricos', () => {
    cy.get('input[name="nome"]').type('João123');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Nome deve conter apenas letras./i).should('exist');
  });

  it('109 - Não deve aceitar nome com caracteres especiais', () => {
    cy.get('input[name="nome"]').type('João@#!');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Nome deve conter apenas letras/i).should('exist');
  });

  it('110 - Deve aceitar nome com espaços e acentos', () => {
    cy.get('input[name="nome"]').type('João da Silva');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  it('111 - Nome muito longo (mais de 50 caracteres) deve apresentar erro', () => {
    const longName = 'A'.repeat(51);
    cy.get('input[name="nome"]').type(longName);
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Máximo de 50 caracteres no nome/i).should('exist');
  });

  // --- 115 a 117: Botão mostrar/ocultar senha ---
  it('115 - Botão mostrar senha altera input para texto e atualiza aria-label', () => {
    cy.get('input[name="senha"]').should('have.attr', 'type', 'password');
    cy.get('#togglePassword').click();
    cy.get('input[name="senha"]').should('have.attr', 'type', 'text');
    cy.get('#togglePassword').should('have.attr', 'aria-label', 'Ocultar senha');
  });

  it('116 - Botão ocultar senha altera input para password e atualiza aria-label', () => {
    cy.get('#togglePassword').click(); // mostrar
    cy.get('#togglePassword').click(); // ocultar
    cy.get('input[name="senha"]').should('have.attr', 'type', 'password');
    cy.get('#togglePassword').should('have.attr', 'aria-label', 'Mostrar senha');
  });

  it('117 - Botão mostrar/ocultar senha não submete o formulário', () => {
    cy.get('#togglePassword').click();
    cy.url().should('include', '/cadastro');
  });

  // --- 121 a 125: Submissão do formulário e UX ---
  it('118 - Formulário com dados válidos realiza cadastro com sucesso', () => {
    cy.get('input[name="nome"]').type('Usuário Completo');
    cy.get('input[name="email"]').type(`usuario${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc1234!@#');
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  it('119 - Navegação entre campos via tecla Tab funciona corretamente', () => {
    cy.get('input[name="nome"]').focus().tab();
    cy.focused().should('have.attr', 'name', 'email');
    cy.focused().tab();
    cy.focused().should('have.attr', 'name', 'senha');
    cy.focused().tab();
    cy.focused().should('have.id', 'togglePassword');
  });

  it('120 - Submissão via tecla Enter dispara o envio do formulário', () => {
    cy.get('input[name="nome"]').type('Usuário');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc1234!@#{enter}');
    cy.contains(/Usuário cadastrado com sucesso! Faça o login./i).should('exist');
  });

  it('121 - Senha com 7 caracteres deve apresentar erro', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!'); // 7 caracteres
    cy.get('button[type="submit"]').click();
    cy.contains(/senha deve ter entre 8 e 10 caracteres/i).should('exist');
  });

  it('122- Senha com 8 caracteres deve cadastrar com sucesso', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@'); // 8 caracteres
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login/i).should('exist');
  });

  it('123- Senha com 9 caracteres deve cadastrar com sucesso', () => {
    cy.get('input[name="nome"]').type('Usuário Teste');
    cy.get('input[name="email"]').type(`email${Date.now()}@exemplo.com`);
    cy.get('input[name="senha"]').type('Abc123!@#'); // 9 caracteres
    cy.get('button[type="submit"]').click();
    cy.contains(/Usuário cadastrado com sucesso! Faça o login/i).should('exist');
  });
});

describe('ContaFácil - Página Adicionar Conta', () => {
  beforeEach(() => {
    // Usa cy.session para manter login entre testes
    cy.session('sessao-pagina-inicial', () => {
      LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/contas/adicionar');
  });

  it('124 - Deve conter título da aba correto', () => {
    cy.title().should('eq', 'ContaFácil - Adicionar Conta');
  });

  it('125 - Deve conter o título visível "Adicionar Conta"', () => {
    cy.get('h2').should('have.text', 'Adicionar Conta').and('be.visible');
  });

  it('126 - Deve conter um formulário com method POST', () => {
    cy.get('form').should('have.attr', 'method', 'post');
  });

  it('127 - Deve conter o campo oculto de CSRF Token', () => {
    cy.get('input[name="csrf_token"]').should('exist').and('have.attr', 'type', 'hidden');
  });

  it('128 - Deve conter campo de nome com label correto', () => {
    cy.get('label[for="nome"]').should('have.text', 'Nome');
    cy.get('input#nome').should('have.attr', 'name', 'nome');
  });

  it('129 - Deve permitir digitar no campo "nome"', () => {
    cy.get('input#nome').type('Conta Corrente').should('have.value', 'Conta Corrente');
  });

  it('130 - Botão "Salvar" deve ser do tipo submit e visível', () => {
    cy.get('button[type="submit"]').should('contain', 'Salvar').and('be.visible');
  });

  it('131 - Deve redirecionar para a Home ao clicar em "Cancelar"', () => {
    cy.get('a.btn-secondary')
      .should('have.attr', 'href')
      .and('include', '/home');
  });
//Teste de
// Este teste simula o envio do formulário com o token CSRF inválido (removido).
// O objetivo é garantir que a aplicação bloqueie o envio e retorne um erro 400 (Bad Request),
// como esperado em uma falha de segurança por ausência do token CSRF.
  it('132 - Deve retornar erro 400 se o CSRF token estiver ausente', () => {
    cy.intercept('POST', '/contas/adicionar').as('postAdicionarConta'); // intercepta a requisição POST

    cy.get('input#nome').type('Conta CSRF inválido');
    cy.get('input[name="csrf_token"]').invoke('val', ''); // zera o token
    cy.get('form').submit(); // envia o formulário manualmente
    cy.wait('@postAdicionarConta').its('response.statusCode').should('eq', 400); // valida status 400
  });

  it('133 - Deve ter estrutura semântica HTML correta (form, label, input)', () => {
    cy.get('form').within(() => {
      cy.get('label').should('have.length.at.least', 1);
      cy.get('input').should('have.length.at.least', 2); // nome + csrf
    });
  });

  it('134 - Deve adicionar conta com exatamente 19 caracteres', () => {
    const nomeBase = 'Conta com 19 cha'; // 16 + 3 = 19
    const nome19 = nomeBase + gerarSufixo(3);
    expect(nome19.length).to.eq(19);
    cy.get('input[name="nome"]').type(nome19);
    cy.get('button[type="submit"]').click();
    cy.contains('Conta adicionada com sucesso!').should('be.visible');
  });

    it('135 - Deve adicionar conta com exatamente 20 caracteres', () => {
    const base = 'Conta com 20 cha';
    const nome20 = base + gerarSufixo(4);
    expect(nome20.length).to.eq(20); // Garantia no teste
    cy.get('input[name="nome"]').clear().type(nome20);
    cy.get('button[type="submit"]').click();
    cy.contains('Conta adicionada com sucesso!').should('be.visible');
  });

  it('136 - Deve exibir erro ao tentar adicionar conta com 21 caracteres', () => {
    const base = 'Conta com 21 cha';
    const nome21 = base + gerarSufixo(5);
    expect(nome21.length).to.eq(21); // Aqui deve ser 21, não 20
    cy.get('input[name="nome"]').clear().type(nome21);
    cy.get('button[type="submit"]').click();
    cy.contains('O nome da conta deve ter no máximo 20 caracteres.').should('be.visible');
  });

  it('137 - Deve exibir erro ao tentar salvar conta com nome vazio', () => {
    cy.get('button[type="submit"]').click(); // Envia o formulário
    cy.contains('O nome da conta é obrigatório.').should('be.visible');
  });

   it('138 - Não deve cadastrar nome de conta repetida', () => {
    const nome = 'Teste Nome Duplicado';
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    cy.contains('Já existe uma conta com esse nome.').should('be.visible');
  });
});

describe('Acessibilidade - Página Adicionar Conta', () => {

  beforeEach(() => {
    cy.session('user-session', () => {
      LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/contas/adicionar');
  });

  it('139 - Deve conter apenas um elemento <main> na página', () => {
    cy.get('main').should('have.length', 1);
  });

  it('140 - Deve conter um heading visível e semântico <h2> com o texto correto', () => {
    cy.get('h2').should('have.text', 'Adicionar Conta').and('be.visible');
  });

  it('141 - O campo "nome" deve ter rótulo associado via <label for="..."> e id correspondente', () => {
    cy.get('label[for="nome"]').should('exist').and('contain.text', 'Nome');
    cy.get('#nome').should('exist').and('have.attr', 'name', 'nome');
  });

  it('142 - O campo "nome" deve ser acessível por teclado (focável)', () => {
  cy.get('#nome').focus().should('exist');
  });

  it('143 - O formulário deve conter botão do tipo submit e botão de cancelamento acessíveis via teclado', () => {
    cy.get('button[type="submit"]').should('contain.text', 'Salvar').focus();
    cy.focused().should('have.text', 'Salvar');
    cy.get('a.btn-secondary').should('contain.text', 'Cancelar').focus();
    cy.focused().should('have.text', 'Cancelar');
  });

  it('144 - Deve exibir mensagem de erro acessível se o campo "nome" for enviado vazio', () => {
    cy.get('form').submit();
    cy.get('.alert, [role="alert"], [aria-live="polite"], [aria-live="assertive"]')
      .should('exist')
      .and('contain.text', 'O nome da conta é obrigatório.')
      .and('be.visible');
  });

  it('145 - O formulário deve ser navegável via teclado (tabindex natural)', () => {
    const ordemEsperada = [
      'a.brand',                 // Marca do sistema
      'a:contains("Home")',      // Link Home
      'button:contains("Contas")', // Botão dropdown
      'a:contains("Adicionar")',
      'a:contains("Listar")',
      'a:contains("Criar Movimentação")',
      'a:contains("Resumo Mensal")',
      'a:contains("Sair")',
      'input[name="nome"]',       // Campo do formulário
      'button[type="submit"]',    // Botão salvar
      'a.btn-secondary'           // Botão cancelar
    ];

    let idx = 0;
    cy.get('body').realPress('Tab'); // primeiro tab

    ordemEsperada.forEach((selector, i) => {
      cy.focused().should('match', selector);
      if (i < ordemEsperada.length - 1) {
        cy.realPress('Tab');
      }
    });
  });

    it('146 - Botões "Salvar" e "Cancelar" devem ser acessíveis com foco via teclado', () => {
    cy.get('button[type="submit"]').focus().should('have.focus');
    cy.get('a.btn-secondary').focus().should('have.focus');
  });

  
  it('147 - Deve exibir mensagem de erro se campo "nome" estiver vazio após envio', () => {
    cy.get('input#nome').clear();
    cy.get('button[type="submit"]').click();
    cy.url().should('include', '/contas/adicionar'); // permanece na página
  });
});

describe('ContaFácil - Página Listar Conta', () => {
  beforeEach(() => {
    cy.session('sessao-pagina-listar', () => {
      LoginPage.login('contalistar@contalistar.com', 'login_10');
    });
    cy.visit('/contas'); // Visite APÓS sessão estar criada
  });

  it('148 - Deve exibir título e botão "Adicionar Conta"', () => {
    cy.contains('h2', 'Contas Cadastradas').should('be.visible');
    cy.get('a.btn-success').should('contain', 'Adicionar Conta');
  });

  it('149 - Deve exibir tabela com cabeçalhos "Conta" e "Ações"', () => {
    cy.get('table').should('be.visible');
    cy.get('thead tr th').eq(0).should('contain.text', 'Conta');
    cy.get('thead tr th').eq(1).should('contain.text', 'Ações');
  });

  it('150 - Deve exibir contas cadastradas na tabela, se existirem', () => {
    cy.get('tbody tr').then(rows => {
      if (rows.length === 1) {
        cy.get('tbody tr td').should('contain.text', 'Nenhuma conta cadastrada.');
      } else {
        cy.get('tbody tr').each(row => {
          cy.wrap(row).find('td').eq(0).should('not.be.empty');
        });
      }
    });
  });

 it('151 - Deve adicionar conta', () => {
    const nome = 'Conta adicionada';
    cy.get('a.btn-success').click();  // Clicar no botão "Adicionar Conta"
    cy.url().should('include', '/contas/adicionar');
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    // Após salvar, deve voltar para listar contas e mostrar mensagem de sucesso
    cy.url().should('include', '/contas');
    cy.contains('Conta adicionada com sucesso!').should('be.visible');
    // Validar que a nova conta aparece na tabela
    cy.contains('td', nome).should('exist');
    // Guardar nome para usar nos próximos testes
    cy.wrap(nome).as('nomeConta');
  });

  it('152 - Não deve permitir duplicar nome de conta já existente', () => {
    const nome = 'Conta adicionada';
    cy.get('a.btn-success').click();  // Clicar no botão "Adicionar Conta"
    cy.url().should('include', '/contas/adicionar');
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    // Após salvar, deve voltar para listar contas e mostrar mensagem de sucesso
    cy.url().should('include', '/contas');
    cy.contains('Já existe uma conta com esse nome.').should('be.visible');
});

  it('153 - Cada conta listada deve conter botões de Detalhes, Editar e Excluir', () => {
    cy.get('tbody tr').each(row => {
      if (!row.text().includes('Nenhuma conta cadastrada.')) {
        cy.wrap(row).find('a.btn-primary').should('contain.text', 'Detalhes');
        cy.wrap(row).find('a.btn-warning').should('contain.text', 'Editar');
        cy.wrap(row).find('button.btn-danger').should('contain.text', 'Excluir');
      }
    });
  });

  it('154 - Botão Detalhes deve abrir em nova aba com target _blank e rel seguro', () => {
    cy.get('a.btn-primary').each(link => {
      cy.wrap(link).should('have.attr', 'target', '_blank');
      cy.wrap(link).should('have.attr', 'rel', 'noopener noreferrer');
    });
  });

  it('155 - Formulário de exclusão deve conter token CSRF', () => {
    cy.get('form').each(form => {
      cy.wrap(form).should('contain.html', 'csrf_token');
    });
  });

  it('156 - Ao clicar em "Excluir" deve exibir confirmação antes de enviar', () => {
    cy.window().then(win => {
      cy.stub(win, 'confirm').returns(false);
    });
    cy.get('button.btn-danger').first().click();
    cy.url().should('include', '/contas');
  });

  it('157 - Links de ação não devem permitir navegação sem autenticação', () => {
    cy.clearCookies();
    cy.visit('/contas', { failOnStatusCode: false });
    cy.url().should('include', '/login');
  });

  it('158 - Não deve permitir exclusão via requisição POST sem token CSRF', () => {
    cy.request({
      method: 'POST',
      url: '/contas/1/excluir',
      failOnStatusCode: false,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: ''
    }).then((response) => {
      expect(response.status).to.not.eq(200);
    });
  });

  it('159 - Campos da tabela não devem permitir script injection', () => {
    cy.get('tbody td').each(cell => {
      cy.wrap(cell).should('not.contain.text', '<script>');
    });
  });

  it('160 - Validar botão "Detalhes"', () => {
  // Localiza o botão "Detalhes" da primeira conta
    cy.get('a.btn-primary').contains('Detalhes')
      // Remove o atributo target para evitar abertura em nova aba (necessário para Cypress)
      .invoke('removeAttr', 'target')
      .click();

    // O botão "Detalhes" tem target="_blank", o que abre nova aba.
    // Cypress não suporta múltiplas abas, então removemos o target para validar a página aberta.
  
    // Valida se estamos na página correta
    cy.url().should('include', '/contas/detalhes');
    // Verifica se o título da página de detalhes está presente
    cy.get('h2').should('contain.text', 'Detalhes da Conta');
  });

  it('161 - Deve editar a conta criada e validar a alteração', function () {
    cy.visit('/contas'); // garantir estamos na página certa
    // Encontrar a linha da conta pelo nome da alias criada no teste anterior
    cy.contains('td', this.nomeConta)
      .parent('tr')
      .within(() => {
        cy.get('a.btn-warning').click(); // botão Editar
      });
    cy.url().should('include', '/contas/editar');
    // Alterar nome da conta
    const novoNome = `${this.nomeConta} Editada`;
    cy.get('input[name="nome"]').clear().type(novoNome);
    cy.get('button[type="submit"]').click();
    // Voltar para listar contas e verificar alteração
    cy.url().should('include', '/contas');
    cy.contains('Conta atualizada com sucesso!').should('be.visible');
    cy.contains('td', novoNome).should('exist');
    // Atualizar alias para próximo teste
    cy.wrap(novoNome).as('nomeConta');
  });

  it('162 - Deve excluir a conta editada e validar remoção', function () {
    cy.visit('/contas'); 
    // Encontrar a linha da conta pelo nome atualizado
    cy.contains('td', this.nomeConta)
      .parent('tr')
      .within(() => {
        // interceptar o confirm e aceitar automaticamente
        cy.window().then(win => {
          cy.stub(win, 'confirm').returns(true);
        });
        cy.get('button.btn-danger').click(); // botão Excluir
      });
    // Validar que a conta foi removida da lista
    cy.contains('td', this.nomeConta).should('not.exist');
  });
});

describe('Validar ordem alfabetica da lista de contas', () => {
  beforeEach(() => {
    cy.session('sessao-pagina-listar', () => {
      LoginPage.login('ordemAlfabetica@ordem.com', 'login_10');
    });
    cy.visit('/contas'); // Visite APÓS sessão estar criada
  });

   it('163 - Contas devem estar ordenadas alfabeticamente por nome', () => {
    const nomes = [];
    cy.get('tbody tr td:first-child').each(($el) => {
      nomes.push($el.text().trim());
    }).then(() => {
      const nomesOrdenados = [...nomes].sort((a, b) => a.localeCompare(b));
      expect(nomes).to.deep.equal(nomesOrdenados);
    });
  });

  it('164 - Excluir conta "A" e validar que as contas permanecem ordenadas alfabeticamente', () => {
    // Passo 1: localizar a linha da conta "A"
    cy.get('tbody tr').contains('td', 'A').parent('tr').within(() => {
      // Passo 2: clicar no botão Excluir dentro dessa linha
      cy.get('form button[type="submit"]').click();
    });
    // Passo 3: confirmar o alert (confirmação da exclusão)
    cy.on('window:confirm', () => true);
    // Passo 4: após exclusão, validar se lista está ordenada
    cy.get('tbody tr td:first-child').then(($els) => {
      const nomes = [...$els].map(el => el.innerText.trim());
      const nomesOrdenados = [...nomes].sort((a, b) => a.localeCompare(b));
      expect(nomes).to.deep.equal(nomesOrdenados);
    });
  });

  it.only('165 - Deve validar a ordem alfabeti após a inclusão da nome "A" ', () => {
    const nome = 'A';
    cy.get('a.btn-success').click();  // Clicar no botão "Adicionar Conta"
    cy.url().should('include', '/contas/adicionar');
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    // Após salvar, deve voltar para listar contas e mostrar mensagem de sucesso
    cy.url().should('include', '/contas');
    cy.contains('Conta adicionada com sucesso!').should('be.visible');

    const nomes = [];
    cy.get('tbody tr td:first-child').each(($el) => {
      nomes.push($el.text().trim());
    }).then(() => {
      const nomesOrdenados = [...nomes].sort((a, b) => a.localeCompare(b));
      expect(nomes).to.deep.equal(nomesOrdenados);
    });
  });
});

describe('Acessibilidade - Página Lista Contas', () => {

  beforeEach(() => {
    cy.session('user-session', () => {
      LoginPage.login('contalistar@contalistar.com', 'login_10');
    });
    cy.visit('/contas');
  });

  it('166 - Deve ter uma tabela com cabeçalho e roles semânticos adequados', () => {
    cy.get('table').should('exist');
    cy.get('thead').should('exist');
    cy.get('thead th').each(($th) => {
      cy.wrap($th).should('have.attr', 'scope').and('match', /col|row/);
    });
  });

  it('167 - Os botões possuem textos claros e acessíveis', () => {
    ['Detalhes', 'Editar', 'Excluir', 'Adicionar Conta'].forEach(texto => {
      cy.contains('button, a', texto).should('be.visible').and('not.be.empty');
    });
  });

  it('168 - O formulário de exclusão possui token CSRF oculto', () => {
    cy.get('form').each(($form) => {
      cy.wrap($form).find('input[name="csrf_token"]').should('exist').and('have.attr', 'type', 'hidden');
    });
  });

  it('169 - Botão "Excluir" confirma exclusão e é focável via teclado', () => {
    cy.get('form button.btn-danger').first().focus().should('be.focused');
    cy.get('form').first().should('have.attr', 'onsubmit').and('include', 'confirm');
  });

  it('170 - Link "Adicionar Conta" é focável e possui texto descritivo', () => {
    cy.get('a.btn-success').should('be.visible').and('contain.text', 'Adicionar Conta').focus().should('be.focused');
  });

  it('171 - Deve focar elementos da tabela corretamente com TAB', () => {
    cy.visit('/contas');
    // Começa no botão "Adicionar Conta"
    cy.get('a.btn-success').focus().should('be.focused');
    // Tab para "Detalhes"
    cy.focused().tab();
    cy.focused().should('have.class', 'btn-primary').and('contain.text', 'Detalhes');
    // Tab para "Editar"
    cy.focused().tab();
    cy.focused().should('have.class', 'btn-warning').and('contain.text', 'Editar');
    // Tab para "Excluir"
    cy.focused().tab();
    cy.focused().should('have.class', 'btn-danger').and('contain.text', 'Excluir');
  });

  it('172 - Deve passar na verificação de contraste de cores', () => {
    cy.injectAxe(); // injeta axe-core na página
    cy.checkA11y(null, {
      runOnly: ['color-contrast']
    });
  });
});

describe('Criação de Movimentações - Testes Funcionais', () => {
  beforeEach(() => {
    cy.session('user-session', () => {
      cy.visit('/login');
      cy.get('input[name=email]').type('movimentacao@movimentacao.com');
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    MovimentacaoPage.visitar();

    MovimentacaoPage.setupClockBasedOnServerDate();
  });

  it('173 - Deve exibir todos os campos obrigatórios', () => {
    cy.get('form').within(() => {
      cy.get('select[name="tipo"]').should('exist');
      cy.get('input[name="data_movimentacao"]').should('exist');
      cy.get('input[name="data_pagamento"]').should('exist');
      cy.get('input[name="descricao"]').should('exist');
      cy.get('input[name="interessado"]').should('exist');
      cy.get('input[name="valor"]').should('exist');
      cy.get('select[name="conta_id"]').should('exist');
      cy.get('input[name="situacao"][value="pago"]').should('exist');
      cy.get('input[name="situacao"][value="pendente"]').should('exist');
    });
  });

  it('174 -Deve validar que o campo "Tipo da Movimentação" é obrigatório', () => {
    // Preenche tudo, exceto o campo tipo
    cy.get('select[name="tipo"]').select(''); // limpar seleção
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1); // ajusta de acordo com as contas
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Selecione o tipo de movimentação.').should('be.visible');
  });

  it('175 - Deve validar que o campo "Data da Movimentação" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').clear();
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Informe a data da movimentação.').should('be.visible');
  });

  it('176 - Deve validar que o campo "Data do Pagamento" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').clear();;
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Informe a data de pagamento.').should('be.visible');
  });

  it('177 - Deve validar que o campo "Descrição" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').clear();
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Descrição é obrigatória.').should('be.visible');
  });

  it('178 - Deve validar que o campo "Valor" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').clear();
    cy.get('select[name="conta_id"]').select(1);
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Informe um valor.').should('be.visible');
  });

  it('179 -Deve validar que o campo "Conta" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('receita');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select('0');  // valor da opção "Selecione uma conta"
    cy.get('input[name="situacao"][value="pago"]').check();
    cy.get('button[type="submit"]').click();
    cy.contains('Você precisa selecionar uma conta.').should('be.visible');
  });

  it('180 - Deve validar que o campo "Situação" é obrigatório', () => {
    cy.get('select[name="tipo"]').select('despesa');
    cy.get('input[name="data_movimentacao"]').type('2025-06-19');
    cy.get('input[name="data_pagamento"]').type('2025-06-19');
    cy.get('input[name="descricao"]').type('Descrição teste');
    cy.get('input[name="valor"]').type('100');
    cy.get('select[name="conta_id"]').select(2);
    cy.get('button[type="submit"]').click();
    cy.contains('Selecione a situação da movimentação.').should('be.visible');
  });

  it('181 - Deve validar valor não numérico', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-19');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente A');
    cy.get('input[name="valor"]').clear().type('abc'); // <-- AJUSTE AQUI: Passando uma string não numérica
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Valor inválido.');
  });

  it('182 - Deve criar receita com sucesso', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Venda de produto');
    MovimentacaoPage.preencherInteressado('Cliente A');
    MovimentacaoPage.preencherValor(250.75);
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('183 - Deve manter valores preenchidos após erro de validação', () => {
    MovimentacaoPage.preencherDescricao('Teste erro');
    MovimentacaoPage.submeter();
    cy.get('input[name="descricao"]').should('have.value', 'Teste erro');
  });

  it('184 -Deve aceitar valor mínimo 0.01', () => {
    MovimentacaoPage.preencherDescricao('Teste valor limite mínimo');
    MovimentacaoPage.preencherValor(0.01);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('185 -Deve rejeitar valor menor que 0.01', () => {
    MovimentacaoPage.preencherDescricao('Teste valor abaixo do mínimo');
    MovimentacaoPage.preencherValor(0.009);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-21');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.selecionarSituacao('pago');
    cy.get('form').submit();
    cy.contains('O valor deve ser maior ou igual a 0.01.').should('exist');
  });

  it('186 - Deve impedir valor zero', () => {
  MovimentacaoPage.preencherDescricao('Teste valor abaixo do mínimo');
  MovimentacaoPage.preencherValor(0);
  MovimentacaoPage.selecionarConta('Conta 1');
  MovimentacaoPage.selecionarTipo('receita');
  MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
  MovimentacaoPage.preencherDataPagamento('2025-06-20');
  MovimentacaoPage.selecionarSituacao('pago');
  cy.get('form').submit();
  cy.contains('O valor deve ser maior ou igual a 0.01.').should('exist');
  });

  it('187 - Deve permitir descrição com caracteres especiais', () => {
    const descricao = '!%&@#()[]{} - Teste com tudo';
    MovimentacaoPage.preencherDescricao(descricao);
    MovimentacaoPage.preencherValor(50);
    MovimentacaoPage.preencherDataMovimentacao('2025-06-19');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.selecionarConta('Conta 3');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
  });

  it('188 - Deve permitir campo "Interessado" opcional (vazio)', () => {
    MovimentacaoPage.preencherDescricao('Sem interessado');
    MovimentacaoPage.preencherValor(300);
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.selecionarConta('Conta 4');
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Despesa incluída com sucesso!').should('exist');
  });

  it('189 - Deve validar que data de pagamento não pode ser anterior à movimentação', () => {
    MovimentacaoPage.preencherDescricao('Data inconsistente');
    MovimentacaoPage.preencherValor(120);
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-19');
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento.');
  });

  it('190 - Não deve ter nenhuma opção de "Situação" selecionada por padrão', () => {
    cy.get('input[name="situacao"][value="pago"]').should('not.be.checked');
    cy.get('input[name="situacao"][value="pendente"]').should('not.be.checked');
  });

  it('191 - Deve manter "pendente" marcado ao submeter e falhar', () => {
    MovimentacaoPage.selecionarSituacao('pendente');
    MovimentacaoPage.submeter();
    cy.get('input[name="situacao"][value="pendente"]').should('be.checked');
  });

  it('192 - Deve permitir descrição com até 30 caracteres', () => {
    const descricao30Chars = 'A'.repeat(30);
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao(descricao30Chars);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
    cy.contains(descricao30Chars).should('exist'); // Verifica se a descrição foi salva e exibida
  });

  it('193 - Não deve permitir descrição com 31 caracteres', () => {
    const descricao31Chars = 'A'.repeat(31);
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao(descricao31Chars);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Descrição deve ter no máximo 30 caracteres.');
    cy.url().should('include', '/movimentacao'); // Deve permanecer na página de formulário
  });

  it('194 - Deve permitir descrição com 29 caracteres', () => {
    const descricao30Chars = 'A'.repeat(29);
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao(descricao30Chars);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    cy.url().should('include', '/resumo');
    cy.contains('Receita incluída com sucesso!').should('exist');
    cy.contains(descricao30Chars).should('exist'); // Verifica se a descrição foi salva e exibida
  });

  it('195 - Deve redirecionar para Home ao clicar em Cancelar', () => {
    cy.get('a.btn-secondary')
      .should('contain.text', 'Cancelar')
      .click();
    cy.url().should('include', '/home');
  });

  it('196 - Deve exibir erro ao criar movimentação sem conta cadastrada', () => {
    cy.session('user-sem-conta', () => {
      cy.visit('/login');
      cy.get('input[name=email]').type('semconta@teste.com');  // usuário sem conta
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    cy.visit('/movimentacao');
    // Preenche todos os campos, exceto conta (não há nenhuma disponível)
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-21');
    MovimentacaoPage.preencherDescricao('Teste sem conta');
    MovimentacaoPage.preencherInteressado('Cliente B');
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    // Valida a mensagem de erro esperada
    MovimentacaoPage.validarMensagem('Você precisa cadastrar uma conta antes de criar movimentações.');
  });

  it('197 - Deve validar que para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento', () => {
      MovimentacaoPage.preencherDescricao('Data inconsistente');
      MovimentacaoPage.preencherValor(120);
      MovimentacaoPage.preencherDataMovimentacao('2025-06-20'); // Data de movimentação posterior
      MovimentacaoPage.preencherDataPagamento('2025-06-19'); // Data de pagamento anterior
      MovimentacaoPage.selecionarConta('Conta 1');
      MovimentacaoPage.selecionarTipo('receita');
      MovimentacaoPage.selecionarSituacao('pago');
      MovimentacaoPage.submeter();
      MovimentacaoPage.validarMensagem('Para movimentações pagas, a data da movimentação não pode ser posterior à data de pagamento.');
  });

  it('198 - Deve validar que para movimentações pagas, a data de pagamento não pode ser no futuro', () => {
    // 'today' e 'tomorrow' agora serão calculados com base na data do servidor
    const tomorrow = Cypress.moment().add(1, 'days').format('YYYY-MM-DD'); 
    const today = Cypress.moment().format('YYYY-MM-DD'); 

    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao(today);
    MovimentacaoPage.preencherDataPagamento(tomorrow); // Data de pagamento no futuro
    MovimentacaoPage.preencherDescricao('Pagamento futuro');
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago'); // Situação 'pago'
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Para movimentações pagas, a data de pagamento não pode ser no futuro.');
  });

  it('199 - Deve validar que para movimentações pendentes, a data de pagamento não pode ser no passado', () => {
    // 'yesterday' e 'today' agora serão calculados com base na data do servidor
    const yesterday = Cypress.moment().subtract(1, 'days').format('YYYY-MM-DD'); 
    const today = Cypress.moment().format('YYYY-MM-DD'); 
    MovimentacaoPage.selecionarTipo('despesa');
    MovimentacaoPage.preencherDataMovimentacao(today);
    MovimentacaoPage.preencherDataPagamento(yesterday); // Data de pagamento no passado
    MovimentacaoPage.preencherDescricao('Pagamento pendente no passado');
    MovimentacaoPage.preencherValor(50);
    MovimentacaoPage.selecionarConta('Conta 2');
    MovimentacaoPage.selecionarSituacao('pendente'); // Situação 'pendente'
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Para movimentações pendentes, a data de pagamento não pode ser no passado.');
  });

  it('200 - Deve prevenir XSS no campo Descrição', () => {
    const xssPayload = '<img src=x onerror=alert(1)>';
  
    // Garante que o banco de dados está limpo para ESTE USUÁRIO antes de começar o teste XSS
    cy.visit('/clean-xss-payloads'); 
    cy.url().should('include', '/resumo'); 
    cy.contains('Payloads XSS de teste removidos do banco de dados!').should('be.visible');

    // Agora, volte para a página de movimentação para criar o novo item
    MovimentacaoPage.visitar(); 

    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao(xssPayload); // Insere o payload XSS
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1'); // Certifique-se que 'Conta 1' existe para este novo usuário
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();

    // O Cypress automaticamente falharia se um alert() aparecesse.
    // Garante que estamos na página de resumo após a submissão
    cy.url().should('include', '/resumo'); 
    cy.contains('Receita incluída com sucesso!').should('be.visible');

    // Asserção 1: Verifica que o HTML bruto da página NÃO contém o script XSS não escapado
    // Isso é o mais importante para XSS.
    cy.get('body').invoke('html').should('not.include', xssPayload);

    // Asserção 2: Verifica que o texto visível na página CONTÉM o payload XSS (escapado)
    // Isso confirma que o conteúdo foi renderizado, mas de forma segura (como texto).
    cy.get('td').contains(xssPayload).should('exist'); 

    // Asserção 3: Verifica que a mensagem flash de sucesso não contém o payload XSS
    cy.get('.alert-success').should('not.contain', xssPayload);
  });

  it('201 - Deve redirecionar para login se tentar acessar movimentacao após logout', () => {
    // Assume que o beforeEach já logou o usuário e visitou /movimentacao
    cy.visit('/logout'); // Ou clique no botão de logout
    cy.url().should('include', '/login'); // Redirecionou para login

    cy.visit('/movimentacao'); // Tenta acessar a página de movimentação diretamente
    cy.url().should('include', '/login'); // Deve ser redirecionado de volta para login
    cy.contains('Você precisa estar logado para acessar esta página.').should('be.visible'); // Se houver uma mensagem
  });
});

describe('Acessibilidade - Movimentação', () => {
  beforeEach(() => {
    // Garante que o usuário está logado para acessar a página de movimentação
    cy.session('user-session', () => {
      cy.visit('/login');
      cy.get('input[name=email]').type('movimentacao@movimentacao.com'); // Use um usuário existente
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    MovimentacaoPage.visitar(); // Visita a página de movimentação
    MovimentacaoPage.setupClockBasedOnServerDate(); // Sincroniza o clock do Cypress com o servidor
  });

  afterEach(() => {
    MovimentacaoPage.restoreClock(); // Restaura o clock do Cypress
  });

  // --- Testes de Acessibilidade ---
  // 1. Navegação por Teclado (WCAG 2.1.1, 2.4.3, 2.4.7)
  // Teste Manual: Ordem de foco lógica e visibilidade do indicador de foco
  it('202 - Deve verificar a ordem de foco lógica e a visibilidade do indicador de foco (MANUAL)', () => {
    cy.log('**Teste Manual:** Comece no topo da página e pressione a tecla `Tab` repetidamente.');
    cy.log('**Verifique:**');
    cy.log('1. O foco deve se mover de forma lógica e previsível por todos os elementos interativos (links da navbar, campos do formulário, botões "Salvar" e "Cancelar").');
    cy.log('2. A ordem deve ser da esquerda para a direita, de cima para baixo.');
    cy.log('3. O indicador de foco deve ser sempre visível e ter contraste suficiente com o fundo.');
    // Este teste não pode ser totalmente automatizado pelo Cypress, requer inspeção visual.
  });

  // Teste Automatizado: Focabilidade de elementos interativos
  it('203 - Deve garantir que todos os elementos interativos são focáveis via teclado (abordagem robusta)', () => {
    // Testar elementos da navbar que são visíveis por padrão
    cy.get('nav.navbar a:not(.dropdown-content a), nav.navbar button').each(($el) => {
      cy.wrap($el).should('be.visible'); // Deve estar visível
      cy.wrap($el).and(($el2) => {
        const tagName = $el2[0].tagName.toLowerCase();
        const hasHref = $el2[0].hasAttribute('href');
        const isDisabled = $el2[0].hasAttribute('disabled');
        const tabIndex = $el2[0].tabIndex;
        // Elementos interativos padrão (a, button) são focáveis por padrão, a menos que desabilitados ou tabindex=-1
        if (['a', 'button'].includes(tagName)) {
          expect(isDisabled, `Elemento ${tagName} não deve estar desabilitado`).to.be.false;
          expect(tabIndex, `Elemento ${tagName} não deve ter tabindex=-1`).to.not.equal(-1);
        } else {
          // Para outros elementos, verificar se tem tabindex >= 0
          expect(tabIndex, `Elemento ${tagName} deve ter tabindex >= 0`).to.be.gte(0);
        }
      });
    });
    // Testar elementos do dropdown APÓS abri-lo
    cy.get('button.dropbtn').click(); // Clica no botão "Contas" para abrir o dropdown
    cy.get('.dropdown-content a').each(($el) => {
      cy.wrap($el).should('be.visible'); // Agora devem estar visíveis
      cy.wrap($el).and(($el2) => {
        const tagName = $el2[0].tagName.toLowerCase();
        const hasHref = $el2[0].hasAttribute('href');
        const isDisabled = $el2[0].hasAttribute('disabled');
        const tabIndex = $el2[0].tabIndex;
        expect(isDisabled, `Elemento ${tagName} no dropdown não deve estar desabilitado`).to.be.false;
        expect(tabIndex, `Elemento ${tagName} no dropdown não deve ter tabindex=-1`).to.not.equal(-1);
      });
    });
    // Campos do formulário: inputs, selects, buttons
    // Excluímos inputs do tipo 'hidden' da verificação de visibilidade e focabilidade
    cy.get('form input:not([type="hidden"]), form select, form button').each(($el) => {
      cy.wrap($el).should('be.visible'); // Deve estar visível
      cy.wrap($el).and(($el2) => {
        const tagName = $el2[0].tagName.toLowerCase();
        const type = $el2[0].type;
        const isDisabled = $el2[0].hasAttribute('disabled');
        const tabIndex = $el2[0].tabIndex;
        expect(isDisabled, `Campo ${tagName} (type: ${type}) não deve estar desabilitado`).to.be.false;
        expect(tabIndex, `Campo ${tagName} (type: ${type}) não deve ter tabindex=-1`).to.not.equal(-1);
      });
    });
    // Links de ação (Cancelar)
    cy.get('a.btn-secondary').should('be.visible');
    cy.get('a.btn-secondary').and(($el) => {
      expect($el[0].hasAttribute('disabled'), 'Botão Cancelar não deve estar desabilitado').to.be.false;
      expect($el[0].tabIndex, 'Botão Cancelar não deve ter tabindex=-1').to.not.equal(-1);
    });
  });

  // Teste Manual: Operação de campos via teclado
  it('204 - Deve permitir a operação de todos os campos de formulário usando apenas o teclado (MANUAL)', () => {
    cy.log('**Teste Manual:** Tente interagir com todos os campos do formulário usando apenas o teclado.');
    cy.log('**Verifique:**');
    cy.log('1. Campos de Texto: Digite, selecione, copie/cole.');
    cy.log('2. Campos de Data: Digite a data ou use o seletor de data (se houver) com setas e Enter.');
    cy.log('3. Selects: Abra, navegue e selecione opções com Enter/Espaço e setas.');
    cy.log('4. Radio Buttons: Navegue entre as opções com setas e selecione com Espaço.');
    cy.log('5. Botões: Ative com Enter ou Espaço.');
    // Este teste é funcional e requer interação manual.
  });

  // 2. Rótulos e Instruções de Formulário (WCAG 1.3.1, 3.3.2)
  it('205 - Deve verificar que todos os campos de formulário possuem rótulos associados', () => {
    // Campos de input e select visíveis e com atributo 'name'
    cy.get('form input[name]:not([type="hidden"]), form select[name]').each(($el) => { // <--- MODIFICADO AQUI
      const id = $el.attr('id');
      const name = $el.attr('name');
      if (id) {
        cy.get(`label[for="${id}"]`).should('exist').and('be.visible');
      } else {
        cy.log(`WARNING: Campo "${name}" não possui ID para associação direta com label 'for'. Verifique se há um label aninhado ou aria-label.`);
      }
    });
    // Radio buttons - verificação mais específica para garantir que cada um tem um label
    cy.get('input[name="situacao"]').each(($radio) => {
      const id = $radio.attr('id');
      cy.get(`label[for="${id}"]`).should('exist').and('be.visible');
    });
  });

  // Teste Manual: Rótulos descritivos e claros
  it('206 - Deve verificar que os rótulos são descritivos e claros (MANUAL)', () => {
    cy.log('**Teste Manual:** Leia os rótulos de cada campo do formulário.');
    cy.log('**Verifique:** Os rótulos devem ser claros, concisos e descrever a finalidade do campo de forma inequívoca.');
  });

  it('207 - Deve verificar o agrupamento semântico dos Radio Buttons', () => {
    // Verifica se existe um fieldset
    cy.get('fieldset').should('exist').and('be.visible');
    // Verifica se o legend está dentro do fieldset e contém o texto "Situação"
    cy.get('fieldset').find('legend').should('contain.text', 'Situação').and('be.visible');
    // Verifica se os radio buttons estão dentro do fieldset
    cy.get('fieldset').find('input[name="situacao"]').should('have.length', 2);
  });

  // 3. Tratamento de Erros (WCAG 3.3.1, 3.3.3)
  it('208 - Deve exibir mensagens de erro claras para campos obrigatórios', () => {
    MovimentacaoPage.submeter(); // Submete o formulário vazio
    MovimentacaoPage.validarMensagem('Selecione o tipo de movimentação.');
    MovimentacaoPage.validarMensagem('Informe a data da movimentação.');
    MovimentacaoPage.validarMensagem('Informe a data de pagamento.');
    MovimentacaoPage.validarMensagem('Descrição é obrigatória.');
    MovimentacaoPage.validarMensagem('Informe um valor.');
    MovimentacaoPage.validarMensagem('Você precisa selecionar uma conta.');
    MovimentacaoPage.validarMensagem('Selecione a situação da movimentação.');
  });

  it('209 - Deve exibir mensagem de erro para valor não numérico', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Teste valor não numérico');
    // preencherInteressado não é obrigatório, então pode ser omitido ou preenchido
    MovimentacaoPage.preencherValor('abc'); // Valor não numérico
    MovimentacaoPage.selecionarConta('Conta 1'); // Certifique-se que 'Conta 1' existe
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Valor inválido.');
  });

  it('210 - Deve exibir mensagem de erro para descrição com mais de 30 caracteres', () => {
    const descricaoLonga = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'; // 31 caracteres
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao(descricaoLonga);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Descrição deve ter no máximo 30 caracteres.');
    cy.url().should('include', '/movimentacao'); // Deve permanecer na página de formulário
  });

  // Teste Manual: Foco movido para o primeiro campo com erro
  it('211 - Deve verificar que o foco é movido para o primeiro campo com erro (MANUAL/LEITOR DE TELA)', () => {
    cy.log('**Teste Manual:** Submeta o formulário com múltiplos erros (ex: tipo vazio, descrição longa).');
    cy.log('**Verifique:**');
    cy.log('1. O foco do teclado deve se mover para o primeiro campo que contém um erro.');
    cy.log('2. Use um leitor de tela para verificar se o erro é anunciado automaticamente.');
  });

  // 4. Contraste de Cores (WCAG 1.4.3)
  // Teste Manual/Ferramenta: Contraste de cores
  it('212 - Deve verificar o contraste de cores do texto e elementos da UI (MANUAL/FERRAMENTA)', () => {
    cy.log('**Teste Manual/Ferramenta:** Use uma ferramenta de verificação de contraste (ex: WebAIM Contrast Checker, Axe DevTools) para analisar o contraste de cores.');
    cy.log('**Verifique:**');
    cy.log('1. Texto dos rótulos e fundo do formulário.');
    cy.log('2. Texto dos inputs e fundo dos inputs.');
    cy.log('3. Texto das mensagens flash e fundo das mensagens flash.');
    cy.log('4. Texto dos links da navbar e fundo da navbar.');
    cy.log('5. Indicador de foco (contorno ao tabular) e o elemento focado.');
    cy.log('**Resultado Esperado:** O contraste deve atender aos requisitos mínimos (4.5:1 para texto normal, 3:1 para texto grande).');
  });

  // 5. Compatibilidade com Leitor de Tela (WCAG 1.3.1, 4.1.2)
  // Teste Manual: Leitura correta de rótulos e tipos de campo por leitor de tela
  it('213 - Deve verificar a leitura correta de rótulos e tipos de campo por leitor de tela (MANUAL/LEITOR DE TELA)', () => {
    cy.log('**Teste Manual:** Navegue pela página usando um leitor de tela (ex: NVDA). Interaja com cada campo do formulário.');
    cy.log('**Verifique:** O leitor de tela deve anunciar corretamente o rótulo de cada campo e o tipo de input (ex: "Tipo da Movimentação, caixa de combinação", "Data da Movimentação, campo de data", "Descrição, campo de edição"). Para radio buttons, deve anunciar "Pago, botão de rádio, marcado" ou "Pendente, botão de rádio, não marcado".');
  });

  // Teste Manual: Anúncio automático de mensagens flash por leitor de tela
  it('214 - Deve verificar o anúncio automático de mensagens flash por leitor de tela (MANUAL/LEITOR DE TELA)', () => {
    cy.log('**Teste Manual:** Submeta o formulário para gerar uma mensagem flash (sucesso ou erro).');
    cy.log('**Verifique:** O leitor de tela deve anunciar a mensagem flash automaticamente assim que ela aparecer, sem que o usuário precise navegar até ela. (Isso geralmente requer `role="alert"` ou `aria-live="assertive"` nas divs de alerta).');
  });

  // 6. Estrutura e Semântica (WCAG 1.3.1)
  it('215 - Deve verificar o uso semântico de headings', () => {
    cy.get('h2').should('contain.text', 'Criar Movimentação').and('be.visible');
    // Se houver um h1 principal no base.html, pode-se verificar que não há outro h1 aqui
    // cy.get('h1').should('not.exist'); 
  });

  // Teste Manual/Ferramenta: Uso correto de atributos ARIA
  it('216 - Deve verificar o uso correto de atributos ARIA (MANUAL/FERRAMENTA)', () => {
    cy.log('**Teste Manual/Ferramenta:** Use ferramentas como Axe DevTools ou inspecione o HTML para verificar o uso de atributos ARIA.');
    cy.log('**Verifique:** Atributos ARIA (ex: `aria-label`, `aria-describedby`, `aria-expanded`) devem ser usados corretamente para melhorar a acessibilidade de componentes complexos (como dropdowns, seletor de data, etc.) quando o HTML semântico não é suficiente.');
  });

  // 7. Responsividade e Zoom (WCAG 1.4.4, 1.4.10)
  // Teste Manual: Conteúdo legível e utilizável com zoom
  it('217 - Deve garantir que o conteúdo é legível e utilizável com zoom de 200% e 400% (MANUAL)', () => {
    cy.log('**Teste Manual:** Aumente o zoom do navegador para 200% e depois para 400%.');
    cy.log('**Verifique:** O conteúdo da página deve se adaptar, sem sobreposição, corte de texto ou necessidade de rolagem horizontal. Todos os elementos devem permanecer acessíveis e legíveis.');
  });

  // Teste Manual: Layout responsivo em diferentes tamanhos de tela
  it('218 - Deve garantir que o layout é responsivo e utilizável em diferentes tamanhos de tela (MANUAL)', () => {
    cy.log('**Teste Manual:** Redimensione a janela do navegador para simular telas menores (ex: mobile, tablet).');
    cy.log('**Verifique:** O layout deve se ajustar fluidamente, e todos os elementos devem ser acessíveis e utilizáveis sem rolagem horizontal.');
  });

  it('219 - Deve verificar que o título da página é único e descritivo', () => {
    cy.title().should('match', /Movimentação/i);
  });

  //home - funcional
  it('220 - Deve redirecionar para a página de detalhes da conta ao clicar no link', () => {
    // Verifica se pelo menos uma conta está listada
    cy.get('table tbody tr td a').first().should('be.visible').then(($link) => {
      const href = $link.attr('href');      
      // Clica no link e valida se a URL mudou corretamente
      cy.wrap($link).click();
      cy.url().should('include', href);
      // Validação extra: a página de detalhes deve conter algum identificador, como título
      cy.contains('Detalhes da Conta').should('be.visible');
    });
  });

  //home - usabilidade - TAB
  it('221 - Deve ser visualmente claro que o nome da conta é um link (MANUAL)', () => {
    cy.get('table tbody td a').should('have.length.at.least', 1).then(($links) => {
      const totalLinks = $links.length;
      // Itera sobre cada link
      for (let i = 0; i < totalLinks; i++) {
        // Foca diretamente no link pela posição
        cy.get('table tbody td a').eq(i).focus().should('have.focus');
        // Captura o href
        cy.get('table tbody td a').eq(i).invoke('attr', 'href').then((href) => {
        // Pressiona Enter
        cy.realPress('Enter');
        // Verifica que a URL foi atualizada
        cy.url().should('include', href);
        // Volta para a home para continuar o teste com o próximo link
          if (i < totalLinks - 1) {
            cy.visit('/home');
          }
          });
      }
    });
  });
});

describe('Página Resumo Mensal - Testes Funcionais', () => {
  beforeEach(() => {
    cy.session('sessao-resumo', () => {
      cy.visit('/login');
      cy.get('input[placeholder="Email"]').type('resumo.mensal@resumo.mensal');
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    cy.visit('/resumo');
  });

  it('222 - Deve carregar filtros com mês, ano e tipo corretos', () => {
    const now = new Date();
    const currentMonth = (now.getMonth() + 1).toString();
    const currentYear = now.getFullYear().toString();
    cy.get('#mes').should('have.value', currentMonth);
    cy.get('#ano').should('have.value', currentYear);
    cy.get('#tipo').should('have.value', 'todos');
  });

  it('223 - Deve exibir mensagem de dados ausentes em conta sem movimentação', () => {
    cy.get('table.table').should('exist');
    cy.get('tbody tr').then(rows => {
      if (rows.length === 1) {
        cy.get('tbody tr td').first().should('contain', 'Nenhuma movimentação encontrada');
      } 
    });
  });

  it('224 - Deve validar a estrutura de uma linha da tabela de resumo', () => {
  cy.get('table thead tr').within(() => {
      cy.get('th').should('have.length', 7);
      cy.get('th').eq(0).should('contain.text', 'Descrição');
      cy.get('th').eq(1).should('contain.text', 'Data Movimentação');
      cy.get('th').eq(2).should('contain.text', 'Data Pagamento');
      cy.get('th').eq(3).should('contain.text', 'Conta');
      cy.get('th').eq(4).should('contain.text', 'Valor');
      cy.get('th').eq(5).should('contain.text', 'Situação');
      cy.get('th').eq(6).should('contain.text', 'Ações');
    });
  });

  it('225 - Deve permitir alterar mês e ano e manter resultado coerente', () => {
    const anoAlvo = (new Date().getFullYear() - 1).toString();
    cy.get('#mes').select('1'); // Janeiro
    cy.get('#ano').select(anoAlvo);
    cy.get('button[type="submit"]').click();
    cy.url().should('include', 'mes=1');
    cy.url().should('include', `ano=${anoAlvo}`);
  });

  it('226 - Deve exibir mensagem apropriada para filtros sem resultados', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2026'); // Supondo que não há dados
    cy.get('#tipo').select('todos');
    cy.get('button[type="submit"]').click();
    cy.contains('Nenhuma movimentação encontrada para este período.').should('be.visible');
  });
})

describe('Validar resumos mensal', () => {
  beforeEach(() => {
    cy.session('sessao-resumo', () => {
      cy.visit('/login');
      cy.get('input[placeholder="Email"]').type('resumo.movimento@resumo.com');
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    cy.visit('/resumo');
  });

  it('227 - Deve filtrar corretamente por tipo "Receitas"', () => {
    cy.get('#mes').select('1');
    cy.get('#tipo').select('receita');
    cy.get('button[type="submit"]').click();
    cy.url().should('include', 'tipo=receita');
    cy.get('tbody tr td:nth-child(5)').each($td => {
      cy.wrap($td).should('have.css', 'color').and('match', /rgb\(0,\s*128,\s*0\)/); // verde
    });
  });

  it('228 - Deve filtrar corretamente por tipo "Despesas"', () => {
    cy.get('#mes').select('1');
    cy.get('#tipo').select('despesa');
    cy.get('button[type="submit"]').click();
    cy.url().should('include', 'tipo=despesa');
    cy.get('tbody tr td:nth-child(5)').each($td => {
      cy.wrap($td).should('have.css', 'color').and('match', /rgb\(255,\s*0,\s*0\)/); // vermelho
    });
  });

  it('229 - Deve manter filtros selecionados na URL após busca', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('despesa');
    cy.get('button[type="submit"]').click();
    cy.url().should('include', 'mes=1');
    cy.url().should('include', 'ano=2025');
    cy.url().should('include', 'tipo=despesa');
  });

  it('230 - Deve exibir mensagem apropriada para filtros sem resultados', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2020'); // Supondo que não há dados
    cy.get('#tipo').select('receita');
    cy.get('button[type="submit"]').click();
    cy.contains('Nenhuma movimentação encontrada para este período.').should('be.visible');
  });

  it('231 - Deve filtrar por mês 01/2025 e tipo receita e validar movimentações', () => {
  cy.get('#mes').select('1'); // Janeiro
  cy.get('#ano').select('2025');
  cy.get('#tipo').select('receita');
  cy.get('button[type="submit"]').click();

  cy.get('tbody tr').each(($tr) => {
    cy.wrap($tr).within(() => {
      // Verifica se a data é de janeiro/2025
      cy.get('td').eq(1).invoke('text').then((dataTexto) => {
        cy.log(`🕒 Data exibida: ${dataTexto.trim()}`);
        const [ano, mes] = dataTexto.trim().split('-');
        expect(mes).to.equal('01');
        expect(ano).to.equal('2025');
      });

      // Verifica se o valor está positivo (R$ e verde indica receita)
      cy.get('td').eq(5).invoke('text').should('include', 'R$');
      
      // Verifica se a situação é "Pago"
      cy.get('td').eq(6).should('contain.text', 'Pago');
    });
  });
});

it('232 - Deve filtrar por mês 01/2025 e tipo receita e validar movimentações', () => {
  cy.get('#mes').select('2'); // Janeiro
  cy.get('#ano').select('2025');
  cy.get('#tipo').select('despesa');
  cy.get('button[type="submit"]').click();

  cy.get('tbody tr').each(($tr) => {
    cy.wrap($tr).within(() => {
      // Verifica se a data é de janeiro/2025
      cy.get('td').eq(1).invoke('text').then((dataTexto) => {
        cy.log(`🕒 Data exibida: ${dataTexto.trim()}`);
        const [ano, mes] = dataTexto.trim().split('-');
        expect(mes).to.equal('02');
        expect(ano).to.equal('2025');
      });
      // Verifica se o valor está positivo (R$ e verde indica receita)
      cy.get('td').eq(3).invoke('text').should('include', 'R$');      
      // Verifica se a situação é "Pendente"
      cy.get('td').eq(5).should('contain.text', 'Pendente');
    });
  });
});

  it('233. Deve carregar o resumo de Março de 2025 (Receitas) diretamente via URL', () => {
    cy.visit('/resumo?mes=3&ano=2025&tipo=receita');

    // Verifica se os filtros estão selecionados corretamente
    cy.get('#mes').should('have.value', '3');
    cy.get('#ano').should('have.value', '2025');
    cy.get('#tipo').should('have.value', 'receita');

    // Verifica se as movimentações corretas estão visíveis (de Março, Receitas)
    cy.contains('td', 'Venda H').should('be.visible');
    cy.contains('td', 'Venda C').should('be.visible');
    cy.get('table tbody tr').should('have.length', 8); // 6 Venda H + 2 Venda C

    // Verifica que despesas não estão visíveis
    cy.contains('td', 'Compra Z').should('not.exist');
  });

  // --- Cenário 2: Filtragem por Mês e Ano (Janeiro de 2025) ---
  it('234 Deve exibir todas as 9 movimentações de Janeiro de 2025 (Receita e Despesa)', () => {
    cy.get('#mes').select('1'); // Janeiro
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('todos');
    cy.get('.btn-primary').contains('Buscar').click();

    cy.url().should('include', 'mes=1')
            .and('include', 'ano=2025')
            .and('include', 'tipo=todos');

    // Lista das movimentações esperadas
    const movimentacoesEsperadas = [
      { descricao: 'Compra I', conta: 'Conta 4', valor: 'R$ 220,00' },
      { descricao: 'Compra D', conta: 'Conta 4', valor: 'R$ 120,00' },
      { descricao: 'Compra D', conta: 'Conta 4', valor: 'R$ 120,00' },
      { descricao: 'Venda F', conta: 'Conta 2', valor: 'R$ 500,00' },
      { descricao: 'Venda F', conta: 'Conta 2', valor: 'R$ 500,00' },
      { descricao: 'Venda F', conta: 'Conta 1', valor: 'R$ 500,00' },
      { descricao: 'Venda F', conta: 'Conta 1', valor: 'R$ 500,00' },
      { descricao: 'Venda F', conta: 'Conta 1', valor: 'R$ 500,00' },
      { descricao: 'Venda A', conta: 'Conta 1', valor: 'R$ 1.500,00' },
    ];

    // Valida a quantidade de movimentações
    cy.get('tbody tr').should('have.length', movimentacoesEsperadas.length);

    movimentacoesEsperadas.forEach(({ descricao, conta, valor }) => {
    cy.get('tbody').within(() => {
      cy.contains('tr', descricao).within(() => {
        cy.contains('td', conta).should('exist');
        cy.contains('td', valor).should('exist');
      });
     });
    }); 
  });

  it('235 - Deve exibir apenas as despesas de Janeiro de 2025 (3 movimentações)', () => {
    cy.get('#mes').select('1'); // Janeiro
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('despesa');
    cy.contains('button', 'Buscar').click();

    // Garante que existem exatamente 2 movimentações
    cy.get('tbody tr').should('have.length', 2);

    // Verifica se as duas descrições esperadas estão visíveis
    cy.contains('td', 'Compra I').should('be.visible');
    cy.contains('td', 'Compra D').should('be.visible');

    // Verifica que receitas como 'Venda A' não aparecem
    cy.contains('td', 'Venda').should('not.exist');
  });

});


describe('Exclusão de Movimentação', () => {
  // Dados do usuário (já existente no DB, conforme sua solicitação)
  const USER_EMAIL = 'resumo.excluir@resumoexcluir.com';
  const USER_PASSWORD = 'login_10';

  let dynamicMovDescription;
  before(() => {
 
    cy.session(USER_EMAIL, () => {
      LoginPage.login(USER_EMAIL, USER_PASSWORD);
      cy.url().should('include', '/home'); 
    });

    dynamicMovDescription = `Movimento para Excluir ${Cypress._.uniqueId()}`;

    const movimentacaoParaTeste = {
      descricao: dynamicMovDescription,
      interessado: 'Teste Exclusão Cypress',
      tipo: 'despesa', // Pode ser 'receita' ou 'despesa'
      data_movimentacao: '2025-06-23', // Ajustado para data atual/futura
      data_pagamento: '2025-06-23',
      valor: '123.45',
      conta: 'Conta 1', // Esta conta DEVE existir para o USER_EMAIL
      situacao: 'pago',
    };

    // Navega para a página de criação de movimentação
    MovimentacaoPage.visitar();
    
    // Preenche e submete o formulário de movimentação
    MovimentacaoPage.selecionarTipo(movimentacaoParaTeste.tipo);
    MovimentacaoPage.preencherDataMovimentacao(movimentacaoParaTeste.data_movimentacao);
    MovimentacaoPage.preencherDataPagamento(movimentacaoParaTeste.data_pagamento);
    MovimentacaoPage.preencherDescricao(movimentacaoParaTeste.descricao);
    MovimentacaoPage.preencherInteressado(movimentacaoParaTeste.interessado);
    cy.get('input[name="valor"]').clear().type(movimentacaoParaTeste.valor);
    MovimentacaoPage.selecionarConta(movimentacaoParaTeste.conta);
    MovimentacaoPage.selecionarSituacao(movimentacaoParaTeste.situacao);

    MovimentacaoPage.submeter();
    
    // Verifica se a submissão foi bem-sucedida e redirecionou para o resumo
    cy.url().should('include', '/resumo');
    if (movimentacaoParaTeste.tipo === 'receita') {
      cy.contains('Receita incluída com sucesso!').should('exist');
    } else { // Assume que é despesa
      cy.contains('Despesa incluída com sucesso!').should('exist');
    }
    cy.visit('/resumo');
  });

it('236 - Deve cancelar exclusão se usuário negar confirmação', () => {
  cy.contains('td', dynamicMovDescription).should('exist');

  // Intercepta o confirm e retorna false (Cancel)
  cy.on('window:confirm', (text) => {
    expect(text).to.contains('Tem certeza que deseja excluir esta movimentação?');
    return false;
  });

  cy.contains('td', dynamicMovDescription)
    .parent('tr')
    .find('button.btn-danger')
    .click();

  // Valida que a movimentação ainda existe
  cy.contains('td', dynamicMovDescription).should('exist');
});

 beforeEach(() => {
    cy.session(USER_EMAIL, () => {
      LoginPage.login(USER_EMAIL, USER_PASSWORD); 
    });
    cy.visit('/resumo');
    cy.reload();
  });

  it('237 - Deve excluir uma movimentação com sucesso', () => {
    cy.contains('td', dynamicMovDescription).should('be.visible');
    // Stubs a função window.confirm para aceitar a exclusão
    cy.on('window:confirm', (text) => {
      expect(text).to.contains('Tem certeza que deseja excluir esta movimentação?');
      return true; // Clica em OK
    });
    cy.contains('td', dynamicMovDescription)
      .parent('tr') 
      .find('button.btn-danger') 
      .click(); 
    cy.contains('Movimentação excluída com sucesso!').should('be.visible');
    cy.contains('td', dynamicMovDescription).should('not.exist');
  });
});

describe('Usabilidade e Acessibilidade)', () => {
const USER_EMAIL = 'resumo.movimento@resumo.com';
  const USER_PASSWORD = 'login_10';

  beforeEach(() => {
    cy.session(USER_EMAIL, () => {
      LoginPage.login(USER_EMAIL, USER_PASSWORD);
    });
    cy.visit('/resumo');
    cy.injectAxe();
    cy.get('table tbody tr').should('exist');
  });
  
  // Exemplo de teste geral de acessibilidade via axe para toda a página Resumo
  it('238 - Página Resumo não deve ter violações de acessibilidade axe', () => {
    // Espera a UI estar estável antes de rodar axe
    cy.wait(500); // às vezes necessário para animações ou carregamento JS

    cy.checkA11y(null, {
      includedImpacts: ['critical', 'serious'], // focar nos mais importantes
      rules: {
        // desabilitar regra que falha indevidamente, se houver
        'color-contrast': { enabled: true }, // geralmente deve estar ativo
      }
    });
  });

  it('239. Filtros - Tabela não atualiza sem clicar em Buscar', () => {
    cy.get('table tbody tr').should('have.length.greaterThan', 0);

    cy.get('#mes').select('1'); // Janeiro
    cy.url().should('not.include', 'mes=1');

    const currentMonth = new Date().getMonth() + 1;
    if (currentMonth !== 1) {
      cy.get('#mes').should('have.value', '1');
      cy.url().should('not.include', `mes=1`);
    } else {
      cy.log('Mês atual é Janeiro, pulando verificação.');
    }
  });

  it('240. Cada linha deve ter botão "Excluir" visível e dentro de um form', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('todos');
    cy.get('.btn-primary').contains('Buscar').click();

    cy.get('table tbody tr').each(($row) => {
      if (!$row.text().includes('Nenhuma movimentação encontrada')) {
        cy.wrap($row).find('form').should('exist');
        cy.wrap($row).find('form button.btn-danger.btn-sm')
          .should('be.visible')
          .and('contain.text', 'Excluir');
      }
    });
  });


  it('241. Não deve exibir mensagens de erro inesperadas', () => {
    cy.get('.flash.danger').should('not.exist');
    cy.get('.alert-danger').should('not.exist');
    cy.contains(/Erro:/i).should('not.exist');
  });

  // Para testes de cor, usar assertiva aproximada
  const assertCorAproximada = (el, rgbEsperado) => {
    cy.wrap(el)
      .should('have.text')
      .then(() => {
        cy.wrap(el)
          .should('have.css', 'color')
          .then((color) => {
            expect(color).to.match(new RegExp(rgbEsperado.replace(/\s/g,'')));
          });
      });
  };

  it('242. Valores de Receita são verdes e formatados corretamente', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('receita');
    cy.get('.btn-primary').contains('Buscar').click();

    // Pega uma linha com receita (exemplo: 'Venda A')
    cy.contains('table tbody tr td', 'Venda A').parent('tr').within(() => {
      cy.get('td').eq(4).should('contain.text', 'R$') // coluna valor
        .and(($td) => {
          const color = $td.css('color');
          expect(color).to.match(/rgb\(0,\s?128,\s?0\)|rgb\(0,\s?255,\s?0\)/); // verde
        });
    });
  });

  it('243. Valores de Despesa são vermelhos e formatados', () => {
    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('despesa');
    cy.get('.btn-primary').contains('Buscar').click();

    cy.contains('td', 'Compra D').parent('tr').within(() => {
      cy.get('td').eq(4).should('have.text', 'R$ 120,00')
        .and(($td) => {
          const cor = $td.css('color');
          expect(cor).to.match(/rgb\(255,\s?0,\s?0\)/); // vermelho
        });
    });
  });

  it('244. Situações "Pago" e "Pendente" capitalizadas', () => {
    cy.get('#mes').select('2');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('todos');
    cy.get('.btn-primary').contains('Buscar').click();

    cy.contains('td', 'Compra G').parent('tr').within(() => {
      cy.get('td').eq(5).invoke('text').should('match', /^Pendente$/);
    });

    cy.get('#mes').select('1');
    cy.get('#ano').select('2025');
    cy.get('#tipo').select('todos');
    cy.get('.btn-primary').contains('Buscar').click();

    cy.contains('td', 'Venda F').parent('tr').within(() => {
      cy.get('td').eq(5).invoke('text').should('match', /^Pago$/);
    });
  });

  it('245. Mensagem "Nenhuma movimentação encontrada" aparece corretamente', () => {
    cy.get('#mes').select('12');
    cy.get('#ano').select('2020');
    cy.get('#tipo').select('todos');
    cy.get('.btn-primary').contains('Buscar').click();

    cy.get('table tbody tr').should('have.length', 1);
    cy.get('table tbody tr td[colspan="7"]')
      .should('contain.text', 'Nenhuma movimentação encontrada para este período.');
  });

  it('247. Navegação por tabulação e preenchimento do formulário', () => {
    cy.visit('/resumo');
    cy.get('#mes').focus();
    cy.realPress('Tab'); // ano
    cy.focused().should('have.attr', 'id', 'ano').select('2025');
    cy.realPress('Tab'); // tipo
    cy.focused().should('have.attr', 'id', 'tipo').select('receita');
    cy.realPress('Tab'); // botão Buscar
    cy.focused().should('contain.text', 'Buscar').realPress('Enter');
    // Validação de que o filtro foi aplicado e tabela atualizada
    cy.url().should('include', 'ano=2025');
    cy.url().should('include', 'tipo=receita');
    cy.get('table tbody tr').its('length').should('be.greaterThan', 0);
  });

  it('248. Validar busca utilizando o preenchimento padrão do app, mês e ano atual', () => {
    const hoje = new Date();
    const mesAtual = (hoje.getMonth() + 1).toString();
    const anoAtual = hoje.getFullYear().toString();

    cy.visit('/resumo');
    cy.get('#mes').should('have.value', mesAtual);
    cy.get('#ano').should('have.value', anoAtual);
  });

  it('249. Elementos não interativos não recebem foco por tabulação', () => {
    cy.get('#server-date').should('not.be.visible');
    // A ausência dele na tabulação é garantida no teste 246.
  });
});

describe('Exclusão de Movimentação via tab', () => {
  const USER_EMAIL = 'excluir.tab@excluir.com';
  const USER_PASSWORD = 'login_10';

  let dynamicMovDescription;
  
  before(() => {
    cy.session(USER_EMAIL, () => {
      LoginPage.login(USER_EMAIL, USER_PASSWORD);
      cy.url().should('include', '/home'); 
    });

    dynamicMovDescription = `Movimento para Excluir ${Cypress._.uniqueId()}`;

    const movimentacaoParaTeste = {
      descricao: dynamicMovDescription,
      interessado: 'Teste Exclusão Cypress',
      tipo: 'despesa',
      data_movimentacao: '2025-06-23',
      data_pagamento: '2025-06-23',
      valor: '123.45',
      conta: 'Conta 1',
      situacao: 'pago',
    };

    MovimentacaoPage.visitar();
    MovimentacaoPage.selecionarTipo(movimentacaoParaTeste.tipo);
    MovimentacaoPage.preencherDataMovimentacao(movimentacaoParaTeste.data_movimentacao);
    MovimentacaoPage.preencherDataPagamento(movimentacaoParaTeste.data_pagamento);
    MovimentacaoPage.preencherDescricao(movimentacaoParaTeste.descricao);
    MovimentacaoPage.preencherInteressado(movimentacaoParaTeste.interessado);
    cy.get('input[name="valor"]').clear().type(movimentacaoParaTeste.valor);
    MovimentacaoPage.selecionarConta(movimentacaoParaTeste.conta);
    MovimentacaoPage.selecionarSituacao(movimentacaoParaTeste.situacao);
    MovimentacaoPage.submeter();
    
    cy.url().should('include', '/resumo');
    cy.contains('Despesa incluída com sucesso!').should('exist');
    cy.visit('/resumo');
  });

  beforeEach(() => {
    cy.session(USER_EMAIL, () => {
      LoginPage.login(USER_EMAIL, USER_PASSWORD); 
    });
    cy.visit('/resumo');
  });

  it('250 - Deve validar cancelar exclusão via teclado (tab + enter para cancelar)', () => {
    cy.contains('td', dynamicMovDescription).should('exist');

    // Força o foco para o botão Excluir da movimentação criada
    cy.contains('td', dynamicMovDescription)
      .parent('tr')
      .find('button.btn-danger')
      .focus()
      .should('have.focus');

    // Simula o usuário apertando Enter no botão Excluir para abrir o confirm
    cy.window().then((win) => {
      cy.stub(win, 'confirm').callsFake((msg) => {
        expect(msg).to.include('Tem certeza que deseja excluir esta movimentação?');
        return false; // Simula clicar em Cancelar no confirm
      }).as('confirmStub');
    });

    cy.focused().realPress('Enter');

    // Validar que o confirm foi chamado
    cy.get('@confirmStub').should('have.been.calledOnce');

    // A movimentação deve continuar visível (não excluída)
    cy.contains('td', dynamicMovDescription).should('exist');
  });

  it('251 - Deve validar confirmar exclusão via teclado (tab + enter para confirmar)', () => {
    cy.contains('td', dynamicMovDescription).should('exist');

    // Foca o botão Excluir e confirma a exclusão com Enter
    cy.contains('td', dynamicMovDescription)
      .parent('tr')
      .find('button.btn-danger')
      .focus()
      .should('have.focus');

    cy.window().then((win) => {
      cy.stub(win, 'confirm').callsFake((msg) => {
        expect(msg).to.include('Tem certeza que deseja excluir esta movimentação?');
        return true; // Simula clicar em OK no confirm
      }).as('confirmStub');
    });

    cy.focused().realPress('Enter');

    cy.get('@confirmStub').should('have.been.calledOnce');

    // Valida mensagem de sucesso e que a movimentação sumiu
    cy.contains('Movimentação excluída com sucesso!').should('be.visible');
    cy.contains('td', dynamicMovDescription).should('not.exist');
  });
});

