import LoginPage from '../support/page_objects/loginPage';

describe('ContaFácil - Página Listar Conta', () => {
  beforeEach(() => {
    cy.session('sessao-pagina-listar', () => {
      LoginPage.login('contalistar@contalistar.com', 'login_10');
    });
    cy.visit('/contas'); // Visite APÓS sessão estar criada
  });

  it('148 - Deve exibir título e botão "Adicionar Conta"', () => {
    cy.contains('h1', 'Contas Cadastradas').should('be.visible');
    cy.get('a.btn-success').should('contain', 'Adicionar Conta');
  });

  it('149 - Deve exibir tabela com cabeçalhos "Conta" e "Ações"', () => {
    cy.get('table').should('be.visible');
    cy.get('thead tr th').eq(0).should('contain.text', 'Conta');
    cy.get('thead tr th').eq(1).should('contain.text', 'Ações');
  });

  it('150 - Deve validar a mensagem: Nenhuma conta cadastrada.', () => {
    cy.get('tbody tr').then(rows => {
      if (rows.length === 1) {
        cy.get('tbody tr td').should('contain.text', 'Nenhuma conta cadastrada.');
      } else {
        cy.get('tbody tr').each(row => {
          cy.wrap(row).find('td').eq(0).should('not.be.empty');
        });
      }
    });
  });

 it('151 - Deve adicionar conta', () => {
    const nome = 'Conta adicionada';
    cy.get('a.btn-success').click();  // Clicar no botão "Adicionar Conta"
    cy.url().should('include', '/contas/adicionar');
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    // Após salvar, deve voltar para listar contas e mostrar mensagem de sucesso
    cy.url().should('include', '/contas');
    cy.contains('Conta adicionada com sucesso!').should('be.visible');
    // Validar que a nova conta aparece na tabela
    cy.contains('td', nome).should('exist');
    // Guardar nome para usar nos próximos testes
    cy.wrap(nome).as('nomeConta');
  });

  it('152 - Não deve permitir duplicar nome de conta já existente', () => {
    const nome = 'Conta adicionada';
    cy.get('a.btn-success').click();  // Clicar no botão "Adicionar Conta"
    cy.url().should('include', '/contas/adicionar');
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    // Após salvar, deve voltar para listar contas e mostrar mensagem de sucesso
    cy.url().should('include', '/contas');
    cy.contains('Já existe uma conta com esse nome.').should('be.visible');
});

  it('153 - Cada conta listada deve conter botões de Detalhes, Editar e Excluir', () => {
    cy.get('tbody tr').each(row => {
      if (!row.text().includes('Nenhuma conta cadastrada.')) {
        cy.wrap(row).find('a.btn-primary').should('contain.text', 'Detalhes');
        cy.wrap(row).find('a.btn-warning').should('contain.text', 'Editar');
        cy.wrap(row).find('button.btn-danger').should('contain.text', 'Excluir');
      }
    });
  });

  it('154 - Botão Detalhes deve abrir em nova aba com target _blank e rel seguro', () => {
    cy.get('a.btn-primary').each(link => {
      cy.wrap(link).should('have.attr', 'target', '_blank');
      cy.wrap(link).should('have.attr', 'rel', 'noopener noreferrer');
    });
  });

  it('155 - Formulário de exclusão deve conter token CSRF', () => {
    cy.get('form').each(form => {
      cy.wrap(form).should('contain.html', 'csrf_token');
    });
  });

  it('156 - Ao clicar em "Excluir" deve exibir confirmação antes de enviar', () => {
    cy.window().then(win => {
      cy.stub(win, 'confirm').returns(false);
    });
    cy.get('button.btn-danger').first().click();
    cy.url().should('include', '/contas');
  });

  it('157 - Links de ação não devem permitir navegação sem autenticação', () => {
    cy.clearCookies();
    cy.visit('/contas', { failOnStatusCode: false });
    cy.url().should('include', '/login');
  });

  it('158 - Não deve permitir exclusão via requisição POST sem token CSRF', () => {
    cy.request({
      method: 'POST',
      url: '/contas/1/excluir',
      failOnStatusCode: false,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: ''
    }).then((response) => {
      expect(response.status).to.not.eq(200);
    });
  });

  it('159 - Campos da tabela não devem permitir script injection', () => {
    cy.get('tbody td').each(cell => {
      cy.wrap(cell).should('not.contain.text', '<script>');
    });
  });

  it('160 - Validar botão "Detalhes"', () => {
  // Localiza o botão "Detalhes" da primeira conta
    cy.get('a.btn-primary').contains('Detalhes')
      // Remove o atributo target para evitar abertura em nova aba (necessário para Cypress)
      .invoke('removeAttr', 'target')
      .click();

    // O botão "Detalhes" tem target="_blank", o que abre nova aba.
    // Cypress não suporta múltiplas abas, então removemos o target para validar a página aberta.
  
    // Valida se estamos na página correta
    cy.url().should('include', '/contas/detalhes');
    // Verifica se o título da página de detalhes está presente
    cy.get('h2').should('contain.text', 'Detalhes da Conta');
  });

  it('161 - Deve editar a conta criada e validar a alteração', function () {
    cy.visit('/contas'); // garantir estamos na página certa
    // Encontrar a linha da conta pelo nome da alias criada no teste anterior
    cy.contains('td', this.nomeConta)
      .parent('tr')
      .within(() => {
        cy.get('a.btn-warning').click(); // botão Editar
      });
    cy.url().should('include', '/contas/editar');
    // Alterar nome da conta
    const novoNome = `${this.nomeConta} Editada`;
    cy.get('input[name="nome"]').clear().type(novoNome);
    cy.get('button[type="submit"]').click();
    // Voltar para listar contas e verificar alteração
    cy.url().should('include', '/contas');
    cy.contains('Conta atualizada com sucesso!').should('be.visible');
    cy.contains('td', novoNome).should('exist');
    // Atualizar alias para próximo teste
    cy.wrap(novoNome).as('nomeConta');
  });

  it('162 - Deve excluir a conta editada e validar remoção', function () {
    cy.visit('/contas'); 
    // Encontrar a linha da conta pelo nome atualizado
    cy.contains('td', this.nomeConta)
      .parent('tr')
      .within(() => {
        // interceptar o confirm e aceitar automaticamente
        cy.window().then(win => {
          cy.stub(win, 'confirm').returns(true);
        });
        cy.get('button.btn-danger').click(); // botão Excluir
      });
    // Validar que a conta foi removida da lista
    cy.contains('td', this.nomeConta).should('not.exist');
  });
});

describe('Validar ordem alfabética da lista de contas', () => {
  beforeEach(() => {
    // Faz login antes de cada teste
    LoginPage.login('ordemAlfabetica@ordem.com', 'login_10');
    cy.visit('/contas');
    cy.contains('h1', 'Contas Cadastradas').should('be.visible'); // Garante que carregou
  });

  it('163 - Contas devem estar ordenadas alfabeticamente por nome', () => {
    cy.get('tbody tr td:first-child').then(($els) => {
      const nomes = [...$els].map(el => el.innerText.trim());
      const nomesOrdenados = [...nomes].sort((a, b) => a.localeCompare(b));
      expect(nomes).to.deep.equal(nomesOrdenados);
    });
  });

  it('164 - Excluir conta "A" e validar que as contas permanecem ordenadas alfabeticamente', () => {
    cy.on('window:confirm', () => true); // Aceita confirmação

    // Verifica se conta 'A' existe antes de tentar excluir
    cy.get('tbody tr').then(($rows) => {
      const row = [...$rows].find(r => r.innerText.trim().startsWith('A'));
      if (row) {
        cy.wrap(row).within(() => {
          cy.get('form button[type="submit"]').click();
        });

        // Valida ordenação após exclusão
        cy.get('tbody tr td:first-child').then(($els) => {
          const nomes = [...$els].map(el => el.innerText.trim());
          const nomesOrdenados = [...nomes].sort((a, b) => a.localeCompare(b));
          expect(nomes).to.deep.equal(nomesOrdenados);
        });
      } else {
        cy.log('Conta "A" não encontrada para exclusão.');
      }
    });
  });

  it('165 - Deve validar a ordem alfabética após a inclusão do nome "A"', () => {
    const nome = 'A';
    cy.get('a.btn-success').should('be.visible').click();
    cy.url().should('include', '/contas/adicionar');
    cy.get('input[name="nome"]').clear().type(nome);
    cy.get('button[type="submit"]').click();
    cy.url().should('include', '/contas');
    cy.contains('Conta adicionada com sucesso!').should('be.visible');

    cy.get('tbody tr td:first-child').then(($els) => {
      const nomes = [...$els].map(el => el.innerText.trim());
      const nomesOrdenados = [...nomes].sort((a, b) => a.localeCompare(b));
      expect(nomes).to.deep.equal(nomesOrdenados);
    });
  });
});
