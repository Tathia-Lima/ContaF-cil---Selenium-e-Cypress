import LoginPage from '../../support/page_objects/loginPage';

describe('Acessibilidade - Página Home', () => {

  beforeEach(() => {
    // Usa cy.session para manter login entre testes
    cy.session('user-session', () => {
    LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/home');
  });

  it('18 - Deve conter cabeçalho com texto acessível', () => {
    cy.get('h2').should('contain.text', 'Olá, LoginPage! Seja bem-vindo(a) ao ContaFácil');
  });

  it('19 - Deve conter uma tabela com títulos claros e identificáveis', () => {
    cy.get('table').should('exist');
    cy.get('table thead th').eq(0).should('contain.text', 'Conta');
    cy.get('table thead th').eq(1).should('contain.text', 'Receitas');
    cy.get('table thead th').eq(2).should('contain.text', 'Despesas');
    cy.get('table thead th').eq(3).should('contain.text', 'Saldo');
  });

  it('20 - Deve permitir navegação por teclado com foco visível', () => {
    cy.get('body').tab();
    cy.focused().should('be.visible');
  });

  it('21 - Deve passar nas verificações automáticas do axe-core', () => {
    cy.injectAxe();
    cy.checkA11y(); 
  });

  it('22 - Todos os elementos interativos devem ser acessíveis por teclado', () => {
    cy.get('button, a, input, select, textarea')
      .each(($el) => {
        cy.wrap($el).focus().should('have.focus');
      });
  });

  it('23 - Elementos devem possuir contraste adequado', () => {
    cy.injectAxe();
    cy.checkA11y(null, {
    runOnly: ['color-contrast'],
    });
  });

  it('24 - Botões devem conter texto ou aria-label', () => {
    cy.get('button').each(($btn) => {
      cy.wrap($btn).should(($el) => {
        const hasText = $el.text().trim().length > 0;
        const hasAria = $el.attr('aria-label') !== undefined;
        expect(hasText || hasAria).to.be.true;
      });
    });
  });

  it('25 - Links devem ser descritivos (sem textos como "clique aqui")', () => {
    cy.get('a').each(($a) => {
      cy.wrap($a).invoke('text').should('match', /[^\s]+/);
      cy.wrap($a).should('not.contain.text', 'clique aqui');
    });
  });

  it('26 - Página deve possuir uma linguagem definida no HTML', () => {
    cy.document().its('documentElement.lang').should('match', /^[a-z]{2}(-[A-Z]{2})?$/);
  });

  it('27 - Página não requer foco inicial automático, teste ignorado', () => {
    cy.log('Foco inicial não é necessário nesta página porque o usuário deve decidir a ação.');
  });

  it('28 - Nenhum elemento deve estar com tabindex="-1" indevidamente', () => {
    cy.get('body').then(($body) => {
      if ($body.find('[tabindex="-1"]').length > 0) {
        // Pode-se fazer lógica para verificar se está em contexto aceitável, ex: aria-live
        cy.get('[tabindex="-1"]').each($el => {
          cy.wrap($el).should('have.attr', 'aria-live'); // Exemplo de uso aceitável
        });
      } else {
        cy.log('Nenhum tabindex="-1" encontrado. Teste aprovado.');
      }
    });
  });
  
  it('227 - Deve ser visualmente claro que o nome da conta é um link que encaminha para Detalhe da Conta', () => {
    cy.get('table tbody tr').then((rows) => {
      if (rows.length === 0 || rows.text().includes('Nenhuma conta cadastrada')) {
        cy.log('Nenhuma conta cadastrada. Teste ignorado.');
        return;
      }

      cy.get('table tbody td a').first().as('linkConta');

      // Valida que o link tem target e rel seguros
      cy.get('@linkConta')
        .should('have.attr', 'target', '_blank')
        .and('have.attr', 'rel')
        .and('include', 'noopener');

      // Foca no link e garante foco visível
      cy.get('@linkConta').focus().should('have.focus');

      // Captura href e remove target para navegação na mesma aba
      cy.get('@linkConta').invoke('attr', 'href').then((href) => {
        cy.get('@linkConta').invoke('removeAttr', 'target').click();

        cy.url().should('include', href);
        cy.get('h2').should('contain.text', 'Detalhes da Conta');

        // Retorna à home
        cy.visit('/home');
      });
    });
  });

  describe('Navegation', () => {
    it('29 - Deve clicar no menu ContaFácil e abrir home', () => {
      cy.get('a.brand').click();
      cy.url().should('include', '/home');
    });

    it('30 - Deve abrir a página home pelo menu', () => {
      cy.get('a').contains('Home').click();
      cy.url().should('include', '/home');
    });

    it('31 - Deve abrir página Contas > Adicionar', () => {
      cy.get('.dropdown .dropbtn').contains('Contas').click();
      cy.get('.dropdown-content a').contains('Adicionar').click();
      cy.url().should('include', '/contas/adicionar');
    });

    // Continue para os demais links, ex:
    it('32 - Deve abrir página Contas > Listar', () => {
      cy.visit('/home');
      cy.get('.dropdown .dropbtn').contains('Contas').click();
      cy.get('.dropdown-content a').contains('Listar').click();
      // Ajuste a URL esperada conforme sua aplicação
      cy.url().should('include', '/contas'); // ou '/contas/listar' se for o correto
      // Valide o título da página, para garantir que a lista foi carregada
      cy.get('h1').should('contain.text', 'Contas Cadastradas');
    });

    it('33 - Deve abrir página Criar Movimentação', () => {
      cy.get('a').contains('Criar Movimentação').click();
      cy.url().should('include', '/movimentacao');
    });

    it('34 - Deve abrir página Resumo Mensal', () => {
      cy.get('a').contains('Resumo Mensal').click();
      cy.url().should('include', '/resumo');
    });

    it('35 - Deve clicar em sair e ir para login', () => {
      cy.get('a').contains('Sair').click();
      cy.url().should('include', '/login');
    });
  });
});