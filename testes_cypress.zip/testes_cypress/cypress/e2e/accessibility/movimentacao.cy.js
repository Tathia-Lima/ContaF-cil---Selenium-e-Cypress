// cypress/e2e/movimentacao_acessibilidade.cy.js
import MovimentacaoPage from '../../support/page_objects/MovimentacaoPage';
import LoginPage from '../../support/page_objects/loginPage';
import 'cypress-axe';

describe('Acessibilidade - Movimentação', () => {
  beforeEach(() => {
    // Garante que o usuário está logado para acessar a página de movimentação
    cy.session('user-session', () => {
      cy.visit('/login');
      cy.get('input[name=email]').type('movimentacao@movimentacao.com'); // Use um usuário existente
      cy.get('input[name=senha]').type('login_10');
      cy.get('button[type=submit]').click();
    });
    MovimentacaoPage.visitar(); // Visita a página de movimentação
    MovimentacaoPage.setupClockBasedOnServerDate(); // Sincroniza o clock do Cypress com o servidor
  });

  afterEach(() => {
    MovimentacaoPage.restoreClock(); // Restaura o clock do Cypress
  });

  // --- Testes de Acessibilidade ---
  // 1. Navegação por Teclado (WCAG 2.1.1, 2.4.3, 2.4.7)
  // Teste Manual: Ordem de foco lógica e visibilidade do indicador de foco
  it('202 - Deve verificar a ordem de foco lógica e a visibilidade do indicador de foco (MANUAL)', () => {
    cy.log('**Teste Manual:** Comece no topo da página e pressione a tecla `Tab` repetidamente.');
    cy.log('**Verifique:**');
    cy.log('1. O foco deve se mover de forma lógica e previsível por todos os elementos interativos (links da navbar, campos do formulário, botões "Salvar" e "Cancelar").');
    cy.log('2. A ordem deve ser da esquerda para a direita, de cima para baixo.');
    cy.log('3. O indicador de foco deve ser sempre visível e ter contraste suficiente com o fundo.');
    // Este teste não pode ser totalmente automatizado pelo Cypress, requer inspeção visual.
  });

  // Teste Automatizado: Focabilidade de elementos interativos
  it('203 - Deve garantir que todos os elementos interativos são focáveis via teclado (abordagem robusta)', () => {
    // Testar elementos da navbar que são visíveis por padrão
    cy.get('nav.navbar a:not(.dropdown-content a), nav.navbar button').each(($el) => {
      cy.wrap($el).should('be.visible'); // Deve estar visível
      cy.wrap($el).and(($el2) => {
        const tagName = $el2[0].tagName.toLowerCase();
        const hasHref = $el2[0].hasAttribute('href');
        const isDisabled = $el2[0].hasAttribute('disabled');
        const tabIndex = $el2[0].tabIndex;
        // Elementos interativos padrão (a, button) são focáveis por padrão, a menos que desabilitados ou tabindex=-1
        if (['a', 'button'].includes(tagName)) {
          expect(isDisabled, `Elemento ${tagName} não deve estar desabilitado`).to.be.false;
          expect(tabIndex, `Elemento ${tagName} não deve ter tabindex=-1`).to.not.equal(-1);
        } else {
          // Para outros elementos, verificar se tem tabindex >= 0
          expect(tabIndex, `Elemento ${tagName} deve ter tabindex >= 0`).to.be.gte(0);
        }
      });
    });
    // Testar elementos do dropdown APÓS abri-lo
    cy.get('button.dropbtn').click(); // Clica no botão "Contas" para abrir o dropdown
    cy.get('.dropdown-content a').each(($el) => {
      cy.wrap($el).should('be.visible'); // Agora devem estar visíveis
      cy.wrap($el).and(($el2) => {
        const tagName = $el2[0].tagName.toLowerCase();
        const hasHref = $el2[0].hasAttribute('href');
        const isDisabled = $el2[0].hasAttribute('disabled');
        const tabIndex = $el2[0].tabIndex;
        expect(isDisabled, `Elemento ${tagName} no dropdown não deve estar desabilitado`).to.be.false;
        expect(tabIndex, `Elemento ${tagName} no dropdown não deve ter tabindex=-1`).to.not.equal(-1);
      });
    });
    // Campos do formulário: inputs, selects, buttons
    // Excluímos inputs do tipo 'hidden' da verificação de visibilidade e focabilidade
    cy.get('form input:not([type="hidden"]), form select, form button').each(($el) => {
      cy.wrap($el).should('be.visible'); // Deve estar visível
      cy.wrap($el).and(($el2) => {
        const tagName = $el2[0].tagName.toLowerCase();
        const type = $el2[0].type;
        const isDisabled = $el2[0].hasAttribute('disabled');
        const tabIndex = $el2[0].tabIndex;
        expect(isDisabled, `Campo ${tagName} (type: ${type}) não deve estar desabilitado`).to.be.false;
        expect(tabIndex, `Campo ${tagName} (type: ${type}) não deve ter tabindex=-1`).to.not.equal(-1);
      });
    });
    // Links de ação (Cancelar)
    cy.get('a.btn-secondary').should('be.visible');
    cy.get('a.btn-secondary').and(($el) => {
      expect($el[0].hasAttribute('disabled'), 'Botão Cancelar não deve estar desabilitado').to.be.false;
      expect($el[0].tabIndex, 'Botão Cancelar não deve ter tabindex=-1').to.not.equal(-1);
    });
  });

  // Teste Manual: Operação de campos via teclado
  it('204 - Deve permitir a operação de todos os campos de formulário usando apenas o teclado (MANUAL)', () => {
    cy.log('**Teste Manual:** Tente interagir com todos os campos do formulário usando apenas o teclado.');
    cy.log('**Verifique:**');
    cy.log('1. Campos de Texto: Digite, selecione, copie/cole.');
    cy.log('2. Campos de Data: Digite a data ou use o seletor de data (se houver) com setas e Enter.');
    cy.log('3. Selects: Abra, navegue e selecione opções com Enter/Espaço e setas.');
    cy.log('4. Radio Buttons: Navegue entre as opções com setas e selecione com Espaço.');
    cy.log('5. Botões: Ative com Enter ou Espaço.');
    // Este teste é funcional e requer interação manual.
  });

  // 2. Rótulos e Instruções de Formulário (WCAG 1.3.1, 3.3.2)
  it('205 - Deve verificar que todos os campos de formulário possuem rótulos associados', () => {
    // Campos de input e select visíveis e com atributo 'name'
    cy.get('form input[name]:not([type="hidden"]), form select[name]').each(($el) => { // <--- MODIFICADO AQUI
      const id = $el.attr('id');
      const name = $el.attr('name');
      if (id) {
        cy.get(`label[for="${id}"]`).should('exist').and('be.visible');
      } else {
        cy.log(`WARNING: Campo "${name}" não possui ID para associação direta com label 'for'. Verifique se há um label aninhado ou aria-label.`);
      }
    });
    // Radio buttons - verificação mais específica para garantir que cada um tem um label
    cy.get('input[name="situacao"]').each(($radio) => {
      const id = $radio.attr('id');
      cy.get(`label[for="${id}"]`).should('exist').and('be.visible');
    });
  });

  // Teste Manual: Rótulos descritivos e claros
  it('206 - Deve verificar que os rótulos são descritivos e claros (MANUAL)', () => {
    cy.log('**Teste Manual:** Leia os rótulos de cada campo do formulário.');
    cy.log('**Verifique:** Os rótulos devem ser claros, concisos e descrever a finalidade do campo de forma inequívoca.');
  });

  it('207 - Deve verificar o agrupamento semântico dos Radio Buttons', () => {
    // Verifica se existe um fieldset
    cy.get('fieldset').should('exist').and('be.visible');
    // Verifica se o legend está dentro do fieldset e contém o texto "Situação"
    cy.get('fieldset').find('legend').should('contain.text', 'Situação').and('be.visible');
    // Verifica se os radio buttons estão dentro do fieldset
    cy.get('fieldset').find('input[name="situacao"]').should('have.length', 2);
  });

  // 3. Tratamento de Erros (WCAG 3.3.1, 3.3.3)
  it('208 - Deve exibir mensagens de erro claras para campos obrigatórios', () => {
    MovimentacaoPage.submeter(); // Submete o formulário vazio
    MovimentacaoPage.validarMensagem('Selecione o tipo de movimentação.');
    MovimentacaoPage.validarMensagem('Informe a data da movimentação.');
    MovimentacaoPage.validarMensagem('Informe a data de pagamento.');
    MovimentacaoPage.validarMensagem('Descrição é obrigatória.');
    MovimentacaoPage.validarMensagem('Informe um valor.');
    MovimentacaoPage.validarMensagem('Você precisa selecionar uma conta.');
    MovimentacaoPage.validarMensagem('Selecione a situação da movimentação.');
  });

  it('209 - Deve exibir mensagem de erro para valor não numérico', () => {
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao('Teste valor não numérico');
    // preencherInteressado não é obrigatório, então pode ser omitido ou preenchido
    MovimentacaoPage.preencherValor('abc'); // Valor não numérico
    MovimentacaoPage.selecionarConta('Conta 1'); // Certifique-se que 'Conta 1' existe
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Valor inválido.');
  });

  it('210 - Deve exibir mensagem de erro para descrição com mais de 30 caracteres', () => {
    const descricaoLonga = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'; // 31 caracteres
    MovimentacaoPage.selecionarTipo('receita');
    MovimentacaoPage.preencherDataMovimentacao('2025-06-20');
    MovimentacaoPage.preencherDataPagamento('2025-06-20');
    MovimentacaoPage.preencherDescricao(descricaoLonga);
    MovimentacaoPage.preencherValor(100);
    MovimentacaoPage.selecionarConta('Conta 1');
    MovimentacaoPage.selecionarSituacao('pago');
    MovimentacaoPage.submeter();
    MovimentacaoPage.validarMensagem('Descrição deve ter no máximo 30 caracteres.');
    cy.url().should('include', '/movimentacao'); // Deve permanecer na página de formulário
  });

  // Teste Manual: Foco movido para o primeiro campo com erro
  it('211 - Deve verificar que o foco é movido para o primeiro campo com erro (MANUAL/LEITOR DE TELA)', () => {
    cy.log('**Teste Manual:** Submeta o formulário com múltiplos erros (ex: tipo vazio, descrição longa).');
    cy.log('**Verifique:**');
    cy.log('1. O foco do teclado deve se mover para o primeiro campo que contém um erro.');
    cy.log('2. Use um leitor de tela para verificar se o erro é anunciado automaticamente.');
  });

  // 4. Contraste de Cores (WCAG 1.4.3)
  // Teste Manual/Ferramenta: Contraste de cores
  it('212 - Deve verificar o contraste de cores do texto e elementos da UI (MANUAL/FERRAMENTA)', () => {
    cy.log('**Teste Manual/Ferramenta:** Use uma ferramenta de verificação de contraste (ex: WebAIM Contrast Checker, Axe DevTools) para analisar o contraste de cores.');
    cy.log('**Verifique:**');
    cy.log('1. Texto dos rótulos e fundo do formulário.');
    cy.log('2. Texto dos inputs e fundo dos inputs.');
    cy.log('3. Texto das mensagens flash e fundo das mensagens flash.');
    cy.log('4. Texto dos links da navbar e fundo da navbar.');
    cy.log('5. Indicador de foco (contorno ao tabular) e o elemento focado.');
    cy.log('**Resultado Esperado:** O contraste deve atender aos requisitos mínimos (4.5:1 para texto normal, 3:1 para texto grande).');
  });

  // 5. Compatibilidade com Leitor de Tela (WCAG 1.3.1, 4.1.2)
  // Teste Manual: Leitura correta de rótulos e tipos de campo por leitor de tela
  it('213 - Deve verificar a leitura correta de rótulos e tipos de campo por leitor de tela (MANUAL/LEITOR DE TELA)', () => {
    cy.log('**Teste Manual:** Navegue pela página usando um leitor de tela (ex: NVDA). Interaja com cada campo do formulário.');
    cy.log('**Verifique:** O leitor de tela deve anunciar corretamente o rótulo de cada campo e o tipo de input (ex: "Tipo da Movimentação, caixa de combinação", "Data da Movimentação, campo de data", "Descrição, campo de edição"). Para radio buttons, deve anunciar "Pago, botão de rádio, marcado" ou "Pendente, botão de rádio, não marcado".');
  });

  // Teste Manual: Anúncio automático de mensagens flash por leitor de tela
  it('214 - Deve verificar o anúncio automático de mensagens flash por leitor de tela (MANUAL/LEITOR DE TELA)', () => {
    cy.log('**Teste Manual:** Submeta o formulário para gerar uma mensagem flash (sucesso ou erro).');
    cy.log('**Verifique:** O leitor de tela deve anunciar a mensagem flash automaticamente assim que ela aparecer, sem que o usuário precise navegar até ela. (Isso geralmente requer `role="alert"` ou `aria-live="assertive"` nas divs de alerta).');
  });

  // 6. Estrutura e Semântica (WCAG 1.3.1)
  it('215 - Deve verificar o uso semântico de headings', () => {
    cy.get('h2').should('contain.text', 'Criar Movimentação').and('be.visible');
    // Se houver um h1 principal no base.html, pode-se verificar que não há outro h1 aqui
    // cy.get('h1').should('not.exist'); 
  });

  // Teste Manual/Ferramenta: Uso correto de atributos ARIA
  it('216 - Deve verificar o uso correto de atributos ARIA (MANUAL/FERRAMENTA)', () => {
    cy.log('**Teste Manual/Ferramenta:** Use ferramentas como Axe DevTools ou inspecione o HTML para verificar o uso de atributos ARIA.');
    cy.log('**Verifique:** Atributos ARIA (ex: `aria-label`, `aria-describedby`, `aria-expanded`) devem ser usados corretamente para melhorar a acessibilidade de componentes complexos (como dropdowns, seletor de data, etc.) quando o HTML semântico não é suficiente.');
  });

  // 7. Responsividade e Zoom (WCAG 1.4.4, 1.4.10)
  // Teste Manual: Conteúdo legível e utilizável com zoom
  it('217 - Deve garantir que o conteúdo é legível e utilizável com zoom de 200% e 400% (MANUAL)', () => {
    cy.log('**Teste Manual:** Aumente o zoom do navegador para 200% e depois para 400%.');
    cy.log('**Verifique:** O conteúdo da página deve se adaptar, sem sobreposição, corte de texto ou necessidade de rolagem horizontal. Todos os elementos devem permanecer acessíveis e legíveis.');
  });

  // Teste Manual: Layout responsivo em diferentes tamanhos de tela
  it('218 - Deve garantir que o layout é responsivo e utilizável em diferentes tamanhos de tela (MANUAL)', () => {
    cy.log('**Teste Manual:** Redimensione a janela do navegador para simular telas menores (ex: mobile, tablet).');
    cy.log('**Verifique:** O layout deve se ajustar fluidamente, e todos os elementos devem ser acessíveis e utilizáveis sem rolagem horizontal.');
  });

  it('219 - Deve verificar que o título da página é único e descritivo', () => {
    cy.title().should('match', /Movimentação/i);
  });
});
