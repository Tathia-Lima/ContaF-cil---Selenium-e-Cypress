// Arquivo: accessibility.cy.js

describe('Acessibilidade - Login', () => {

  // 01 - Verifica se os labels estão associados corretamente aos inputs
  it('01 - Deve ter labels associados aos campos de formulário', () => {
    cy.visit('/login');
    cy.get('label[for="email"]').should('contain', 'Email');
    cy.get('#email').should('be.visible').and('have.attr', 'id', 'email');

    cy.get('label[for="senha"]').should('contain', 'Senha');
    cy.get('#senha').should('be.visible').and('have.attr', 'id', 'senha');
  });

  // 02 - Verifica a navegação por teclado via TAB
  it('02 - Deve permitir navegação por teclado', () => {
    cy.visit('/login');

    cy.get('#email').focus();
    cy.focused().should('have.id', 'email');

    cy.focused().tab();
    cy.focused().should('have.id', 'senha');

    cy.focused().tab();
    cy.focused().should('have.id', 'togglePassword');

    cy.focused().tab();
    cy.focused().should('contain.text', 'Entrar');
  });

  // 03 - Verifica contraste de cores básico para leitura confortável
  it('03 - Deve ter contraste adequado para leitura', () => {
    cy.visit('/login');
    cy.get('h2').should('have.css', 'color').and((color) => {
      expect(color).to.be.oneOf(['rgb(0, 0, 0)', 'rgb(255, 215, 0)', 'rgb(255, 235, 59)']);
    });
    cy.get('body').should('have.css', 'background-color').and((bg) => {
      expect(bg).to.be.oneOf(['rgb(255, 255, 255)', 'rgb(26, 26, 26)']);
    });
    cy.get('button').contains('Entrar').should('have.css', 'color');
    cy.get('button').contains('Entrar').should('have.css', 'background-color');
  });

  // 04 - Verifica se botão de mostrar/ocultar senha tem aria-label para acessibilidade
  it('04 - Botão toggle senha deve ter aria-label para screen readers', () => {
    cy.visit('/login');
    cy.get('#togglePassword')
      .should('have.attr', 'aria-label')
      .and('match', /mostrar|ocultar senha/i);
  });

  // 05 - Verifica se o formulário possui role="form" para melhor semântica
  it('05 - Formulário deve ter role="form"', () => {
    cy.visit('/login');
    cy.get('form').should('have.attr', 'role', 'form');
  });

  // 06 - Verifica que campos obrigatórios possuem atributo required
  it('06 - Campos obrigatórios devem ter atributo required', () => {
    cy.visit('/login');
    cy.get('#email').should('have.attr', 'required');
    cy.get('#senha').should('have.attr', 'required');
  });

  // 07 - Verifica se mensagens de erro estão associadas via aria-describedby
  it('07 - Mensagens de erro devem ser associadas via aria-describedby', () => {
    cy.visit('/login');
    cy.get('#email').should('have.attr', 'aria-describedby');
    cy.get('#senha').should('have.attr', 'aria-describedby');
  });

  // 08 - Verifica se os ícones têm textos alternativos ou aria-hidden
  it('08 - Ícones devem ter texto alternativo ou aria-hidden para acessibilidade', () => {
    cy.visit('/login');
    cy.get('button#togglePassword').then(($btn) => {
    const hasAriaLabel = $btn.attr('aria-label') !== undefined;
    const hasAriaHidden = $btn.attr('aria-hidden') !== undefined;

    expect(hasAriaLabel || hasAriaHidden).to.be.true;
    });
  });

  // 09 - Verifica se a página possui título (title) e cabeçalho (h2) claros
  it('09 - Deve possuir título da página e cabeçalho claros', () => {
    cy.visit('/login');
    cy.title().should('contain', 'ContaFácil - Login');
    cy.get('h2').should('contain.text', 'Login');
  });

  // 10 - Verifica se mensagens de erro são visíveis e compreensíveis 
  // o Cypress não consegue capturar mensagens de validação nativa diretamente, 
  // porque elas não são elementos reais no DOM. As mesmas soluções se aplicam:
  //Capturar validationMessage via JavaScript, com limitação de idioma;

  it('10 - Deve exibir mensagem de campo obrigatório ao tentar logar sem preencher o email', () => {
    cy.visit('/login');
    // Tenta clicar em "Entrar" sem preencher nada
    cy.get('button').contains('Entrar').click();
    // Acessa o input de email e valida a mensagem nativa
    cy.get('input[name="email"]') // ou outro seletor específico
      .then(($input) => {
        // Verifica a mensagem nativa do navegador
        const validationMessage = $input[0].validationMessage;
        expect(validationMessage).to.eq('Preencha este campo.');
      });
  });

  //Verificar foco visível nos elementos interativos
  // Garantir que o usuário visualiza onde está o foco durante a navegação por
  it('11 - Elementos interativos devem exibir foco visível', () => {
    cy.visit('/login');
    cy.get('#email').focus().should('have.css', 'outline-style').and('not.eq', 'none');
    cy.get('#senha').focus().should('have.css', 'outline-style').and('not.eq', 'none');
    cy.get('#togglePassword').focus().should('have.css', 'outline-style').and('not.eq', 'none');
    cy.get('button[type="submit"]').focus().should('have.css', 'outline-style').and('not.eq', 'none');
  });

 // 12 - Deve ativar o botão mostrar/ocultar senha com a tecla Enter
  it('12 - Deve ativar o botão mostrar/ocultar senha via teclado (Enter)', () => {
    cy.visit('/login');
    cy.get('#togglePassword').focus().type('{enter}');
    cy.get('#senha').should('have.attr', 'type').and('match', /(text|password)/);
  });

  // 13 - Deve ativar o botão mostrar/ocultar senha com a tecla Espaço
  it('13 - Deve ativar o botão mostrar/ocultar senha via teclado (Espaço)', () => {
    cy.visit('/login');
    cy.get('#togglePassword').focus().type(' ');
    cy.get('#senha').should('have.attr', 'type').and('match', /(text|password)/);
  });

  // 14 - Deve ativar o botão Entrar com a tecla Enter
  it('14 - Deve ativar o botão Entrar via teclado (Enter)', () => {
    cy.visit('/login');
    cy.get('#email').type('LoginPage@LoginPage.com');
    cy.get('#senha').type('login_10');
    cy.get('button[type="submit"]').focus().type('{enter}');
    cy.url().should('not.include', '/login');
  });

  // 15 - Deve ativar o botão Cadastrar novo usuário com a tecla Enter
  it('15 - Deve ativar o link Novo usuário via teclado (Enter) e validar título Cadastro de Usuário', () => {
    cy.visit('/login');
    // Foca no link e valida que ele está focável
    cy.contains('Novo usuário').focus().should('have.focus');
    // Clica para garantir navegação
    cy.contains('Novo usuário').click();
    // Valida URL e título da página de cadastro
    cy.url().should('include', '/cadastro');
    cy.get('h1').should('contain.text', 'Cadastro de Usuário');
  });

  it('16 - deve alternar para o campo de senha ao pressionar Tab', () => {
    cy.visit('/login');
    cy.get('input[placeholder="Email"]').focus().tab();
    cy.get('input[placeholder="Senha"]').should('have.focus');
  });

  it('17 - deve mostrar/ocultar a senha ao clicar no ícone de olho', () => {
    cy.visit('/login');
    cy.get('input[placeholder="Senha"]').type('senha123');
    cy.get('input[placeholder="Senha"]').should('have.attr', 'type', 'password');
    // Clica no botão de mostrar senha (ícone de olho)
    cy.get('#togglePassword').click();;
    cy.get('input[placeholder="Senha"]').should('have.attr', 'type', 'text');
    // Clica novamente para ocultar
    cy.get('#togglePassword').click();;
    cy.get('input[placeholder="Senha"]').should('have.attr', 'type', 'password');
  });
});  

