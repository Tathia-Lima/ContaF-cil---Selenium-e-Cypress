/// <reference types="cypress" />

describe('Acessibilidade - Tela de Cadastro de Usuário', () => {
  beforeEach(() => {
    cy.visit('/cadastro'); // Ajuste a rota conforme necessário
    cy.injectAxe(); // Injeta a biblioteca de acessibilidade axe-core
  });

  it('85 - Deve passar nos testes básicos de acessibilidade do Axe', () => {
    cy.checkA11y(null, null, (violations) => {
      if (violations.length) {
        console.log(`${violations.length} violações de acessibilidade encontradas:`);

        violations.forEach(({ id, impact, description, nodes }) => {
          console.log(`ID: ${id}`);
          console.log(`Impacto: ${impact}`);
          console.log(`Descrição: ${description}`);
          console.log(`Número de elementos afetados: ${nodes.length}`);

          nodes.forEach(({ html, target }) => {
            console.log(`Elemento afetado: ${html}`);
            console.log(`Caminho do alvo: ${target.join(' > ')}`);
          });

          console.log('---');
        });
      }
      // Faz a asserção dentro do callback, sem usar then()
      expect(violations.length, 'Sem violações de acessibilidade básicas').to.equal(0);
    });
  });  

  //83 - Valida a navegação usando apenas o teclado (Tab).
  it('86 - Deve ser possível navegar pelo formulário usando apenas o teclado', () => {
    cy.visit('/cadastro');
    // Foco inicial no input nome
    cy.get('#nome').focus().should('have.attr', 'id', 'nome');
    // Tab para email
    cy.focused().tab();
    cy.focused().should('have.attr', 'id', 'email');
    // Tab para senha
    cy.focused().tab();
    cy.focused().should('have.attr', 'id', 'senha');
    // Tab para o botão togglePassword (tipo button)
    cy.focused().tab();
    cy.focused().should('have.attr', 'id', 'togglePassword');
    cy.focused().should('have.attr', 'type', 'button');
    // Tab para o botão submit
    cy.focused().tab();
    cy.focused().should('have.attr', 'type', 'submit');
  });

   it('87 - Todos os campos devem possuir rótulos (label) corretamente associados', () => {
    cy.get('label[for="nome"]').should('exist');
    cy.get('input#nome').should('exist');

    cy.get('label[for="email"]').should('exist');
    cy.get('input#email').should('exist');

    cy.get('label[for="senha"]').should('exist');
    cy.get('input#senha').should('exist');
  });

  it('88 - Botão de mostrar senha deve ter rótulo acessível', () => {
    cy.get('#togglePassword')
      .should('have.attr', 'aria-label')
      .and('match', /mostrar|ocultar/i); // Deve conter a palavra mostrar ou ocultar
  });

   it('89 - Mensagens de critérios da senha devem ser visíveis e informativas', () => {
    cy.get('#senha').type('A');
    cy.get('#length').should('be.visible');
    cy.get('#letter').should('contain.text', 'letra');
    cy.get('#number').should('contain.text', 'número');
    cy.get('#special').should('contain.text', 'caractere especial');
  });

  it('90 - Mensagem de feedback deve ser lida por leitores de tela (role="alert")', () => {
    cy.get('button[type="submit"]').click();
    cy.contains(/todos os campos são obrigatórios/i).should('exist');
  });

  it('91 - Link "Já tem conta? Faça login" deve ser acessível', () => {
    cy.contains('Já tem conta? Faça login')
      .should('have.attr', 'href')
      .and('include', 'login');
  });

  it('92 - Deve manter contraste suficiente entre texto e fundo', () => {
    cy.get('button[type="submit"]')
      .should('have.css', 'color')
      .and((color) => {
        expect(color).to.not.equal('rgba(0, 0, 0, 0)'); // Não deve ser transparente
      });
  });

  it('93 - Deve haver apenas um elemento <main> na página', () => {
    cy.get('main').should('have.length', 1);
  });
  
    // 91 - Deve haver indicação visual clara do foco nos elementos focáveis
  it('94 - Deve haver indicação visual clara do foco nos elementos focáveis', () => {
    cy.get('input, button, a').each(($el) => {
      cy.wrap($el)
        .focus()
        .should('have.css', 'outline-color')
        .and('not.equal', 'rgba(0, 0, 0, 0)') // ou 'transparent'
        .and('match', /rgb|#|hsl/); // assegura que tem cor
    });
  });

  // 92 - Botão mostrar/ocultar senha deve atualizar aria-label conforme estado
  it('95 - Botão mostrar/ocultar senha atualiza aria-label conforme estado', () => {
    cy.get('#togglePassword')
    .as('toggle')
    .should('have.attr', 'aria-label', 'Mostrar senha');
    cy.get('#togglePassword').click();
    cy.get('@toggle').should('have.attr', 'aria-label', 'Ocultar senha');
  });

  // 93 - Todos os links devem ter texto descritivo e visível
  it('96 - Todos os links possuem texto descritivo e visível', () => {
    cy.get('a[href]').each(($link) => {
      cy.wrap($link)
        .invoke('text')
        .should('not.be.empty')
        .and('not.match', /^\s*$/);
      cy.wrap($link).should('be.visible');
    });
  });
});
