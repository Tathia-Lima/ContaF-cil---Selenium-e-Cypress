/// <reference types="cypress" />
import LoginPage from '../../support/page_objects/loginPage';
import 'cypress-axe';
import 'cypress-plugin-tab';

describe('Acessibilidade e Navegação - Página Detalhes da Conta', () => {
  beforeEach(() => {
    cy.login('conta_detalhes@conta.com', 'login_10');
    cy.visit('/home');

    // Acessa a Conta 1 pela tabela, garantindo caminho funcional
    cy.contains('td', 'Conta 1')
      .parent('tr')
      .find('a.btn-primary')
      .invoke('removeAttr', 'target')
      .click();

    cy.url().should('include', '/contas/detalhes/');
    cy.injectAxe();
  });

  it('277 - Deve ter elementos semânticos essenciais (main, nav, table, thead, tbody)', () => {
    cy.get('main').should('exist');
    cy.get('nav[aria-label="Navegação de Movimentações"]').should('exist');
    cy.get('table').should('exist');
    cy.get('thead').should('exist');
    cy.get('tbody').should('exist');
  });

  it('278 - Labels devem estar visíveis e coerentes com os dados exibidos', () => {
    cy.get('.conta-info-grid label').each(($label) => {
      cy.wrap($label).invoke('text').should('not.be.empty');
      cy.wrap($label).next('div').should('exist').and('not.be.empty');
    });
  });

  it('279 - Botões e links devem ter texto legível e aria-label quando aplicável', () => {
    cy.get('a.btn, button').each(($el) => {
      cy.wrap($el).then($btn => {
        const text = $btn.text().trim();
        const ariaLabel = $btn.attr('aria-label');
        expect(text.length > 0 || (ariaLabel && ariaLabel.length > 0)).to.be.true;
      });
    });
  });

  it('280 - Deve haver um título principal visível e acessível', () => {
    cy.get('h2').contains('Detalhes da Conta').should('be.visible');
  });

  it('281 - Botão "Voltar para Contas" deve ser acessível via teclado', () => {
    cy.get('body').tab();
    function tabUntilFound(retries = 30) {
      if (retries <= 0) throw new Error('Botão "Voltar para Contas" não foi encontrado via tabulação');
      cy.focused().then($el => {
        if ($el.text().trim().includes('Voltar para Contas')) {
          cy.wrap($el)
            .should('have.attr', 'href')
            .and('include', '/contas');
        } else {
          cy.tab();
          tabUntilFound(retries - 1);
        }
      });
    }
    tabUntilFound();
  });

  it('282 - Foco no botão "Editar Conta" via tabulação', () => {
    cy.get('body').tab().tab();
    function tabUntilFound(retries = 30) {
      if (retries <= 0) throw new Error('Botão "Editar Conta" não foi encontrado via tabulação');
      cy.focused().then($el => {
        if ($el.text().trim().includes('Editar Conta')) {
          cy.wrap($el).should('have.attr', 'href').and('include', '/editar');
        } else {
          cy.tab();
          tabUntilFound(retries - 1);
        }
      });
    }
    tabUntilFound();
  });

  it('283 - Foco no botão "Nova Movimentação" via tabulação', () => {
    cy.get('body').tab().tab().tab();
    function tabUntilFound(retries = 30) {
      if (retries <= 0) throw new Error('Botão "Nova Movimentação" não foi encontrado via tabulação');
      cy.focused().then($el => {
        if ($el.text().trim().includes('Nova Movimentação')) {
          cy.wrap($el).should('have.attr', 'href').and('include', '/movimentacao');
        } else {
          cy.tab();
          tabUntilFound(retries - 1);
        }
      });
    }
    tabUntilFound();
  });

  it('284 - Deve alcançar os botões "Anterior" e "Próximo" via tabulação', () => {
    const verificarFocoEm = (textoEsperado) => {
      let tentativas = 0;
      function tabAteEncontrar() {
        if (tentativas++ > 40) throw new Error(`Botão "${textoEsperado}" não encontrado via tabulação`);
        cy.focused().then($el => {
          const texto = $el.text().trim().replace(/\s+/g, ' ');
          if (texto.includes(textoEsperado)) {
            cy.wrap($el).should('have.attr', 'href');
          } else {
            cy.tab();
            tabAteEncontrar();
          }
        });
      }
      tabAteEncontrar();
    };
    cy.tab();
    verificarFocoEm('Próximo');
  });

  it('285 - Deve alcançar o botão "Anterior" via tabulação após clicar na página 2', () => {
    const textoBotaoEsperado = 'Anterior';
    let tentativas = 0;
    const maxTentativas = 40;

    cy.visit('/contas/detalhes/196?page=2');
    cy.url().should('include', '?page=2');

    cy.get('body').focus();

    function tabAteEncontrar() {
      if (tentativas++ >= maxTentativas) {
        throw new Error(`Botão "${textoBotaoEsperado}" não encontrado após ${maxTentativas} tabulações.`);
      }

      cy.tab();

      cy.focused().then($el => {
        if (!$el || !$el.length) {
          cy.log('Nenhum elemento focado válido, tentando focar body novamente');
          cy.get('body').focus();
          tabAteEncontrar();
          return;
        }

        const textoFocado = $el.text().trim();

        if (textoFocado.includes(textoBotaoEsperado)) {
          cy.wrap($el).should(($button) => {
            expect($button).to.be.visible;
            expect($button).to.not.have.attr('disabled');
            expect($button).to.not.have.class('disabled-link');
            expect($button).to.have.attr('href');
          });
        } else {
          tabAteEncontrar();
        }
      });
    }

    tabAteEncontrar();
  });

  it('286 - Foco no botão "1" da paginação via tabulação', () => {
    cy.get('body').tab().tab().tab();
    function tabUntilFound(retries = 30) {
      if (retries <= 0) throw new Error('Botão "1" da paginação não foi encontrado via tabulação');
      cy.focused().then($el => {
        if ($el.text().trim() === '1') {
          cy.wrap($el).should('have.attr', 'href');
        } else {
          cy.tab();
          tabUntilFound(retries - 1);
        }
      });
    }
    tabUntilFound();
  });

  it('287 - Botões "Editar" nas linhas da tabela são acessíveis via tabulação', () => {
    cy.get('body').tab().tab().tab();
    function tabUntilFound(retries = 30) {
      if (retries <= 0) throw new Error('Botões "Editar" não foram encontrados via tabulação');
      cy.focused().then($el => {
        if ($el.text().trim().includes('Editar')) {
          cy.wrap($el).should('have.attr', 'href').and('include', '/movimentacao/editar/');
        } else {
          cy.tab();
          tabUntilFound(retries - 1);
        }
      });
    }
    tabUntilFound();
  });

  it('288 - Botões com foco exibem outline visível', () => {
    cy.get('a.btn, button').each(($btn) => {
      cy.wrap($btn).focus().should('have.css', 'outline-style').and('not.equal', 'none');
    });
  });

  it('289 - A tabela de movimentações tem cabeçalhos com scope="col"', () => {
    cy.get('table thead th').each(($th) => {
      cy.wrap($th).should('have.attr', 'scope', 'col');
    });
  });

  it('290 - A paginação possui aria-label "Navegação de Movimentações"', () => {
    cy.get('nav[aria-label="Navegação de Movimentações"]').should('exist');
  });

  it('291 - Botões de paginação desabilitados possuem aria-disabled="true"', () => {
    cy.get('nav[aria-label="Navegação de Movimentações"] li.page-item.disabled').each(($li) => {
      cy.wrap($li).find('a.page-link').should('have.attr', 'aria-disabled', 'true');
    });
  });

  it('292 - Botão ativo na paginação possui classe "btn-primary"', () => {
    cy.get('nav[aria-label="Navegação de Movimentações"] li.page-item.active a.page-link')
      .should('have.class', 'btn-primary');
  });

  it('293 - Valores positivos têm classe "positive-value" e negativos "negative-value"', () => {
    const regexValor = /^R\$ ?\d{1,3}(\.\d{3})*,\d{2}$/;

    // Positivos (sem traço, com classe positiva)
    cy.get('.positive-value').each(($el) => {
      cy.wrap($el).invoke('text').then((text) => {
        const valorLimpo = text.replace(/\s+/g, ' ').trim();
        expect(valorLimpo).to.match(regexValor);
      });
    });

    // Negativos (sem traço, mas com classe 'negative-value')
    cy.get('.negative-value').each(($el) => {
      cy.wrap($el).invoke('text').then((text) => {
        const valorLimpo = text.replace(/\s+/g, ' ').trim();
        expect(valorLimpo).to.match(regexValor);
      });
    });
  });


  it('294 - Saldo atual está visível com destaque', () => {
    cy.get('.saldo-info').should('be.visible');
    cy.get('.saldo-info > div').invoke('text').should('match', /R\$ -?\d{1,3}(\.\d{3})*,\d{2}/);
  });

  it('295 - Paginação altera URL e mantém a página atual ativa', () => {
    cy.get('nav[aria-label="Navegação de Movimentações"]')
      .find('a.page-link')
      .contains(/^2$/)
      .click();

    cy.url().should('include', 'page=2');
    cy.get('nav[aria-label="Navegação de Movimentações"] li.page-item.active a.page-link').should('contain', '2');
  });


  it('296 - Tabela possui estrutura acessível com linhas e colunas coerentes', () => {
    cy.get('table tbody tr').each(($tr) => {
      cy.wrap($tr).find('td').should('have.length', 6);
    });
  });

  it('297 - Tabela de movimentações possui textos com contraste visível', () => {
    cy.get('table tbody tr td').each(($td) => {
      cy.wrap($td).should('be.visible');
    });
  });

  it('298 - Links na página devem possuir href válido e navegável', () => {
    cy.get('a[href]').each(($a) => {
      const href = $a.attr('href');
      expect(href).to.match(/^\/|https?:\/\//);
    });
  });
});
