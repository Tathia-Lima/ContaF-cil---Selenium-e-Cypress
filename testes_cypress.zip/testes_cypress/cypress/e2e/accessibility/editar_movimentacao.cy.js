// cypress/e2e/movimentacao_editar_accessibility.cy.js

import LoginPage from '../../support/page_objects/loginPage';

describe('Testes de Acessibilidade - Página Editar Movimentação', () => {
  const USER_EMAIL = 'editarMovimentacao@movimentacao.com'; // Usando o email consistente com outros testes
  const USER_PASSWORD = 'login_10';

  let movementId;

  // Função auxiliar para acessar a página de detalhes de uma conta
  // Reutilizada do seu arquivo de testes funcionais, se existir em '../support/page_objects/common_helpers.js'
  // ou diretamente aqui para auto-contenção.
  const acessarContaPorNome = (nomeConta) => {
    cy.visit('/home');
    cy.contains('td', nomeConta)
      .parent('tr')
      .find('a.btn-primary') // Botão para ir para detalhes da conta
      .invoke('removeAttr', 'target') // Remove target=_blank se presente
      .click();
    cy.url().should('include', '/contas/detalhes/');
    cy.contains('Detalhes da Conta').should('be.visible');
  };

  beforeEach(() => {
    // Login antes de cada teste para garantir que o usuário esteja autenticado
    cy.session(USER_EMAIL, () => {
      LoginPage.login(USER_EMAIL, USER_PASSWORD);
    });

    // 1. Navegar para a página de detalhes de uma conta que se sabe ter movimentações
    // Usaremos 'Conta 3' como exemplo, ajuste se necessário para seu ambiente de teste.
    acessarContaPorNome('Conta 3');

    // 2. Na página de detalhes da conta, obter o ID da primeira movimentação para edição
    cy.get('table tbody tr').first().find('a.btn-warning').invoke('attr', 'href').then((href) => {
      // Extrai o ID da URL de edição (ex: /movimentacao/editar/123 -> 123)
      const parts = href.split('/');
      movementId = parts[parts.length - 1];

      // 3. Vai para a página de edição da movimentação
      cy.visit(`/movimentacao/editar/${movementId}`);

      // 4. Injeta o axe-core para rodar a análise de acessibilidade em cada teste
      cy.injectAxe();
    });
  });

  // TESTES DE ACESSIBILIDADE

  // 323 - Deve ter zero violações de acessibilidade (WCAG 2.1 AA) na página de edição (via Axe-core)
  // Este teste é abrangente e substitui 323, 328, 329 e 335 dos rascunhos anteriores.
  // Ele foca em problemas críticos e sérios, incluindo contraste, semântica e roles.
  it('323 - Deve ter zero violações de acessibilidade (WCAG 2.1 AA) na página de edição', () => {
    cy.checkA11y(null, {
      runOnly: {
        type: 'tag',
        // Inclui tags para WCAG 2.1 Nível AA e foca em impactos críticos e sérios.
        // O axe-core já verifica contraste e outras regras de WCAG AA.
        values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']
      },
      // Exclui warnings ou notices que podem ser informativos mas não bloqueantes.
      includedImpacts: ['critical', 'serious']
    }, (violations) => {
      if (violations.length) {
        cy.log('Problemas de acessibilidade encontrados:');
        violations.forEach(({ id, impact, description, nodes }) => {
          cy.log(`Impacto: ${impact} - Regra: ${id}`);
          cy.log(`Descrição: ${description}`);
          nodes.forEach(({ html, target }) => {
            cy.log(`Elemento: ${html}`);
            cy.log(`Seletor: ${target.join(', ')}`);
          });
        });
      }
      expect(violations.length).to.equal(0, 'Não deve haver violações de acessibilidade críticas ou sérias.');
    });
  });

  // 324 - Deve garantir que todos os elementos interativos são focáveis e navegáveis por teclado, com foco visível
  // Consolida 325 e 330 dos rascunhos anteriores.
it('324 - Deve garantir que todos os elementos interativos são focáveis e navegáveis por teclado, com foco visível', () => {
  const totalTabs = 30; // Ajuste conforme necessário

  // Começa a tabulação no body
  cy.get('body').tab({ force: true });

  for (let i = 0; i < totalTabs; i++) {
    cy.focused().should('be.visible');

    // Verifica que o foco tem algum estilo visível: outline, box-shadow ou border
    cy.focused().then($el => {
      const outline = $el.css('outline-style');
      const boxShadow = $el.css('box-shadow');
      const borderColor = $el.css('border-color');

      const hasVisibleFocus =
        (outline && outline !== 'none') ||
        (boxShadow && boxShadow !== 'none' && !boxShadow.includes('rgba(0, 0, 0, 0)')) ||
        (borderColor && borderColor !== 'rgba(0, 0, 0, 0)' && borderColor !== 'transparent');

      expect(
        hasVisibleFocus,
        `Elemento focado (${i + 1}º tab) deveria ter estilo visual de foco visível`
      ).to.be.true;
    });

    cy.focused().tab();
  }

  // Verifica também o SHIFT+TAB reverso
  cy.focused().tab({ shift: true });
  cy.focused().should('be.visible');
});


  // 325 - Deve garantir que todos os campos de formulário e radio buttons possuem rótulos (labels) associados corretamente e atributos ARIA semânticos
  // Consolida 324 (anterior), 331 e 337 dos rascunhos anteriores.
  it('325 - Deve garantir que todos os campos de formulário e radio buttons possuem rótulos (labels) associados corretamente e atributos ARIA semânticos', () => {
    cy.get('form').within(() => {
      // Verifica inputs e selects (exceto hidden)
      cy.get('input:not([type="hidden"]), select, textarea').each(($el) => {
        const id = $el.attr('id');
        const name = $el.attr('name');
        if (id) {
          // Verifica se há um label diretamente associado via 'for'
          cy.get(`label[for="${id}"]`).should('exist').and('be.visible');
        } else {
          // Se não houver ID, verifica se há aria-label ou aria-labelledby
          cy.wrap($el).should(($inputWithoutId) => {
            const hasAriaLabel = $inputWithoutId.attr('aria-label') || $inputWithoutId.attr('aria-labelledby');
            expect(hasAriaLabel, `Input "${name}" deve ter ID ou aria-label/aria-labelledby`).to.exist;
          });
        }
      });

      // Verificação específica para o grupo de radio buttons
      cy.get('fieldset').as('situacaoFieldset'); // Aliases para facilitar
      cy.get('@situacaoFieldset').should('exist').and('be.visible');
      cy.get('@situacaoFieldset').find('legend').should('contain.text', 'Situação').and('be.visible');

      // Verifica cada radio button individualmente
      cy.get('input[name="situacao"]').each(($radio) => {
        const id = $radio.attr('id');
        cy.get(`label[for="${id}"]`).should('exist').and('be.visible'); // Cada radio deve ter um label
        cy.wrap($radio).should('have.attr', 'type', 'radio');
      });

      // Para o fieldset que agrupa os radio buttons, embora não tenha um role='radiogroup' explícito,
      // o fieldset/legend já fornecem a semântica de agrupamento necessária.
      // Se houvesse um div externo, role="radiogroup" seria mais apropriado lá.
    });
    cy.log('Verificação de rótulos e atributos ARIA concluída.');
  });

  // 326 - Deve garantir que o botão 'Salvar Alterações' possui texto descritivo e tipo (role) apropriado
  it('326 - Deve garantir que o botão "Salvar Alterações" possui texto descritivo e tipo (role) apropriado', () => {
    cy.get('button[type="submit"]')
      .should('exist')
      .and('contain.text', 'Salvar Alterações') // Verifica o texto visível
      .and('have.attr', 'type', 'submit') // Garante que é um botão de submissão
      .and('be.visible');
    cy.log('Botão "Salvar Alterações" verificado.');
  });

  it('327 - Deve garantir que campos com formato específico (valor, data) possuem informações acessíveis sobre o formato', () => {
    // Verifica o campo de Valor
    cy.get('#valor').then(($input) => {
      const idAttr = $input.attr('id');
      const ariaDescId = $input.attr('aria-describedby');
      const ariaLabel = $input.attr('aria-label');

      if (ariaDescId) {
        cy.get(`#${ariaDescId}`)
          .should('exist')
          .and('be.visible')
          .and('contain.text', 'mínimo: 0.01');
      } else if (ariaLabel) {
        expect(ariaLabel).to.include('mínimo: 0.01');
      } else {
        // Verifica se a informação está dentro do próprio <label>
        cy.get(`label[for="${idAttr}"]`)
          .find('.text-muted')
          .should('exist')
          .and('contain.text', '(mínimo: 0.01)');
      }

      cy.log(`Campo 'valor' com formato acessível: ${idAttr}`);
    });

    // Verifica os campos de data
    ['data_movimentacao', 'data_pagamento'].forEach((id) => {
      cy.get(`#${id}`).then(($input) => {
        const ariaLabel = $input.attr('aria-label');
        const placeholder = $input.attr('placeholder');

        // Busca o texto do label relacionado
        cy.get(`label[for="${id}"]`).invoke('text').then((labelText) => {
          const acessibilidadeTexto = ariaLabel || placeholder || labelText;

          expect(acessibilidadeTexto).to.match(
            /(YYYY-MM-DD|ano-mês-dia|DD\/MM\/YYYY|data|formato)/i
          );
        });

        cy.log(`Campo '${id}' com formato acessível.`);
      });
    });

    cy.log('Verificação de informações de formato acessíveis concluída.');
  });

  // 328 - Deve garantir que a ordem de tabulação dos elementos do formulário segue uma sequência lógica no DOM
it('328 - Deve garantir que a ordem de tabulação dos elementos do formulário segue uma sequência lógica no DOM', () => {
  // Foca manualmente o primeiro campo
  cy.get('select[name="tipo"]').focus();

  const tabOrder = [
    { name: 'tipo' },                        // select
    { name: 'data_movimentacao' },           // input[type="date"]
    { name: 'data_pagamento' },              // input[type="date"]
    { name: 'descricao' },                   // input
    { name: 'interessado' },                 // input
    { name: 'valor' },                       // input
    { name: 'conta_id' },                    // select
    { name: 'situacao', id: 'situacao-0' },  // radio 1
    { name: 'situacao', id: 'situacao-1' },  // radio 2
    { tag: 'button', type: 'submit' },       // Salvar Alterações
    { tag: 'a', class: 'btn-secondary' }     // Cancelar
  ];

  tabOrder.forEach(({ name, id, tag, type, class: className }, index) => {
    cy.focused().should('exist').then($el => {
      if (name) {
        expect($el.attr('name'), `Tab ${index + 1} (name)`).to.eq(name);
      }
      if (id) {
        expect($el.attr('id'), `Tab ${index + 1} (id)`).to.eq(id);
      }
      if (tag) {
        expect($el.prop('tagName').toLowerCase(), `Tab ${index + 1} (tag)`).to.eq(tag);
      }
      if (type) {
        expect($el.attr('type'), `Tab ${index + 1} (type)`).to.eq(type);
      }
      if (className) {
        expect($el).to.have.class(className, `Tab ${index + 1} (class)`);
      }
    });

    cy.focused().tab();
  });
});


  // 329 - Deve manter legibilidade e usabilidade da página com zoom de 200% (verificação visual)
  // Mantém 336 do rascunho anterior, com ênfase na verificação manual.
  it('329 - Deve manter legibilidade e usabilidade da página com zoom de 200% (verificação visual)', () => {
    // Define o viewport para um tamanho comum de desktop
    cy.viewport(1280, 720);

    // Ajusta o zoom da página via CSS (simulação de zoom do navegador)
    cy.get('body').then($body => {
      $body.css('zoom', '200%');
    });

    // Verificações automatizadas básicas:
    // Garante que o formulário principal ainda é visível
    cy.get('form').should('be.visible');
    // Garante que o botão de salvar ainda é visível e clicável
    cy.get('button[type="submit"]').should('be.visible').and('be.enabled');
    // Garante que não há scroll horizontal excessivo (indicativo de layout quebrado)
    cy.document().then(($document) => {
      expect($document.body.scrollWidth).to.be.lte($document.body.clientWidth + 50); // Permite uma pequena margem
    });

    cy.log('**VERIFICAÇÃO MANUAL NECESSÁRIA:**');
    cy.log('Por favor, verifique visualmente a página de edição com o zoom de 200%.');
    cy.log('Observe se:');
    cy.log('1. O conteúdo ainda é legível e não está sobreposto.');
    cy.log('2. Todos os elementos interativos são acessíveis e clicáveis.');
    cy.log('3. Não há barras de rolagem horizontais desnecessárias (especialmente em telas menores).');
    cy.log('4. O layout se adapta de forma razoável, sem cortes de conteúdo.');
  });
});
