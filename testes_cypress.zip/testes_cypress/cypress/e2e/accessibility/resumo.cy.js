// cypress/e2e/resumo_usabilidade.cy.js
import MovimentacaoPage from '../../support/page_objects/MovimentacaoPage'; // Certifique-se de que este é o Page Object Cypress
import LoginPage from '../../support/page_objects/loginPage'; // Certifique-se de que este é o Page Object Cypress
import 'cypress-axe';
import 'cypress-real-events/support'; // para cy.realPress

describe('Usabilidade e Acessibilidade - Página Resumo', () => {
    const USER_EMAIL = 'resumo.movimento@resumo.com';
    const USER_PASSWORD = 'login_10';

    beforeEach(() => {
        cy.session(USER_EMAIL, () => {
            LoginPage.login(USER_EMAIL, USER_PASSWORD); // Chama o método de login do Page Object
        });
        cy.visit('/resumo');
        cy.injectAxe(); // Injeta a ferramenta Axe para auditoria de acessibilidade
        cy.get('table tbody tr').should('exist'); // Espera que a tabela esteja carregada
        MovimentacaoPage.setupClockBasedOnServerDate(); // Re-adicionado: Sincroniza o clock do Cypress com o servidor
    });

    afterEach(() => {
        MovimentacaoPage.restoreClock(); // Re-adicionado: Restaura o clock do Cypress
    });

    // Exemplo de teste geral de acessibilidade via axe para toda a página Resumo
    it('239. Filtros - Tabela não atualiza sem clicar em Buscar', () => {
        cy.get('table tbody tr').should('have.length.greaterThan', 0);

        cy.get('#mes').select('1'); // Janeiro
        cy.url().should('not.include', 'mes=1'); // Verifica que a URL não mudou automaticamente

        const currentMonth = new Date().getMonth() + 1;
        if (currentMonth !== 1) {
            cy.get('#mes').should('have.value', '1');
            cy.url().should('not.include', `mes=1`);
        } else {
            cy.log('Mês atual é Janeiro, pulando verificação de URL para filtro de mês.');
        }
    });

    it('240. Cada linha deve ter botão "Excluir" visível e dentro de um form', () => {
        cy.get('#mes').select('1');
        cy.get('#ano').select('2025');
        cy.get('#tipo').select('todos');
        cy.get('.btn-primary').contains('Buscar').click();

        cy.get('table tbody tr').each(($row) => {
            if (!$row.text().includes('Nenhuma movimentação encontrada')) {
                cy.wrap($row).find('form').should('exist');
                cy.wrap($row).find('form button.btn-danger.btn-sm')
                    .should('be.visible')
                    .and('contain.text', 'Excluir');
            }
        });
    });

    it('241. Não deve exibir mensagens de erro inesperadas', () => {
        cy.get('.flash.danger').should('not.exist');
        cy.get('.alert-danger').should('not.exist');
        cy.contains(/Erro:/i).should('not.exist');
    });

    // Para testes de cor, usar assertiva aproximada
    const assertCorAproximada = (el, rgbEsperado) => {
        cy.wrap(el)
            .should('have.text')
            .then(() => {
                cy.wrap(el)
                    .should('have.css', 'color')
                    .then((color) => {
                        expect(color).to.match(new RegExp(rgbEsperado.replace(/\s/g, '')));
                    });
            });
    };

    it('242. Valores de Receita são verdes e formatados corretamente', () => {
        cy.get('#mes').select('1');
        cy.get('#ano').select('2025');
        cy.get('#tipo').select('receita');
        cy.get('.btn-primary').contains('Buscar').click();

        // Pega uma linha com receita (exemplo: 'Venda A')
        cy.contains('table tbody tr td', 'Venda A').parent('tr').within(() => {
            cy.get('td').eq(4).should('contain.text', 'R$') // coluna valor
                .and(($td) => {
                    const color = $td.css('color');
                    expect(color).to.match(/rgb\(0,\s?128,\s?0\)|rgb\(0,\s?255,\s?0\)/); // verde
                });
        });
    });

    it('243. Valores de Despesa são vermelhos e formatados', () => {
        cy.get('#mes').select('1');
        cy.get('#ano').select('2025');
        cy.get('#tipo').select('despesa');
        cy.get('.btn-primary').contains('Buscar').click();

        cy.contains('td', 'Compra D').parent('tr').within(() => {
            cy.get('td').eq(4).should('contain.text', 'R$ 120,00')
                .and(($td) => {
                    const cor = $td.css('color');
                    expect(cor).to.match(/rgb\(255,\s?36,\s?0\)/);; // vermelho
                });
        });
    });

    it('244. Situações "Pago" e "Pendente" capitalizadas', () => {
        cy.get('#mes').select('2');
        cy.get('#ano').select('2025');
        cy.get('#tipo').select('todos');
        cy.get('.btn-primary').contains('Buscar').click();

        cy.contains('td', 'Compra G').parent('tr').within(() => {
            cy.get('td').eq(5).invoke('text').should('match', /^Pendente$/);
        });

        cy.get('#mes').select('1');
        cy.get('#ano').select('2025');
        cy.get('#tipo').select('todos');
        cy.get('.btn-primary').contains('Buscar').click();

        cy.contains('td', 'Venda F').parent('tr').within(() => {
            cy.get('td').eq(5).invoke('text').should('match', /^Pago$/);
        });
    });

    it('245. Mensagem "Nenhuma movimentação encontrada" aparece corretamente', () => {
        cy.get('#mes').select('12');
        cy.get('#ano').select('2020');
        cy.get('#tipo').select('todos');
        cy.get('.btn-primary').contains('Buscar').click();

        cy.get('table tbody tr').should('have.length', 1);
        cy.get('table tbody tr td[colspan="7"]')
            .should('contain.text', 'Nenhuma movimentação encontrada para este período.');
    });

    it('247. Navegação por tabulação e preenchimento do formulário', () => {
        cy.visit('/resumo');
        cy.get('#mes').focus();
        cy.realPress('Tab'); // ano
        cy.focused().should('have.attr', 'id', 'ano').select('2025');
        cy.realPress('Tab'); // tipo
        cy.focused().should('have.attr', 'id', 'tipo').select('receita');
        cy.realPress('Tab'); // botão Buscar
        cy.focused().should('contain.text', 'Buscar').realPress('Enter');
        // Validação de que o filtro foi aplicado e tabela atualizada
        cy.url().should('include', 'ano=2025');
        cy.url().should('include', 'tipo=receita');
        cy.get('table tbody tr').its('length').should('be.greaterThan', 0);
    });

    it('248. Validar busca utilizando o preenchimento padrão do app, mês e ano atual', () => {
        const hoje = new Date();
        const mesAtual = (hoje.getMonth() + 1).toString();
        const anoAtual = hoje.getFullYear().toString();

        cy.visit('/resumo');
        cy.get('#mes').should('have.value', mesAtual);
        cy.get('#ano').should('have.value', anoAtual);
    });

    it('249. Elementos não interativos não recebem foco por tabulação', () => {
        cy.get('#server-date').should('not.be.visible');
        // A ausência dele na tabulação é garantida no teste 246.
    });
});

describe('Exclusão de Movimentação via tab', () => {
    const USER_EMAIL = 'excluir.tab@excluir.com';
    const USER_PASSWORD = 'login_10';

    let dynamicMovDescription;

    before(() => {
        cy.session(USER_EMAIL, () => {
            LoginPage.login(USER_EMAIL, USER_PASSWORD);
            cy.url().should('include', '/home');
        });

        dynamicMovDescription = `Excluir ${Cypress._.uniqueId()}`;

        const movimentacaoParaTeste = {
            descricao: dynamicMovDescription,
            interessado: 'Teste Exclusão Cypress',
            tipo: 'despesa',
            data_movimentacao: '2025-07-03',
            data_pagamento: '2025-07-03',
            valor: '123.45',
            conta: 'Conta 1', // Certifique-se que 'Conta 1' existe ou ajuste para uma conta existente
            situacao: 'pago',
        };

        MovimentacaoPage.visitar();
        MovimentacaoPage.selecionarTipo(movimentacaoParaTeste.tipo);
        MovimentacaoPage.preencherDataMovimentacao(movimentacaoParaTeste.data_movimentacao);
        MovimentacaoPage.preencherDataPagamento(movimentacaoParaTeste.data_pagamento);
        MovimentacaoPage.preencherDescricao(movimentacaoParaTeste.descricao);
        MovimentacaoPage.preencherInteressado(movimentacaoParaTeste.interessado);
        cy.get('input[name="valor"]').clear().type(movimentacaoParaTeste.valor);
        MovimentacaoPage.selecionarConta(movimentacaoParaTeste.conta);
        MovimentacaoPage.selecionarSituacao(movimentacaoParaTeste.situacao);
        MovimentacaoPage.submeter();

        cy.url().should('include', '/resumo');
        MovimentacaoPage.validarMensagem('Despesa incluída com sucesso!'); // Usando o método do PO
        cy.visit('/resumo'); // Re-visita /resumo após criar a movimentação para garantir o estado
    });

    beforeEach(() => {
        cy.session(USER_EMAIL, () => {
            LoginPage.login(USER_EMAIL, USER_PASSWORD);
        });
        cy.visit('/resumo');
    });

    it('250 - Deve validar cancelar exclusão via teclado (tab + enter para cancelar)', () => {
        cy.contains('td', dynamicMovDescription).should('exist');

        // Força o foco para o botão Excluir da movimentação criada
        cy.contains('td', dynamicMovDescription)
            .parent('tr')
            .find('button.btn-danger')
            .focus()
            .should('have.focus');

        // Simula o usuário apertando Enter no botão Excluir para abrir o confirm
        cy.window().then((win) => {
            cy.stub(win, 'confirm').callsFake((msg) => {
                expect(msg).to.include('Tem certeza que deseja excluir esta movimentação?');
                return false; // Simula clicar em Cancelar no confirm
            }).as('confirmStub');
        });

        cy.focused().realPress('Enter');

        // Validar que o confirm foi chamado
        cy.get('@confirmStub').should('have.been.calledOnce');

        // A movimentação deve continuar visível (não excluída)
        cy.contains('td', dynamicMovDescription).should('exist');
    });

    it('251 - Deve validar confirmar exclusão via teclado (tab + enter para confirmar)', () => {
        cy.contains('td', dynamicMovDescription).should('exist');

        // Foca o botão Excluir e confirma a exclusão com Enter
        cy.contains('td', dynamicMovDescription)
            .parent('tr')
            .find('button.btn-danger')
            .focus()
            .should('have.focus');

        cy.window().then((win) => {
            cy.stub(win, 'confirm').callsFake((msg) => {
                expect(msg).to.include('Tem certeza que deseja excluir esta movimentação?');
                return true; // Simula clicar em OK no confirm
            }).as('confirmStub');
        });

        cy.focused().realPress('Enter');

        cy.get('@confirmStub').should('have.been.calledOnce');

        // Valida mensagem de sucesso e que a movimentação sumiu
        MovimentacaoPage.validarMensagem('Movimentação excluída com sucesso!');
    });
});
