import LoginPage from '../../support/page_objects/loginPage';

describe('Acessibilidade - Página Adicionar Conta', () => {

  beforeEach(() => {
    cy.session('user-session', () => {
      LoginPage.login('LoginPage@LoginPage.com', 'login_10');
    });
    cy.visit('/contas/adicionar');
  });

  it('139 - Deve conter apenas um elemento <main> na página', () => {
    cy.get('main').should('have.length', 1);
  });

  it('140 - Deve conter um heading visível e semântico <h2> com o texto correto', () => {
    cy.get('h2').should('have.text', 'Adicionar Conta').and('be.visible');
  });

  it('141 - O campo "nome" deve ter rótulo associado via <label for="..."> e id correspondente', () => {
    cy.get('label[for="nome"]').should('exist').and('contain.text', 'Nome');
    cy.get('#nome').should('exist').and('have.attr', 'name', 'nome');
  });

  it('142 - O campo "nome" deve ser acessível por teclado (focável)', () => {
  cy.get('#nome').focus().should('exist');
  });

  it('143 - O formulário deve conter botão do tipo submit e botão de cancelamento acessíveis via teclado', () => {
    cy.get('button[type="submit"]').should('contain.text', 'Salvar').focus();
    cy.focused().should('have.text', 'Salvar');
    cy.get('a.btn-secondary').should('contain.text', 'Cancelar').focus();
    cy.focused().should('have.text', 'Cancelar');
  });

  it('144 - Deve exibir mensagem de erro acessível se o campo "nome" for enviado vazio', () => {
    cy.get('form').submit();
    cy.get('.alert, [role="alert"], [aria-live="polite"], [aria-live="assertive"]')
      .should('exist')
      .and('contain.text', 'O nome da conta é obrigatório.')
      .and('be.visible');
  });

  it('145 - O formulário deve ser navegável via teclado (tabindex natural)', () => {
    const ordemEsperada = [
      'a.brand',                 // Marca do sistema
      'a:contains("Home")',      // Link Home
      'button:contains("Contas")', // Botão dropdown
      'a:contains("Adicionar")',
      'a:contains("Listar")',
      'a:contains("Criar Movimentação")',
      'a:contains("Resumo Mensal")',
      'a:contains("Sair")',
      'input[name="nome"]',       // Campo do formulário
      'button[type="submit"]',    // Botão salvar
      'a.btn-secondary'           // Botão cancelar
    ];

    let idx = 0;
    cy.get('body').realPress('Tab'); // primeiro tab

    ordemEsperada.forEach((selector, i) => {
      cy.focused().should('match', selector);
      if (i < ordemEsperada.length - 1) {
        cy.realPress('Tab');
      }
    });
  });

    it('146 - Botões "Salvar" e "Cancelar" devem ser acessíveis com foco via teclado', () => {
    cy.get('button[type="submit"]').focus().should('have.focus');
    cy.get('a.btn-secondary').focus().should('have.focus');
  });

  
  it('147 - Deve exibir mensagem de erro se campo "nome" estiver vazio após envio', () => {
    cy.get('input#nome').clear();
    cy.get('button[type="submit"]').click();
    cy.url().should('include', '/contas/adicionar'); // permanece na página
  });
});
