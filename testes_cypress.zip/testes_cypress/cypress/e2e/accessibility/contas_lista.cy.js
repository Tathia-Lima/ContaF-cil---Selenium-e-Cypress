import LoginPage from '../../support/page_objects/loginPage';
import 'cypress-axe';

describe('Acessibilidade - Página Lista Contas', () => {

  beforeEach(() => {
    cy.session('user-session', () => {
      LoginPage.login('ordemAlfabetica@ordem.com', 'login_10');
    });
    cy.visit('/contas');
  });

  it('166 - Deve ter uma tabela com cabeçalho e roles semânticos adequados', () => {
    cy.get('table').should('exist');
    cy.get('thead').should('exist');
    cy.get('thead th').each(($th) => {
      cy.wrap($th).should('have.attr', 'scope').and('match', /col|row/);
    });
  });

  it('167 - Os botões possuem textos claros e acessíveis', () => {
    ['Detalhes', 'Editar', 'Excluir', 'Adicionar Conta'].forEach(texto => {
      cy.contains('button, a', texto).should('be.visible').and('not.be.empty');
    });
  });

  it('168 - O formulário de exclusão possui token CSRF oculto', () => {
    cy.get('form').each(($form) => {
      cy.wrap($form).find('input[name="csrf_token"]').should('exist').and('have.attr', 'type', 'hidden');
    });
  });

  it('169 - Botão "Excluir" confirma exclusão e é focável via teclado', () => {
    cy.get('form button.btn-danger').first().focus().should('be.focused');
    cy.get('form').first().should('have.attr', 'onsubmit').and('include', 'confirm');
  });

  it('170 - Link "Adicionar Conta" é focável e possui texto descritivo', () => {
    cy.get('a.btn-success').should('be.visible').and('contain.text', 'Adicionar Conta').focus().should('be.focused');
  });

  it('171 - Deve focar elementos da tabela corretamente com TAB', () => {
    cy.visit('/contas');
    // Começa no botão "Adicionar Conta"
    cy.get('a.btn-success').focus().should('be.focused');
    // Tab para "Detalhes"
    cy.focused().tab();
    cy.focused().should('have.class', 'btn-primary').and('contain.text', 'Detalhes');
    // Tab para "Editar"
    cy.focused().tab();
    cy.focused().should('have.class', 'btn-warning').and('contain.text', 'Editar');
    // Tab para "Excluir"
    cy.focused().tab();
    cy.focused().should('have.class', 'btn-danger').and('contain.text', 'Excluir');
  });

  it('172 - Deve passar na verificação de contraste de cores', () => {
    cy.injectAxe(); // injeta axe-core na página
    cy.checkA11y(null, {
      runOnly: ['color-contrast']
    });
  });
});